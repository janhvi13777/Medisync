from datetime import datetime, timedelta, timezone
import json
import logging
import math
import os
import random
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

import httpx
from dotenv import load_dotenv
from emergentintegrations.llm.chat import LlmChat, UserMessage
from fastapi import APIRouter, FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import ReturnDocument
import bcrypt
from pydantic import BaseModel, EmailStr, Field
from jose import JWTError, jwt


ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

mongo_url = os.environ["MONGO_URL"]
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ["DB_NAME"]]
api_router = APIRouter(prefix="/api")
JWT_SECRET = os.getenv("JWT_SECRET", "medisync-local-secret")
JWT_ALGORITHM = "HS256"
EMERGENT_LLM_KEY = os.getenv("EMERGENT_LLM_KEY")
logger = logging.getLogger("medisync")

ROLES = {"coordinator", "hospital_admin", "ambulance", "specialist", "doctor", "admin"}


class UserPublic(BaseModel):
    user_id: str
    email: EmailStr
    name: str
    role: str
    organization: str
    facility_id: Optional[str] = None
    avatar_initials: str


class AuthResponse(BaseModel):
    session_token: str
    user: UserPublic


class RegisterRequest(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    email: EmailStr
    password: str = Field(min_length=8, max_length=100)
    role: str = "coordinator"
    organization: str = "Medisync Regional Network"


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class SessionRequest(BaseModel):
    session_id: str


class TriageRequest(BaseModel):
    patient_name: str = "Unknown"
    age: int = 40
    sex: str = "unknown"
    chief_complaint: str
    systolic_bp: int = 120
    diastolic_bp: int = 80
    heart_rate: int = 80
    respiratory_rate: int = 16
    spo2: int = 98
    temperature_c: float = 37.0
    consciousness: str = "alert"  # alert, verbal, pain, unresponsive
    trauma: bool = False


class MatchRequest(BaseModel):
    condition: str = "Critical patient"
    urgency: str = "High"
    required_care: str = "ICU"
    blood_type: str = "O+"
    oxygen_required: bool = True
    specialty_needed: Optional[str] = None
    patient_lat: float = 19.9975
    patient_lng: float = 73.7898
    explain: bool = True


class SupplyUpdate(BaseModel):
    quantity: int = Field(ge=0)


class AmbulanceLocationUpdate(BaseModel):
    lat: float
    lng: float
    status: Optional[str] = None
    destination: Optional[str] = None
    eta_min: Optional[int] = None


class DisasterSimulateRequest(BaseModel):
    scenario_name: str = "Mass casualty incident"
    critical: int = Field(default=10, ge=0, le=200)
    urgent: int = Field(default=25, ge=0, le=400)
    moderate: int = Field(default=40, ge=0, le=600)
    incident_lat: float = 19.9975
    incident_lng: float = 73.7898
    radius_km: float = Field(default=15.0, ge=1.0, le=100.0)
    activate: bool = False


class ConsultStartRequest(BaseModel):
    specialist_id: str
    patient_id: Optional[str] = None
    reason: str = "Emergency consult"


class ConsultEndRequest(BaseModel):
    consult_id: str



def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def safe_initials(name: str) -> str:
    pieces = [part[0] for part in name.strip().split() if part]
    return "".join(pieces[:2]).upper() or "MS"


def public_user(user: Dict[str, Any]) -> UserPublic:
    return UserPublic(
        user_id=user["user_id"],
        email=user["email"],
        name=user["name"],
        role=user.get("role", "coordinator"),
        organization=user.get("organization", "Medisync Regional Network"),
        facility_id=user.get("facility_id"),
        avatar_initials=user.get("avatar_initials", safe_initials(user["name"])),
    )


def issue_token(user_id: str) -> str:
    return jwt.encode(
        {"sub": user_id, "jti": uuid.uuid4().hex, "exp": now_utc() + timedelta(days=7)},
        JWT_SECRET,
        algorithm=JWT_ALGORITHM,
    )


async def current_user(authorization: Optional[str] = Header(default=None)) -> Dict[str, Any]:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Authentication required")
    token = authorization.split(" ", 1)[1].strip()
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        user_id = payload.get("sub")
    except JWTError as exc:
        raise HTTPException(status_code=401, detail="Invalid session") from exc
    session = await db.sessions.find_one({"token": token}, {"_id": 0})
    expires_at = session.get("expires_at") if session else None
    if expires_at and expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)
    if not session or not expires_at or expires_at < now_utc():
        raise HTTPException(status_code=401, detail="Session expired")
    user = await db.users.find_one({"user_id": user_id}, {"_id": 0})
    if not user:
        raise HTTPException(status_code=401, detail="Session user not found")
    return user


def haversine_km(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    r = 6371
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lng2 - lng1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return round(2 * r * math.asin(math.sqrt(a)), 2)


# ------------------------------- Seed data -------------------------------

def hospital_seed() -> List[Dict[str, Any]]:
    seed_file = ROOT_DIR / "data" / "hospitals_seed.json"
    if seed_file.exists():
        try:
            with open(seed_file) as fh:
                return json.load(fh)
        except Exception as exc:
            logger.warning("Falling back to inline seed: %s", exc)
    return [
        {
            "resource_id": "hosp-01", "name": "St. Mary's Medical Center", "short_name": "ST MARY'S",
            "lat": 34.0611, "lng": -118.2451,
            "beds_available": 18, "beds_total": 120, "icu_available": 5, "icu_total": 24,
            "er_wait_min": 8, "specialists": ["Trauma", "Cardiology", "Neurology"],
            "oxygen": True, "blood": ["O+", "A+", "O-", "B+"],
            "status": "optimal", "accent": "amber",
            "level": "Level 1 Trauma", "traffic_factor": 1.0,
        },
        {
            "resource_id": "hosp-02", "name": "Northside General Hospital", "short_name": "NORTHSIDE",
            "lat": 34.1023, "lng": -118.2812,
            "beds_available": 9, "beds_total": 96, "icu_available": 2, "icu_total": 18,
            "er_wait_min": 22, "specialists": ["Neurology", "Trauma", "Orthopedics"],
            "oxygen": True, "blood": ["O+", "B+", "AB+"],
            "status": "watch", "accent": "blue",
            "level": "Level 2 Trauma", "traffic_factor": 1.4,
        },
        {
            "resource_id": "hosp-03", "name": "Valley Children's & Trauma", "short_name": "VALLEY",
            "lat": 34.0299, "lng": -118.3417,
            "beds_available": 22, "beds_total": 84, "icu_available": 4, "icu_total": 16,
            "er_wait_min": 14, "specialists": ["Pediatrics", "Trauma", "Critical Care"],
            "oxygen": True, "blood": ["O+", "A-", "O-"],
            "status": "optimal", "accent": "green",
            "level": "Level 2 Trauma", "traffic_factor": 1.1,
        },
        {
            "resource_id": "hosp-04", "name": "East District Hospital", "short_name": "EAST DISTRICT",
            "lat": 34.0512, "lng": -118.1401,
            "beds_available": 3, "beds_total": 72, "icu_available": 0, "icu_total": 12,
            "er_wait_min": 35, "specialists": ["General", "Cardiology"],
            "oxygen": False, "blood": ["A+"],
            "status": "limited", "accent": "red",
            "level": "Level 3", "traffic_factor": 1.8,
        },
        {
            "resource_id": "hosp-05", "name": "Harbor Coastal Medical", "short_name": "HARBOR",
            "lat": 33.9871, "lng": -118.3011,
            "beds_available": 14, "beds_total": 88, "icu_available": 3, "icu_total": 14,
            "er_wait_min": 12, "specialists": ["Cardiology", "Neurology", "Trauma"],
            "oxygen": True, "blood": ["O+", "O-", "A+", "AB-"],
            "status": "optimal", "accent": "amber",
            "level": "Level 1 Trauma", "traffic_factor": 1.2,
        },
    ]


def ambulance_seed() -> List[Dict[str, Any]]:
    return [
        {"resource_id": "amb-01", "unit": "EMS-041", "crew": "Paramedic Lee & EMT Sanchez", "sector": "Nashik Road",
         "lat": 19.940, "lng": 73.780, "eta_min": 7, "status": "en_route",
         "destination": "Apollo", "destination_id": "NMC1008",
         "patient_on_board": True, "color": "amber"},
        {"resource_id": "amb-02", "unit": "EMS-118", "crew": "Paramedic Davis & EMT Kim", "sector": "Panchavati",
         "lat": 19.985, "lng": 73.790, "eta_min": 0, "status": "available",
         "destination": "Standby", "destination_id": None,
         "patient_on_board": False, "color": "green"},
        {"resource_id": "amb-03", "unit": "EMS-209", "crew": "Paramedic Chen & EMT Ali", "sector": "Satpur",
         "lat": 19.960, "lng": 73.760, "eta_min": 4, "status": "at_scene",
         "destination": "Ashoka", "destination_id": "NMC1010",
         "patient_on_board": True, "color": "blue"},
        {"resource_id": "amb-04", "unit": "EMS-334", "crew": "Paramedic Ortiz & EMT Wu", "sector": "CIDCO",
         "lat": 19.905, "lng": 73.770, "eta_min": 12, "status": "en_route",
         "destination": "Adgaon Samaj Kalyan", "destination_id": "NMC1004",
         "patient_on_board": True, "color": "amber"},
    ]


def specialist_seed() -> List[Dict[str, Any]]:
    return [
        {"resource_id": "spec-01", "name": "Dr. Aisha Rahman", "specialty": "Trauma surgery",
         "facility": "Apollo", "facility_id": "NMC1008",
         "status": "available", "response_min": 5, "initials": "AR", "on_call": True},
        {"resource_id": "spec-02", "name": "Dr. Michael Torres", "specialty": "Cardiology",
         "facility": "Ashoka", "facility_id": "NMC1010",
         "status": "consulting", "response_min": 12, "initials": "MT", "on_call": True},
        {"resource_id": "spec-03", "name": "Dr. Priya Nair", "specialty": "Critical care",
         "facility": "Adgaon Samaj Kalyan", "facility_id": "NMC1004",
         "status": "available", "response_min": 9, "initials": "PN", "on_call": True},
        {"resource_id": "spec-04", "name": "Dr. Ethan Kobayashi", "specialty": "Neurology",
         "facility": "Bytco CCC", "facility_id": "NMC1015",
         "status": "available", "response_min": 7, "initials": "EK", "on_call": True},
        {"resource_id": "spec-05", "name": "Dr. Rosa Delgado", "specialty": "Pediatrics",
         "facility": "Apex Super Specialty Hospital (Amrutdham)", "facility_id": "NMC1007",
         "status": "off_duty", "response_min": 45, "initials": "RD", "on_call": False},
    ]


def supply_seed() -> List[Dict[str, Any]]:
    return [
        {"resource_id": "sup-01", "name": "O negative blood", "category": "Blood", "quantity": 18, "unit": "units",
         "threshold": 12, "location": "Regional blood bank", "status": "stable"},
        {"resource_id": "sup-02", "name": "O positive blood", "category": "Blood", "quantity": 42, "unit": "units",
         "threshold": 20, "location": "Regional blood bank", "status": "stable"},
        {"resource_id": "sup-03", "name": "Medical oxygen", "category": "Oxygen", "quantity": 68, "unit": "cylinders",
         "threshold": 30, "location": "Central distribution", "status": "stable"},
        {"resource_id": "sup-04", "name": "Trauma kits", "category": "Trauma", "quantity": 9, "unit": "kits",
         "threshold": 12, "location": "Mobile reserve", "status": "low"},
        {"resource_id": "sup-05", "name": "PPE sets", "category": "PPE", "quantity": 188, "unit": "sets",
         "threshold": 80, "location": "Central distribution", "status": "stable"},
        {"resource_id": "sup-06", "name": "AB plasma", "category": "Blood", "quantity": 6, "unit": "units",
         "threshold": 8, "location": "Harbor Coastal", "status": "low"},
        {"resource_id": "sup-07", "name": "Ventilators", "category": "Equipment", "quantity": 14, "unit": "units",
         "threshold": 10, "location": "Regional pool", "status": "stable"},
    ]


def patient_seed() -> List[Dict[str, Any]]:
    return [
        {"resource_id": "pat-01", "fhir_id": "Patient/12881", "name": "M. Alvarez", "age": 62, "sex": "male",
         "condition": "Acute MI · chest pain 45 min", "severity": "critical", "assigned_ambulance": "amb-01",
         "assigned_hospital": "NMC1008", "eta_min": 7},
        {"resource_id": "pat-02", "fhir_id": "Patient/12902", "name": "T. Nakamura", "age": 34, "sex": "female",
         "condition": "MVA polytrauma", "severity": "critical", "assigned_ambulance": "amb-03",
         "assigned_hospital": "NMC1010", "eta_min": 4},
        {"resource_id": "pat-03", "fhir_id": "Patient/12915", "name": "J. Okafor", "age": 8, "sex": "male",
         "condition": "Severe asthma exacerbation", "severity": "urgent", "assigned_ambulance": "amb-04",
         "assigned_hospital": "NMC1004", "eta_min": 12},
    ]


def forecast_seed() -> List[Dict[str, Any]]:
    return [
        {"resource_id": "fx-01", "resource": "ICU beds", "region": "Northside sector",
         "current": 2, "predicted_6h": 0, "predicted_24h": 1, "risk": "high",
         "advice": "Pre-position 2 vent-capable transfer teams to Northside; reroute non-critical to Valley."},
        {"resource_id": "fx-02", "resource": "O negative blood", "region": "Regional",
         "current": 18, "predicted_6h": 12, "predicted_24h": 6, "risk": "medium",
         "advice": "Trigger regional donation call; reserve remaining O- for trauma only."},
        {"resource_id": "fx-03", "resource": "Trauma kits", "region": "Mobile reserve",
         "current": 9, "predicted_6h": 5, "predicted_24h": 2, "risk": "high",
         "advice": "Restock trauma kits from Central distribution within 4 hours."},
        {"resource_id": "fx-04", "resource": "Ventilators", "region": "Regional pool",
         "current": 14, "predicted_6h": 12, "predicted_24h": 9, "risk": "low",
         "advice": "Current buffer sufficient. Monitor Harbor Coastal ICU admits."},
    ]


DEMO_USERS = [
    {"email": "coordinator@medisync.app", "name": "Jordan Blake", "role": "coordinator",
     "organization": "Medisync Regional Command", "password": "MediSync123!", "facility_id": None},
    {"email": "hospital@medisync.app", "name": "Dr. Amara Okoye", "role": "hospital_admin",
     "organization": "Apollo Nashik", "password": "MediSync123!", "facility_id": "NMC1008"},
    {"email": "ambulance@medisync.app", "name": "Paramedic Sam Lee", "role": "ambulance",
     "organization": "EMS-041 Nashik Road", "password": "MediSync123!", "facility_id": "amb-01"},
    {"email": "specialist@medisync.app", "name": "Dr. Aisha Rahman", "role": "specialist",
     "organization": "Apollo Trauma Surgery", "password": "MediSync123!", "facility_id": "spec-01"},
    {"email": "doctor@medisync.app", "name": "Dr. Kai Reyes", "role": "doctor",
     "organization": "Apollo Emergency Dept", "password": "MediSync123!", "facility_id": "NMC1008"},
]


async def seed_collection(name: str, docs: List[Dict[str, Any]]) -> None:
    collection = db[name]
    for doc in docs:
        await collection.update_one(
            {"resource_id": doc["resource_id"]}, {"$setOnInsert": doc}, upsert=True
        )


async def ensure_seed_data() -> None:
    await db.users.create_index("email", unique=True)
    await db.users.create_index("user_id", unique=True)
    await db.sessions.create_index("token", unique=True)
    await seed_collection("hospitals", hospital_seed())
    await seed_collection("ambulances", ambulance_seed())
    await seed_collection("specialists", specialist_seed())
    await seed_collection("supplies", supply_seed())
    await seed_collection("patients", patient_seed())
    await seed_collection("forecasts", forecast_seed())
    for demo in DEMO_USERS:
        existing = await db.users.find_one({"email": demo["email"]}, {"_id": 0})
        if existing:
            continue
        await db.users.insert_one({
            "user_id": f"user_{demo['role']}_{uuid.uuid4().hex[:8]}",
            "email": demo["email"],
            "name": demo["name"],
            "password_hash": bcrypt.hashpw(demo["password"].encode(), bcrypt.gensalt()).decode(),
            "role": demo["role"],
            "organization": demo["organization"],
            "facility_id": demo["facility_id"],
            "avatar_initials": safe_initials(demo["name"]),
            "created_at": now_utc(),
        })


# ------------------------------- Auth routes -------------------------------

@api_router.get("/")
async def root() -> Dict[str, str]:
    return {"message": "Medisync API online"}


@api_router.post("/auth/register", response_model=AuthResponse)
async def register(payload: RegisterRequest) -> AuthResponse:
    existing = await db.users.find_one({"email": payload.email.lower()}, {"_id": 0})
    if existing:
        raise HTTPException(status_code=409, detail="An account with this email already exists")
    role = payload.role if payload.role in ROLES else "coordinator"
    user = {
        "user_id": f"user_{uuid.uuid4().hex[:12]}",
        "email": payload.email.lower(),
        "name": payload.name.strip(),
        "password_hash": bcrypt.hashpw(payload.password.encode(), bcrypt.gensalt()).decode(),
        "role": role,
        "organization": payload.organization.strip() or "Medisync Regional Network",
        "facility_id": None,
        "avatar_initials": safe_initials(payload.name),
        "created_at": now_utc(),
    }
    await db.users.insert_one(user.copy())
    token = issue_token(user["user_id"])
    await db.sessions.insert_one(
        {"token": token, "user_id": user["user_id"], "expires_at": now_utc() + timedelta(days=7)}
    )
    return AuthResponse(session_token=token, user=public_user(user))


@api_router.post("/auth/login", response_model=AuthResponse)
async def login(payload: LoginRequest) -> AuthResponse:
    user = await db.users.find_one({"email": payload.email.lower()}, {"_id": 0})
    if (
        not user
        or not user.get("password_hash")
        or not bcrypt.checkpw(payload.password.encode(), user["password_hash"].encode())
    ):
        raise HTTPException(status_code=401, detail="Email or password is incorrect")
    token = issue_token(user["user_id"])
    await db.sessions.insert_one(
        {"token": token, "user_id": user["user_id"], "expires_at": now_utc() + timedelta(days=7)}
    )
    return AuthResponse(session_token=token, user=public_user(user))


@api_router.post("/auth/session", response_model=AuthResponse)
async def google_session(payload: SessionRequest) -> AuthResponse:
    try:
        async with httpx.AsyncClient(timeout=12) as http_client:
            response = await http_client.get(
                "https://demobackend.emergentagent.com/auth/v1/env/oauth/session-data",
                headers={"X-Session-ID": payload.session_id},
            )
        if response.status_code != 200:
            raise HTTPException(status_code=401, detail="Google session could not be verified")
        data = response.json()
    except HTTPException:
        raise
    except Exception as exc:
        logger.warning("Google session exchange failed: %s", exc)
        raise HTTPException(status_code=401, detail="Google session could not be verified") from exc
    email = data.get("email")
    if not email:
        raise HTTPException(status_code=401, detail="Google profile did not include an email")
    user = await db.users.find_one({"email": email.lower()}, {"_id": 0})
    if not user:
        name = data.get("name") or email.split("@", 1)[0].replace(".", " ").title()
        user = {
            "user_id": f"user_{uuid.uuid4().hex[:12]}", "email": email.lower(), "name": name,
            "role": "coordinator", "organization": "Medisync Regional Network",
            "facility_id": None, "avatar_initials": safe_initials(name), "created_at": now_utc(),
        }
        await db.users.insert_one(user.copy())
    token = issue_token(user["user_id"])
    await db.sessions.insert_one(
        {"token": token, "user_id": user["user_id"], "expires_at": now_utc() + timedelta(days=7)}
    )
    return AuthResponse(session_token=token, user=public_user(user))


@api_router.get("/auth/me", response_model=UserPublic)
async def me(authorization: Optional[str] = Header(default=None)) -> UserPublic:
    user = await current_user(authorization)
    return public_user(user)


@api_router.post("/auth/logout")
async def logout(authorization: Optional[str] = Header(default=None)) -> Dict[str, bool]:
    if authorization and authorization.lower().startswith("bearer "):
        await db.sessions.delete_one({"token": authorization.split(" ", 1)[1].strip()})
    return {"ok": True}


# ------------------------------- Dashboards -------------------------------

@api_router.get("/dashboard")
async def dashboard(authorization: Optional[str] = Header(default=None)) -> Dict[str, Any]:
    user = await current_user(authorization)
    hospitals = await db.hospitals.find({}, {"_id": 0}).to_list(500)
    supplies = await db.supplies.find({}, {"_id": 0}).to_list(50)
    ambulances = await db.ambulances.find({}, {"_id": 0}).to_list(50)
    patients = await db.patients.find({}, {"_id": 0}).to_list(50)
    total_beds = sum(item["beds_total"] for item in hospitals)
    available_beds = sum(item["beds_available"] for item in hospitals)
    total_icu = sum(item["icu_total"] for item in hospitals)
    available_icu = sum(item["icu_available"] for item in hospitals)
    active_units = sum(1 for a in ambulances if a["status"] in {"en_route", "at_scene"})

    role = user.get("role", "coordinator")
    facility_id = user.get("facility_id")

    if role == "hospital_admin" and facility_id:
        my_hospital = next((h for h in hospitals if h["resource_id"] == facility_id), hospitals[0])
        inbound = [
            {**a, "patient": next((p for p in patients if p.get("assigned_ambulance") == a["resource_id"]), None)}
            for a in ambulances if a.get("destination") == my_hospital["name"]
        ]
        return {
            "role": role,
            "connection": {"status": "live", "label": "LIVE SYNC", "last_sync": "14 seconds ago"},
            "hospital": my_hospital,
            "inbound_ambulances": inbound,
            "metrics": {
                "available_beds": my_hospital["beds_available"], "total_beds": my_hospital["beds_total"],
                "available_icu": my_hospital["icu_available"], "total_icu": my_hospital["icu_total"],
                "er_wait_min": my_hospital["er_wait_min"], "inbound": len(inbound),
            },
            "alerts": [
                {"id": "alert-h1", "type": "warning", "title": "ICU capacity below 25%",
                 "detail": f"{my_hospital['icu_available']} of {my_hospital['icu_total']} ICU beds open", "time": "3 min ago"},
                {"id": "alert-h2", "type": "info", "title": f"{len(inbound)} inbound ambulances",
                 "detail": "Prepare trauma bay 3 and neuro consult", "time": "just now"},
            ],
        }

    if role == "ambulance" and facility_id:
        my_amb = next((a for a in ambulances if a["resource_id"] == facility_id), ambulances[0])
        my_patient = next((p for p in patients if p.get("assigned_ambulance") == my_amb["resource_id"]), None)
        return {
            "role": role,
            "connection": {"status": "live", "label": "GPS LOCK", "last_sync": "3 seconds ago"},
            "ambulance": my_amb,
            "patient": my_patient,
            "destination": next((h for h in hospitals if h["name"] == my_amb.get("destination")), None),
            "metrics": {
                "eta_min": my_amb["eta_min"], "sector": my_amb["sector"],
                "status": my_amb["status"], "patient_on_board": my_amb["patient_on_board"],
            },
            "alerts": [
                {"id": "alert-a1", "type": "info", "title": "Route optimized",
                 "detail": "Traffic cleared on Route 405 · saved 3 min", "time": "1 min ago"},
            ],
        }

    if role == "specialist" and facility_id:
        my_spec = next((s for s in await db.specialists.find({}, {"_id": 0}).to_list(50)
                        if s["resource_id"] == facility_id), None)
        related_patients = [p for p in patients if p.get("severity") in {"critical", "urgent"}][:3]
        return {
            "role": role,
            "connection": {"status": "live", "label": "ON-CALL LIVE", "last_sync": "9 seconds ago"},
            "specialist": my_spec,
            "consults": related_patients,
            "metrics": {
                "status": my_spec["status"] if my_spec else "available",
                "response_min": my_spec["response_min"] if my_spec else 0,
                "pending_consults": len(related_patients),
            },
            "alerts": [
                {"id": "alert-s1", "type": "warning", "title": "Trauma consult requested",
                 "detail": "MVA polytrauma · ETA 4 min · East District", "time": "2 min ago"},
            ],
        }

    if role == "doctor" and facility_id:
        my_hospital = next((h for h in hospitals if h["resource_id"] == facility_id), hospitals[0])
        my_patients = [p for p in patients if p.get("assigned_hospital") == facility_id]
        return {
            "role": role,
            "connection": {"status": "live", "label": "LIVE SYNC", "last_sync": "14 seconds ago"},
            "hospital": my_hospital,
            "patients": my_patients,
            "metrics": {
                "active_cases": len(my_patients),
                "critical": sum(1 for p in my_patients if p.get("severity") == "critical"),
                "er_wait_min": my_hospital["er_wait_min"],
            },
            "alerts": [
                {"id": "alert-d1", "type": "warning", "title": "Critical patient inbound",
                 "detail": "Acute MI · 62yo M · ETA 7 min", "time": "just now"},
            ],
        }

    # Coordinator / admin default
    low_supplies = [s for s in supplies if s["status"] == "low"]
    return {
        "role": role,
        "connection": {"status": "live", "label": "LIVE SYNC", "last_sync": "14 seconds ago"},
        "metrics": {
            "available_beds": available_beds, "total_beds": total_beds,
            "available_icu": available_icu, "total_icu": total_icu,
            "active_units": active_units, "low_supplies": len(low_supplies),
            "hospitals_online": len(hospitals),
        },
        "hospitals": hospitals[:5],
        "ambulances": ambulances,
        "patients": patients,
        "alerts": [
            {"id": "alert-c1", "type": "warning", "title": "Trauma kit reserve below threshold",
             "detail": "Mobile reserve · 9 kits remaining", "time": "8 min ago"},
            {"id": "alert-c2", "type": "info", "title": "EMS-041 en route",
             "detail": "ETA 7 min · St. Mary's Medical Center", "time": "12 sec ago"},
            {"id": "alert-c3", "type": "warning", "title": "AB plasma low at Harbor",
             "detail": "6 of 8 threshold · reroute donations", "time": "22 min ago"},
        ],
    }


# ------------------------------- Resources -------------------------------

async def all_resources(collection: str, authorization: Optional[str]) -> List[Dict[str, Any]]:
    await current_user(authorization)
    return await db[collection].find({}, {"_id": 0}).to_list(200)


@api_router.get("/hospitals")
async def hospitals(authorization: Optional[str] = Header(default=None)) -> List[Dict[str, Any]]:
    return await all_resources("hospitals", authorization)


@api_router.get("/ambulances")
async def ambulances(authorization: Optional[str] = Header(default=None)) -> List[Dict[str, Any]]:
    return await all_resources("ambulances", authorization)


@api_router.get("/specialists")
async def specialists(authorization: Optional[str] = Header(default=None)) -> List[Dict[str, Any]]:
    return await all_resources("specialists", authorization)


@api_router.get("/supplies")
async def supplies(authorization: Optional[str] = Header(default=None)) -> List[Dict[str, Any]]:
    return await all_resources("supplies", authorization)


@api_router.get("/patients")
async def patients(authorization: Optional[str] = Header(default=None)) -> List[Dict[str, Any]]:
    return await all_resources("patients", authorization)


@api_router.get("/analytics/forecast")
async def forecasts(authorization: Optional[str] = Header(default=None)) -> Dict[str, Any]:
    await current_user(authorization)
    items = await db.forecasts.find({}, {"_id": 0}).to_list(50)
    summary = {
        "high_risk": sum(1 for i in items if i["risk"] == "high"),
        "medium_risk": sum(1 for i in items if i["risk"] == "medium"),
        "low_risk": sum(1 for i in items if i["risk"] == "low"),
    }
    return {"forecasts": items, "summary": summary,
            "generated_at": now_utc().isoformat(),
            "model": "Medisync Predictive v1 · time-series + regional load"}


@api_router.patch("/supplies/{resource_id}")
async def update_supply(
    resource_id: str, payload: SupplyUpdate,
    authorization: Optional[str] = Header(default=None),
) -> Dict[str, Any]:
    await current_user(authorization)
    existing = await db.supplies.find_one({"resource_id": resource_id}, {"_id": 0, "threshold": 1})
    if not existing:
        raise HTTPException(status_code=404, detail="Supply not found")
    supply = await db.supplies.find_one_and_update(
        {"resource_id": resource_id},
        {"$set": {
            "quantity": payload.quantity,
            "status": "low" if payload.quantity < existing.get("threshold", 0) else "stable",
        }},
        projection={"_id": 0}, return_document=ReturnDocument.AFTER,
    )
    return supply


@api_router.patch("/ambulances/{resource_id}/location")
async def update_ambulance_location(
    resource_id: str, payload: AmbulanceLocationUpdate,
    authorization: Optional[str] = Header(default=None),
) -> Dict[str, Any]:
    await current_user(authorization)
    update = {"lat": payload.lat, "lng": payload.lng}
    if payload.status:
        update["status"] = payload.status
    if payload.destination:
        update["destination"] = payload.destination
    if payload.eta_min is not None:
        update["eta_min"] = payload.eta_min
    ambulance = await db.ambulances.find_one_and_update(
        {"resource_id": resource_id}, {"$set": update},
        projection={"_id": 0}, return_document=ReturnDocument.AFTER,
    )
    if not ambulance:
        raise HTTPException(status_code=404, detail="Ambulance not found")
    return ambulance


# ------------------------------- AI Triage -------------------------------

def deterministic_triage(req: TriageRequest) -> Dict[str, Any]:
    score = 0
    flags: List[str] = []
    if req.systolic_bp < 90:
        score += 3; flags.append("hypotension")
    elif req.systolic_bp > 180:
        score += 2; flags.append("hypertensive crisis")
    if req.heart_rate > 130 or req.heart_rate < 40:
        score += 3; flags.append("abnormal heart rate")
    if req.respiratory_rate > 30 or req.respiratory_rate < 8:
        score += 3; flags.append("respiratory distress")
    if req.spo2 < 90:
        score += 4; flags.append("severe hypoxia")
    elif req.spo2 < 94:
        score += 2; flags.append("hypoxia")
    if req.temperature_c > 39.5 or req.temperature_c < 35:
        score += 2; flags.append("temp extreme")
    if req.consciousness in {"pain", "unresponsive"}:
        score += 4; flags.append("altered mental status")
    elif req.consciousness == "verbal":
        score += 2; flags.append("reduced consciousness")
    if req.trauma:
        score += 2; flags.append("trauma mechanism")

    if score >= 8:
        severity = "critical"; recommend_icu = True; recommend_vent = req.spo2 < 90 or req.respiratory_rate > 30
    elif score >= 5:
        severity = "urgent"; recommend_icu = True; recommend_vent = False
    elif score >= 2:
        severity = "moderate"; recommend_icu = False; recommend_vent = False
    else:
        severity = "stable"; recommend_icu = False; recommend_vent = False

    specialty = "General emergency"
    text = req.chief_complaint.lower()
    if any(k in text for k in ["chest", "cardiac", "mi", "heart"]):
        specialty = "Cardiology"
    elif any(k in text for k in ["stroke", "neuro", "headache", "seizure"]):
        specialty = "Neurology"
    elif req.trauma or any(k in text for k in ["mva", "trauma", "fall", "gun", "stab"]):
        specialty = "Trauma surgery"
    elif req.age < 16:
        specialty = "Pediatrics"

    return {
        "severity": severity,
        "score": score,
        "flags": flags,
        "recommend_icu": recommend_icu,
        "recommend_ventilator": recommend_vent,
        "recommend_specialty": specialty,
        "recommend_blood_ready": req.trauma or severity == "critical",
    }


async def ai_triage_narrative(req: TriageRequest, det: Dict[str, Any]) -> str:
    fallback = (
        f"{det['severity'].upper()} case (score {det['score']}). "
        f"Key concerns: {', '.join(det['flags']) or 'vitals within range'}. "
        f"Recommend {det['recommend_specialty']}"
        f"{' with ICU bed' if det['recommend_icu'] else ''}"
        f"{' and ventilator ready' if det['recommend_ventilator'] else ''}."
    )
    if not EMERGENT_LLM_KEY:
        return fallback
    try:
        chat = LlmChat(
            api_key=EMERGENT_LLM_KEY,
            session_id=f"triage-{uuid.uuid4().hex}",
            system_message=(
                "You are Medisync Triage AI. Give a 2-sentence operational summary for an "
                "emergency coordinator: severity, top 1-2 concerns, and what resources to prepare. "
                "Do not diagnose or invent clinical facts."
            ),
        ).with_model("anthropic", "claude-sonnet-4-6")
        prompt = {"patient": req.model_dump(), "assessment": det}
        return await chat.send_message(UserMessage(text=f"Summarize this triage: {prompt}"))
    except Exception as exc:
        logger.warning("AI triage fallback: %s", exc)
        return fallback


@api_router.post("/triage")
async def triage(payload: TriageRequest, authorization: Optional[str] = Header(default=None)) -> Dict[str, Any]:
    await current_user(authorization)
    det = deterministic_triage(payload)
    narrative = await ai_triage_narrative(payload, det)
    return {"request": payload.model_dump(), "assessment": det, "narrative": narrative,
            "engine": "deterministic vitals + Claude Sonnet 4.6 narrative"}


# ------------------------------- Hospital Matching -------------------------------

def score_hospital(req: MatchRequest, hospital: Dict[str, Any]) -> Dict[str, Any]:
    # Sub-scores summing to 100.
    breakdown = {}
    total = 0

    # Distance / ETA (30 pts)
    dist = haversine_km(req.patient_lat, req.patient_lng, hospital["lat"], hospital["lng"])
    eta = round(dist * 2 * hospital.get("traffic_factor", 1.0))  # ~2 min/km base
    dist_score = max(0, 30 - min(30, int(eta * 0.9)))
    breakdown["distance"] = {"points": dist_score, "max": 30,
                             "detail": f"{dist} km · ~{eta} min with traffic"}
    total += dist_score

    # ICU (25 pts)
    if req.required_care.lower() == "icu":
        if hospital["icu_available"] >= 3:
            pts = 25; d = f"{hospital['icu_available']} ICU beds open"
        elif hospital["icu_available"] > 0:
            pts = 15; d = f"only {hospital['icu_available']} ICU bed(s) open"
        else:
            pts = 0; d = "no ICU beds"
    else:
        pts = 20 if hospital["beds_available"] > 5 else 10
        d = f"{hospital['beds_available']} general beds"
    breakdown["capacity"] = {"points": pts, "max": 25, "detail": d}
    total += pts

    # Specialist match (20 pts)
    needed = (req.specialty_needed or "").strip().lower()
    if needed:
        has = any(needed in s.lower() for s in hospital.get("specialists", []))
        pts = 20 if has else 5
        d = "specialist on-site" if has else "no matching specialist"
    else:
        pts = 15
        d = f"{len(hospital.get('specialists', []))} specialties available"
    breakdown["specialist"] = {"points": pts, "max": 20, "detail": d}
    total += pts

    # Blood (15 pts)
    if req.blood_type in hospital.get("blood", []):
        pts = 15; d = f"{req.blood_type} blood on hand"
    else:
        pts = 3; d = f"{req.blood_type} not stocked"
    breakdown["blood"] = {"points": pts, "max": 15, "detail": d}
    total += pts

    # Oxygen / ER wait (10 pts)
    pts = 0
    if req.oxygen_required and hospital.get("oxygen"):
        pts += 6
    elif not req.oxygen_required:
        pts += 6
    pts += max(0, 4 - min(4, hospital.get("er_wait_min", 0) // 8))
    d = f"O₂ {'✓' if hospital.get('oxygen') else '✗'} · ER wait {hospital.get('er_wait_min', 0)} min"
    breakdown["readiness"] = {"points": pts, "max": 10, "detail": d}
    total += pts

    reasons = [v["detail"] for v in breakdown.values()]

    return {
        "hospital": hospital,
        "score": min(total, 100),
        "eta_min": eta,
        "distance_km": dist,
        "breakdown": breakdown,
        "reasons": reasons,
    }


def fallback_match_explanation(req: MatchRequest, top: Dict[str, Any]) -> str:
    h = top["hospital"]
    return (
        f"{h['name']} scores {top['score']}/100. It has {h['icu_available']} ICU beds open, "
        f"stocks {req.blood_type} blood, and is ~{top['eta_min']} minutes away accounting for traffic. "
        f"Score reflects distance ({top['breakdown']['distance']['points']}/30), capacity "
        f"({top['breakdown']['capacity']['points']}/25), specialist "
        f"({top['breakdown']['specialist']['points']}/20), blood "
        f"({top['breakdown']['blood']['points']}/15), and readiness "
        f"({top['breakdown']['readiness']['points']}/10)."
    )


async def ai_match_explanation(req: MatchRequest, top: Dict[str, Any], all_matches: List[Dict[str, Any]]) -> str:
    fallback = fallback_match_explanation(req, top)
    if not EMERGENT_LLM_KEY:
        return fallback
    try:
        chat = LlmChat(
            api_key=EMERGENT_LLM_KEY,
            session_id=f"match-{uuid.uuid4().hex}",
            system_message=(
                "You are Medisync, an emergency healthcare coordination assistant. "
                "Give a concise, 2-sentence explanation of why the top hospital was chosen "
                "over the runner-up, mentioning specific sub-score wins. Do not invent facts."
            ),
        ).with_model("anthropic", "claude-sonnet-4-6")
        summary = [
            {"name": m["hospital"]["name"], "score": m["score"],
             "eta_min": m["eta_min"], "breakdown": m["breakdown"]}
            for m in all_matches[:3]
        ]
        return await chat.send_message(UserMessage(
            text=f"Explain the match for: {req.model_dump()}. Ranked: {summary}"
        ))
    except Exception as exc:
        logger.warning("AI match fallback: %s", exc)
        return fallback


@api_router.post("/match")
async def match_patient(
    payload: MatchRequest, authorization: Optional[str] = Header(default=None),
) -> Dict[str, Any]:
    await current_user(authorization)
    hospitals = await db.hospitals.find({}, {"_id": 0}).to_list(500)
    scored = [score_hospital(payload, h) for h in hospitals]
    scored.sort(key=lambda item: (-item["score"], item["eta_min"]))
    top = scored[0]
    explanation = (
        await ai_match_explanation(payload, top, scored)
        if payload.explain else fallback_match_explanation(payload, top)
    )
    return {
        "request": payload.model_dump(),
        "matches": scored,
        "top_match": top,
        "explanation": explanation,
        "engine": "0-100 weighted scoring + Claude Sonnet 4.6 rationale" if payload.explain else "deterministic 0-100 scoring",
    }


# ------------------------------- Disaster Mode -------------------------------


def _hospital_capacity_score(h: Dict[str, Any]) -> float:
    """Higher is better. Weighs ICU, ventilators, general beds, and emergency status."""
    status_multiplier = {"NORMAL": 1.0, "BUSY": 0.6, "CRITICAL": 0.25}.get(
        h.get("emergency_status", "NORMAL"), 0.7,
    )
    return (
        h.get("icu_available", 0) * 5
        + h.get("ventilator_available", 0) * 4
        + h.get("beds_available", 0) * 1
    ) * status_multiplier


def _distribute_patients(
    hospitals_in_range: List[Dict[str, Any]],
    critical: int, urgent: int, moderate: int,
) -> List[Dict[str, Any]]:
    """Greedy allocation: critical → best ICU/vent facilities, urgent → next, moderate → any."""
    # Build mutable capacity buckets.
    buckets = []
    for h in hospitals_in_range:
        buckets.append({
            "hospital": h,
            "icu_left": max(0, h.get("icu_available", 0)),
            "vent_left": max(0, h.get("ventilator_available", 0)),
            "beds_left": max(0, h.get("beds_available", 0)),
            "critical_assigned": 0,
            "urgent_assigned": 0,
            "moderate_assigned": 0,
            "unassigned_critical": 0,
        })
    # Critical: need ICU first.
    buckets.sort(key=lambda b: (-b["icu_left"], -b["vent_left"], b["hospital"].get("_distance", 0)))
    remaining_critical = critical
    for b in buckets:
        take = min(b["icu_left"], remaining_critical)
        b["critical_assigned"] += take
        b["icu_left"] -= take
        remaining_critical -= take
        if remaining_critical == 0:
            break
    # If critical patients remain, use ventilators.
    if remaining_critical:
        buckets.sort(key=lambda b: (-b["vent_left"], b["hospital"].get("_distance", 0)))
        for b in buckets:
            take = min(b["vent_left"], remaining_critical)
            b["critical_assigned"] += take
            b["vent_left"] -= take
            remaining_critical -= take
            if remaining_critical == 0:
                break
    # Urgent: prefer general beds nearest.
    buckets.sort(key=lambda b: (b["hospital"].get("_distance", 0), -b["beds_left"]))
    remaining_urgent = urgent
    for b in buckets:
        cap = b["beds_left"] // 2  # reserve half for moderate
        take = min(cap, remaining_urgent)
        b["urgent_assigned"] += take
        b["beds_left"] -= take
        remaining_urgent -= take
        if remaining_urgent == 0:
            break
    # Moderate: any remaining bed capacity.
    remaining_moderate = moderate
    for b in buckets:
        take = min(b["beds_left"], remaining_moderate)
        b["moderate_assigned"] += take
        b["beds_left"] -= take
        remaining_moderate -= take
        if remaining_moderate == 0:
            break
    unassigned = {
        "critical": remaining_critical,
        "urgent": remaining_urgent,
        "moderate": remaining_moderate,
    }
    return buckets, unassigned


@api_router.post("/disaster/simulate")
async def disaster_simulate(
    payload: DisasterSimulateRequest,
    authorization: Optional[str] = Header(default=None),
) -> Dict[str, Any]:
    await current_user(authorization)
    hospitals = await db.hospitals.find({}, {"_id": 0}).to_list(500)
    # Filter by radius.
    in_range = []
    for h in hospitals:
        dist = haversine_km(payload.incident_lat, payload.incident_lng, h["lat"], h["lng"])
        if dist <= payload.radius_km:
            h_copy = {**h, "_distance": dist}
            in_range.append(h_copy)
    if not in_range:
        raise HTTPException(status_code=400, detail="No hospitals within radius")
    buckets, unassigned = _distribute_patients(
        in_range, payload.critical, payload.urgent, payload.moderate,
    )
    # Build plan output.
    plan = []
    total_assigned = 0
    for b in buckets:
        assigned_total = b["critical_assigned"] + b["urgent_assigned"] + b["moderate_assigned"]
        if assigned_total == 0:
            continue
        h = b["hospital"]
        plan.append({
            "hospital_id": h["resource_id"],
            "hospital_name": h["name"],
            "distance_km": round(h["_distance"], 2),
            "eta_min": round(h["_distance"] * 2 * h.get("traffic_factor", 1.0)),
            "assigned": {
                "critical": b["critical_assigned"],
                "urgent": b["urgent_assigned"],
                "moderate": b["moderate_assigned"],
                "total": assigned_total,
            },
            "capacity_after": {
                "icu_remaining": b["icu_left"],
                "ventilator_remaining": b["vent_left"],
                "beds_remaining": b["beds_left"],
            },
            "emergency_status": h.get("emergency_status", "NORMAL"),
        })
        total_assigned += assigned_total
    plan.sort(key=lambda p: -p["assigned"]["total"])

    scenario_id = f"ds_{uuid.uuid4().hex[:12]}"
    active_doc = {
        "scenario_id": scenario_id,
        "scenario_name": payload.scenario_name,
        "incident_lat": payload.incident_lat,
        "incident_lng": payload.incident_lng,
        "radius_km": payload.radius_km,
        "patients": {
            "critical": payload.critical,
            "urgent": payload.urgent,
            "moderate": payload.moderate,
            "total": payload.critical + payload.urgent + payload.moderate,
        },
        "unassigned": unassigned,
        "hospitals_used": len(plan),
        "hospitals_in_range": len(in_range),
        "plan": plan,
        "created_at": now_utc(),
        "active": payload.activate,
    }
    if payload.activate:
        # Deactivate any previously active scenario.
        await db.disasters.update_many({"active": True}, {"$set": {"active": False}})
        await db.disasters.insert_one(active_doc.copy())
    return {
        "scenario_id": scenario_id,
        "scenario_name": payload.scenario_name,
        "patients": active_doc["patients"],
        "unassigned": unassigned,
        "hospitals_used": len(plan),
        "hospitals_in_range": len(in_range),
        "total_assigned": total_assigned,
        "plan": plan,
        "active": payload.activate,
    }


@api_router.get("/disaster/active")
async def disaster_active(authorization: Optional[str] = Header(default=None)) -> Dict[str, Any]:
    await current_user(authorization)
    doc = await db.disasters.find_one({"active": True}, {"_id": 0})
    return {"active": doc is not None, "disaster": doc}


@api_router.post("/disaster/end")
async def disaster_end(authorization: Optional[str] = Header(default=None)) -> Dict[str, bool]:
    await current_user(authorization)
    await db.disasters.update_many({"active": True}, {"$set": {"active": False}})
    return {"ok": True}


# ------------------------------- Ambulance Live Route -------------------------------


def _route_maneuver(idx: int, total: int, dest_name: str) -> str:
    if idx == 0:
        return "Depart scene, head toward main road"
    if idx == total - 1:
        return f"Arrive at {dest_name}"
    hints = [
        "Continue straight",
        "Merge with main corridor",
        "Bear right toward city center",
        "Continue on route",
        "Turn left at signal",
        "Continue past next junction",
        "Approach hospital entrance",
    ]
    return hints[idx % len(hints)]


@api_router.get("/ambulances/{resource_id}/route")
async def ambulance_route(
    resource_id: str, authorization: Optional[str] = Header(default=None),
) -> Dict[str, Any]:
    await current_user(authorization)
    amb = await db.ambulances.find_one({"resource_id": resource_id}, {"_id": 0})
    if not amb:
        raise HTTPException(status_code=404, detail="Ambulance not found")
    dest_id = amb.get("destination_id")
    dest = None
    if dest_id:
        dest = await db.hospitals.find_one({"resource_id": dest_id}, {"_id": 0})
    if not dest:
        # Try by destination name.
        dest = await db.hospitals.find_one({"name": amb.get("destination", "")}, {"_id": 0})
    if not dest:
        raise HTTPException(status_code=400, detail="Ambulance has no active destination")
    steps = 12
    dist = haversine_km(amb["lat"], amb["lng"], dest["lat"], dest["lng"])
    total_eta = max(1, round(dist * 2 * dest.get("traffic_factor", 1.0)))
    waypoints = []
    # Add a small deterministic jitter so the route looks realistic, not a straight line.
    seed = sum(ord(c) for c in resource_id)
    rng = random.Random(seed)
    for i in range(steps + 1):
        t = i / steps
        lat = amb["lat"] + (dest["lat"] - amb["lat"]) * t
        lng = amb["lng"] + (dest["lng"] - amb["lng"]) * t
        if 0 < i < steps:
            lat += (rng.random() - 0.5) * 0.006
            lng += (rng.random() - 0.5) * 0.006
        waypoints.append({
            "index": i,
            "lat": round(lat, 5),
            "lng": round(lng, 5),
            "eta_min": round(total_eta * (1 - t), 1),
            "progress_pct": round(t * 100, 1),
            "maneuver": _route_maneuver(i, steps + 1, dest["short_name"]),
            "distance_remaining_km": round(dist * (1 - t), 2),
        })
    return {
        "ambulance": {
            "resource_id": amb["resource_id"],
            "unit": amb["unit"],
            "crew": amb["crew"],
            "lat": amb["lat"],
            "lng": amb["lng"],
            "status": amb["status"],
        },
        "destination": {
            "resource_id": dest["resource_id"],
            "name": dest["name"],
            "short_name": dest["short_name"],
            "lat": dest["lat"],
            "lng": dest["lng"],
            "icu_available": dest.get("icu_available", 0),
            "icu_total": dest.get("icu_total", 0),
            "er_wait_min": dest.get("er_wait_min", 0),
        },
        "route": {
            "total_distance_km": dist,
            "total_eta_min": total_eta,
            "traffic_factor": dest.get("traffic_factor", 1.0),
            "waypoints": waypoints,
        },
    }


# ------------------------------- Video Consult -------------------------------


@api_router.post("/consult/start")
async def consult_start(
    payload: ConsultStartRequest,
    authorization: Optional[str] = Header(default=None),
) -> Dict[str, Any]:
    user = await current_user(authorization)
    specialist = await db.specialists.find_one({"resource_id": payload.specialist_id}, {"_id": 0})
    if not specialist:
        raise HTTPException(status_code=404, detail="Specialist not found")
    patient = None
    if payload.patient_id:
        patient = await db.patients.find_one({"resource_id": payload.patient_id}, {"_id": 0})
    consult_id = f"cs_{uuid.uuid4().hex[:12]}"
    room_id = f"medisync-{uuid.uuid4().hex[:16]}"
    doc = {
        "consult_id": consult_id,
        "room_id": room_id,
        "specialist_id": payload.specialist_id,
        "specialist_name": specialist["name"],
        "specialist_specialty": specialist["specialty"],
        "specialist_initials": specialist["initials"],
        "patient_id": payload.patient_id,
        "patient_summary": (
            f"{patient['name']} · {patient['age']}yo · {patient['condition']}"
            if patient else "New emergency consult"
        ),
        "reason": payload.reason,
        "initiator_id": user["user_id"],
        "initiator_name": user["name"],
        "initiator_role": user.get("role", "coordinator"),
        "status": "active",
        "started_at": now_utc(),
    }
    await db.consults.insert_one(doc.copy())
    return {k: v for k, v in doc.items() if k != "_id"}


@api_router.get("/consult/active")
async def consult_active(authorization: Optional[str] = Header(default=None)) -> List[Dict[str, Any]]:
    user = await current_user(authorization)
    query: Dict[str, Any] = {"status": "active"}
    if user.get("role") == "specialist":
        query["specialist_id"] = user.get("facility_id")
    docs = await db.consults.find(query, {"_id": 0}).sort("started_at", -1).to_list(20)
    return docs


@api_router.post("/consult/end")
async def consult_end(
    payload: ConsultEndRequest,
    authorization: Optional[str] = Header(default=None),
) -> Dict[str, bool]:
    await current_user(authorization)
    result = await db.consults.update_one(
        {"consult_id": payload.consult_id, "status": "active"},
        {"$set": {"status": "ended", "ended_at": now_utc()}},
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Consult not found or already ended")
    return {"ok": True}


# ------------------------------- App -------------------------------

app = FastAPI(title="Medisync API")
app.include_router(api_router)
app.add_middleware(
    CORSMiddleware, allow_credentials=True,
    allow_origins=["*"], allow_methods=["*"], allow_headers=["*"],
)


@app.on_event("startup")
async def startup() -> None:
    await ensure_seed_data()


@app.on_event("shutdown")
async def shutdown_db_client() -> None:
    client.close()
