"""Medisync backend API regression suite."""
import os
import uuid
import pytest
import requests

BASE_URL = os.environ.get("EXPO_BACKEND_URL") or os.environ.get("EXPO_PUBLIC_BACKEND_URL") or "https://care-connect-954.preview.emergentagent.com"
BASE_URL = BASE_URL.rstrip("/")

DEMO_USERS = [
    ("coordinator@medisync.app", "coordinator"),
    ("hospital@medisync.app", "hospital_admin"),
    ("ambulance@medisync.app", "ambulance"),
    ("specialist@medisync.app", "specialist"),
    ("doctor@medisync.app", "doctor"),
]
PASSWORD = "MediSync123!"


@pytest.fixture(scope="session")
def s():
    sess = requests.Session()
    sess.headers.update({"Content-Type": "application/json"})
    return sess


@pytest.fixture(scope="session")
def tokens(s):
    out = {}
    for email, role in DEMO_USERS:
        r = s.post(f"{BASE_URL}/api/auth/login", json={"email": email, "password": PASSWORD})
        assert r.status_code == 200, f"{email} login failed: {r.status_code} {r.text}"
        data = r.json()
        assert data["user"]["role"] == role, f"{email} role mismatch: {data['user']['role']}"
        out[role] = data["session_token"]
    return out


def auth(token):
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}


# -------- Auth --------
class TestAuth:
    def test_login_all_demo_users(self, tokens):
        assert set(tokens.keys()) == {"coordinator", "hospital_admin", "ambulance", "specialist", "doctor"}

    def test_login_bad_password(self, s):
        r = s.post(f"{BASE_URL}/api/auth/login", json={"email": "coordinator@medisync.app", "password": "wrong"})
        assert r.status_code == 401

    def test_register_and_duplicate(self, s):
        email = f"test_{uuid.uuid4().hex[:8]}@medisync.app"
        r = s.post(f"{BASE_URL}/api/auth/register", json={
            "name": "TEST User", "email": email, "password": "TestPass123!", "role": "coordinator"
        })
        assert r.status_code == 200
        data = r.json()
        assert "session_token" in data and data["user"]["email"] == email
        # duplicate
        r2 = s.post(f"{BASE_URL}/api/auth/register", json={
            "name": "TEST User", "email": email, "password": "TestPass123!"
        })
        assert r2.status_code == 409

    def test_me_valid_and_invalid(self, s, tokens):
        r = s.get(f"{BASE_URL}/api/auth/me", headers=auth(tokens["coordinator"]))
        assert r.status_code == 200
        assert r.json()["role"] == "coordinator"
        r2 = s.get(f"{BASE_URL}/api/auth/me")
        assert r2.status_code == 401
        r3 = s.get(f"{BASE_URL}/api/auth/me", headers={"Authorization": "Bearer bogus"})
        assert r3.status_code == 401

    def test_logout_invalidates(self, s):
        r = s.post(f"{BASE_URL}/api/auth/login", json={"email": "doctor@medisync.app", "password": PASSWORD})
        tok = r.json()["session_token"]
        assert s.get(f"{BASE_URL}/api/auth/me", headers=auth(tok)).status_code == 200
        assert s.post(f"{BASE_URL}/api/auth/logout", headers=auth(tok)).status_code == 200
        assert s.get(f"{BASE_URL}/api/auth/me", headers=auth(tok)).status_code == 401


# -------- Role dashboards --------
class TestDashboards:
    def test_coordinator(self, s, tokens):
        r = s.get(f"{BASE_URL}/api/dashboard", headers=auth(tokens["coordinator"]))
        assert r.status_code == 200
        d = r.json()
        assert d["role"] == "coordinator"
        m = d["metrics"]
        for k in ["available_beds", "total_beds", "available_icu", "total_icu",
                  "active_units", "low_supplies", "hospitals_online"]:
            assert k in m, f"missing metric {k}"
        assert isinstance(d["hospitals"], list) and len(d["hospitals"]) >= 1
        assert isinstance(d["ambulances"], list)
        assert isinstance(d["patients"], list)
        assert isinstance(d["alerts"], list)

    def test_hospital_admin(self, s, tokens):
        d = s.get(f"{BASE_URL}/api/dashboard", headers=auth(tokens["hospital_admin"])).json()
        assert d["role"] == "hospital_admin"
        assert "hospital" in d and "inbound_ambulances" in d
        assert "inbound" in d["metrics"]

    def test_ambulance(self, s, tokens):
        d = s.get(f"{BASE_URL}/api/dashboard", headers=auth(tokens["ambulance"])).json()
        assert d["role"] == "ambulance"
        assert "ambulance" in d and "patient" in d and "destination" in d
        assert "eta_min" in d["metrics"]

    def test_specialist(self, s, tokens):
        d = s.get(f"{BASE_URL}/api/dashboard", headers=auth(tokens["specialist"])).json()
        assert d["role"] == "specialist"
        assert "specialist" in d and "consults" in d
        assert "pending_consults" in d["metrics"]

    def test_doctor(self, s, tokens):
        d = s.get(f"{BASE_URL}/api/dashboard", headers=auth(tokens["doctor"])).json()
        assert d["role"] == "doctor"
        assert "hospital" in d and "patients" in d
        assert "active_cases" in d["metrics"]


# -------- Resources --------
class TestResources:
    def test_hospitals(self, s, tokens):
        r = s.get(f"{BASE_URL}/api/hospitals", headers=auth(tokens["coordinator"]))
        assert r.status_code == 200
        data = r.json()
        assert len(data) == 80
        for h in data:
            for k in ["lat", "lng", "level", "blood", "specialists"]:
                assert k in h, f"hospital missing {k}: {h.get('resource_id')}"

    def test_ambulances(self, s, tokens):
        data = s.get(f"{BASE_URL}/api/ambulances", headers=auth(tokens["coordinator"])).json()
        assert len(data) == 4
        for a in data:
            assert "lat" in a and "lng" in a and "patient_on_board" in a

    def test_specialists(self, s, tokens):
        data = s.get(f"{BASE_URL}/api/specialists", headers=auth(tokens["coordinator"])).json()
        assert len(data) == 5

    def test_supplies(self, s, tokens):
        data = s.get(f"{BASE_URL}/api/supplies", headers=auth(tokens["coordinator"])).json()
        assert len(data) == 7
        assert any(x["status"] == "low" for x in data)

    def test_patients(self, s, tokens):
        data = s.get(f"{BASE_URL}/api/patients", headers=auth(tokens["coordinator"])).json()
        assert len(data) == 3
        for p in data:
            assert "fhir_id" in p and "severity" in p

    def test_forecast(self, s, tokens):
        d = s.get(f"{BASE_URL}/api/analytics/forecast", headers=auth(tokens["coordinator"])).json()
        assert len(d["forecasts"]) == 4
        assert "high_risk" in d["summary"] and "medium_risk" in d["summary"] and "low_risk" in d["summary"]
        assert "model" in d


# -------- Supply update --------
class TestSupplyUpdate:
    def test_update_flips_status(self, s, tokens):
        # find a supply, set below threshold then above
        sup = s.get(f"{BASE_URL}/api/supplies", headers=auth(tokens["coordinator"])).json()
        target = next(x for x in sup if x["resource_id"] == "sup-01")
        threshold = target["threshold"]
        # low
        r1 = s.patch(f"{BASE_URL}/api/supplies/sup-01", json={"quantity": threshold - 1},
                     headers=auth(tokens["coordinator"]))
        assert r1.status_code == 200 and r1.json()["status"] == "low"
        # stable
        r2 = s.patch(f"{BASE_URL}/api/supplies/sup-01", json={"quantity": threshold + 5},
                     headers=auth(tokens["coordinator"]))
        assert r2.status_code == 200 and r2.json()["status"] == "stable"
        # verify persistence
        after = s.get(f"{BASE_URL}/api/supplies", headers=auth(tokens["coordinator"])).json()
        row = next(x for x in after if x["resource_id"] == "sup-01")
        assert row["quantity"] == threshold + 5 and row["status"] == "stable"


# -------- Triage --------
class TestTriage:
    def test_critical(self, s, tokens):
        payload = {"chief_complaint": "unresponsive after MVA", "systolic_bp": 70,
                   "heart_rate": 140, "respiratory_rate": 34, "spo2": 82,
                   "consciousness": "unresponsive", "trauma": True, "age": 45}
        r = s.post(f"{BASE_URL}/api/triage", json=payload, headers=auth(tokens["coordinator"]))
        assert r.status_code == 200
        d = r.json()
        a = d["assessment"]
        assert a["severity"] == "critical"
        assert isinstance(a["score"], int) and a["score"] >= 8
        assert isinstance(a["flags"], list)
        for k in ["recommend_icu", "recommend_ventilator", "recommend_specialty", "recommend_blood_ready"]:
            assert k in a
        assert isinstance(d["narrative"], str) and len(d["narrative"]) > 5
        assert "engine" in d

    def test_stable(self, s, tokens):
        payload = {"chief_complaint": "mild headache", "systolic_bp": 120,
                   "heart_rate": 75, "respiratory_rate": 16, "spo2": 98,
                   "consciousness": "alert", "trauma": False, "age": 30}
        r = s.post(f"{BASE_URL}/api/triage", json=payload, headers=auth(tokens["coordinator"]))
        assert r.status_code == 200
        assert r.json()["assessment"]["severity"] == "stable"


# -------- Match --------
class TestMatch:
    def test_match_with_explain(self, s, tokens):
        payload = {"required_care": "ICU", "blood_type": "O+", "specialty_needed": "Trauma",
                   "oxygen_required": True, "explain": True}
        r = s.post(f"{BASE_URL}/api/match", json=payload, headers=auth(tokens["coordinator"]))
        assert r.status_code == 200, r.text
        d = r.json()
        assert len(d["matches"]) == 80
        top = d["top_match"]
        assert 0 <= top["score"] <= 100
        for k in ["distance", "capacity", "specialist", "blood", "readiness"]:
            assert k in top["breakdown"]
            b = top["breakdown"][k]
            assert "points" in b and "max" in b and "detail" in b
        assert "eta_min" in top and "distance_km" in top
        # sort order desc
        scores = [m["score"] for m in d["matches"]]
        assert scores == sorted(scores, reverse=True)
        assert isinstance(d["explanation"], str) and len(d["explanation"]) > 5
        assert "Claude" in d["engine"] or "Sonnet" in d["engine"]

    def test_match_no_explain(self, s, tokens):
        payload = {"required_care": "ICU", "blood_type": "O+", "explain": False}
        r = s.post(f"{BASE_URL}/api/match", json=payload, headers=auth(tokens["coordinator"]))
        assert r.status_code == 200
        d = r.json()
        assert "deterministic" in d["engine"].lower()
        assert isinstance(d["explanation"], str)
