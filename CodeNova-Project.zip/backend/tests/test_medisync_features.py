"""Medisync new feature regression: Disaster Mode, Ambulance Route, Video Consult.
Also validates that the existing endpoints still work with the 80-hospital Nashik dataset."""
import os
import pytest
import requests

BASE_URL = (
    os.environ.get("EXPO_BACKEND_URL")
    or os.environ.get("EXPO_PUBLIC_BACKEND_URL")
    or "https://care-connect-954.preview.emergentagent.com"
).rstrip("/")

PASSWORD = "MediSync123!"


@pytest.fixture(scope="session")
def s():
    sess = requests.Session()
    sess.headers.update({"Content-Type": "application/json"})
    return sess


@pytest.fixture(scope="session")
def tokens(s):
    out = {}
    for email, role in [
        ("coordinator@medisync.app", "coordinator"),
        ("hospital@medisync.app", "hospital_admin"),
        ("ambulance@medisync.app", "ambulance"),
        ("specialist@medisync.app", "specialist"),
        ("doctor@medisync.app", "doctor"),
    ]:
        r = s.post(f"{BASE_URL}/api/auth/login", json={"email": email, "password": PASSWORD})
        assert r.status_code == 200, f"{email} login failed: {r.status_code} {r.text}"
        data = r.json()
        assert data["user"]["role"] == role
        out[role] = data["session_token"]
    return out


def auth(token):
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}


# -------- Hospitals (80-row Nashik seed) --------
class TestHospitalsSeed:
    def test_returns_80_with_required_keys(self, s, tokens):
        r = s.get(f"{BASE_URL}/api/hospitals", headers=auth(tokens["coordinator"]))
        assert r.status_code == 200
        data = r.json()
        assert len(data) == 80, f"expected 80 hospitals, got {len(data)}"
        for h in data:
            for k in ["lat", "lng", "level", "emergency_status", "specialists"]:
                assert k in h, f"hospital {h.get('resource_id')} missing {k}"
            assert h["emergency_status"] in {"NORMAL", "BUSY", "CRITICAL"}, h["emergency_status"]
            assert isinstance(h["specialists"], list)

    def test_contains_apollo_or_breech(self, s, tokens):
        data = s.get(f"{BASE_URL}/api/hospitals", headers=auth(tokens["coordinator"])).json()
        names = " | ".join(h["name"].lower() for h in data)
        assert ("apollo" in names) or ("breech" in names), \
            "expected 'Apollo' or 'Breech candy HOSPITAL' in seed"


# -------- Disaster Mode --------
class TestDisaster:
    def test_simulate_shape(self, s, tokens):
        payload = {"scenario_name": "Highway pileup",
                   "critical": 8, "urgent": 20, "moderate": 30,
                   "radius_km": 15, "activate": False}
        r = s.post(f"{BASE_URL}/api/disaster/simulate", json=payload, headers=auth(tokens["coordinator"]))
        assert r.status_code == 200, r.text
        d = r.json()
        for k in ["scenario_id", "scenario_name", "patients", "unassigned",
                  "hospitals_used", "hospitals_in_range", "total_assigned", "plan"]:
            assert k in d, f"missing key {k}"
        assert d["scenario_name"] == "Highway pileup"
        for k in ["critical", "urgent", "moderate", "total"]:
            assert k in d["patients"]
        assert d["patients"]["total"] == 58
        total_patients = 58
        assert d["total_assigned"] <= total_patients
        assert isinstance(d["plan"], list) and len(d["plan"]) > 0
        totals = []
        for item in d["plan"]:
            for k in ["hospital_id", "hospital_name", "distance_km", "eta_min",
                      "assigned", "capacity_after", "emergency_status"]:
                assert k in item, f"plan item missing {k}"
            for k in ["critical", "urgent", "moderate", "total"]:
                assert k in item["assigned"]
            for k in ["icu_remaining", "ventilator_remaining", "beds_remaining"]:
                assert k in item["capacity_after"]
            assert item["assigned"]["total"] > 0
            totals.append(item["assigned"]["total"])
        # sorted desc by assigned.total
        assert totals == sorted(totals, reverse=True), f"plan not sorted desc: {totals}"

    def test_activate_and_end_flow(self, s, tokens):
        # start clean
        s.post(f"{BASE_URL}/api/disaster/end", headers=auth(tokens["coordinator"]))
        payload = {"scenario_name": "TEST activation", "critical": 3, "urgent": 5,
                   "moderate": 8, "radius_km": 20, "activate": True}
        r = s.post(f"{BASE_URL}/api/disaster/simulate", json=payload, headers=auth(tokens["coordinator"]))
        assert r.status_code == 200
        assert r.json().get("active") is True
        # active
        a = s.get(f"{BASE_URL}/api/disaster/active", headers=auth(tokens["coordinator"])).json()
        assert a["active"] is True and a["disaster"] is not None
        assert a["disaster"]["scenario_name"] == "TEST activation"
        # end
        e = s.post(f"{BASE_URL}/api/disaster/end", headers=auth(tokens["coordinator"]))
        assert e.status_code == 200
        a2 = s.get(f"{BASE_URL}/api/disaster/active", headers=auth(tokens["coordinator"])).json()
        assert a2["active"] is False and a2["disaster"] is None

    def test_no_hospitals_in_radius(self, s, tokens):
        payload = {"scenario_name": "Micro radius", "critical": 1, "urgent": 1,
                   "moderate": 1, "radius_km": 0.01, "activate": False}
        # radius has ge=1.0 constraint per model; expect 422 OR 400. Attempt with 1.0 first
        # to satisfy the spec's intent, but our schema requires ge=1.0. So this should 422.
        r = s.post(f"{BASE_URL}/api/disaster/simulate", json=payload, headers=auth(tokens["coordinator"]))
        # Our Pydantic model rejects <1; either 400 or 422 acceptable per intent.
        assert r.status_code in (400, 422), r.text

    def test_distribution_correctness_overflow(self, s, tokens):
        payload = {"scenario_name": "Overflow", "critical": 500, "urgent": 0,
                   "moderate": 0, "radius_km": 25, "activate": False}
        # critical is capped at 200 by our Pydantic model; use 200 to force overflow.
        payload["critical"] = 200
        r = s.post(f"{BASE_URL}/api/disaster/simulate", json=payload, headers=auth(tokens["coordinator"]))
        assert r.status_code == 200, r.text
        d = r.json()
        # Critical must be assigned only where icu or vent capacity was available.
        # If unassigned_critical > 0, means total_assigned == sum of icu+vent capacities.
        assert d["unassigned"]["critical"] >= 0
        assert d["total_assigned"] + sum(d["unassigned"].values()) == d["patients"]["total"]


# -------- Ambulance Route --------
class TestAmbulanceRoute:
    def test_amb01_route_shape(self, s, tokens):
        r = s.get(f"{BASE_URL}/api/ambulances/amb-01/route", headers=auth(tokens["coordinator"]))
        assert r.status_code == 200, r.text
        d = r.json()
        for k in ["ambulance", "destination", "route"]:
            assert k in d
        for k in ["unit", "crew", "lat", "lng", "status"]:
            assert k in d["ambulance"]
        for k in ["name", "short_name", "lat", "lng", "icu_available", "icu_total", "er_wait_min"]:
            assert k in d["destination"]
        route = d["route"]
        for k in ["total_distance_km", "total_eta_min", "traffic_factor", "waypoints"]:
            assert k in route
        wps = route["waypoints"]
        assert len(wps) == 13, f"expected 13 waypoints, got {len(wps)}"
        # first & last
        assert wps[0]["progress_pct"] == 0
        assert wps[-1]["progress_pct"] == 100
        # ETA monotonically non-increasing
        etas = [w["eta_min"] for w in wps]
        for i in range(1, len(etas)):
            assert etas[i] <= etas[i - 1] + 0.01, f"eta increased at {i}: {etas}"
        # required per-waypoint fields
        for w in wps:
            for k in ["index", "lat", "lng", "eta_min", "progress_pct", "maneuver", "distance_remaining_km"]:
                assert k in w

    def test_amb02_no_destination(self, s, tokens):
        r = s.get(f"{BASE_URL}/api/ambulances/amb-02/route", headers=auth(tokens["coordinator"]))
        assert r.status_code == 400, r.text
        assert "no active destination" in r.json()["detail"].lower()

    def test_unknown_ambulance(self, s, tokens):
        r = s.get(f"{BASE_URL}/api/ambulances/does-not-exist/route",
                  headers=auth(tokens["coordinator"]))
        assert r.status_code == 404


# -------- Video Consult --------
class TestConsult:
    def test_start_success_shape(self, s, tokens):
        r = s.post(f"{BASE_URL}/api/consult/start",
                   json={"specialist_id": "spec-01", "patient_id": "pat-02",
                         "reason": "Trauma consult"},
                   headers=auth(tokens["coordinator"]))
        assert r.status_code == 200, r.text
        d = r.json()
        for k in ["consult_id", "room_id", "specialist_id", "specialist_name",
                  "specialist_specialty", "specialist_initials", "patient_summary",
                  "reason", "initiator_id", "initiator_name", "initiator_role",
                  "status", "started_at"]:
            assert k in d, f"missing {k}"
        assert d["specialist_id"] == "spec-01"
        assert d["status"] == "active"
        assert d["reason"] == "Trauma consult"
        assert "T. Nakamura" in d["patient_summary"] or "polytrauma" in d["patient_summary"].lower()
        # end for cleanup
        s.post(f"{BASE_URL}/api/consult/end", json={"consult_id": d["consult_id"]},
               headers=auth(tokens["coordinator"]))

    def test_start_unknown_specialist(self, s, tokens):
        r = s.post(f"{BASE_URL}/api/consult/start",
                   json={"specialist_id": "does-not-exist", "reason": "x"},
                   headers=auth(tokens["coordinator"]))
        assert r.status_code == 404

    def test_active_scoped_by_role(self, s, tokens):
        # Start one from coordinator on spec-01, one on spec-02.
        c1 = s.post(f"{BASE_URL}/api/consult/start",
                    json={"specialist_id": "spec-01", "reason": "A"},
                    headers=auth(tokens["coordinator"])).json()
        c2 = s.post(f"{BASE_URL}/api/consult/start",
                    json={"specialist_id": "spec-02", "reason": "B"},
                    headers=auth(tokens["coordinator"])).json()
        # coordinator sees both
        coord_list = s.get(f"{BASE_URL}/api/consult/active",
                           headers=auth(tokens["coordinator"])).json()
        ids = {c["consult_id"] for c in coord_list}
        assert c1["consult_id"] in ids and c2["consult_id"] in ids
        # specialist (facility_id=spec-01) sees only spec-01 consults
        spec_list = s.get(f"{BASE_URL}/api/consult/active",
                          headers=auth(tokens["specialist"])).json()
        spec_ids = {c["consult_id"] for c in spec_list}
        assert c1["consult_id"] in spec_ids
        assert c2["consult_id"] not in spec_ids
        for c in spec_list:
            assert c["specialist_id"] == "spec-01"
        # cleanup
        for cid in [c1["consult_id"], c2["consult_id"]]:
            s.post(f"{BASE_URL}/api/consult/end", json={"consult_id": cid},
                   headers=auth(tokens["coordinator"]))

    def test_end_and_reend(self, s, tokens):
        c = s.post(f"{BASE_URL}/api/consult/start",
                   json={"specialist_id": "spec-03", "reason": "End test"},
                   headers=auth(tokens["coordinator"])).json()
        e = s.post(f"{BASE_URL}/api/consult/end",
                   json={"consult_id": c["consult_id"]},
                   headers=auth(tokens["coordinator"]))
        assert e.status_code == 200
        # not in active anymore
        active = s.get(f"{BASE_URL}/api/consult/active",
                       headers=auth(tokens["coordinator"])).json()
        assert c["consult_id"] not in {a["consult_id"] for a in active}
        # re-end should 404
        e2 = s.post(f"{BASE_URL}/api/consult/end",
                    json={"consult_id": c["consult_id"]},
                    headers=auth(tokens["coordinator"]))
        assert e2.status_code == 404
        e3 = s.post(f"{BASE_URL}/api/consult/end",
                    json={"consult_id": "cs_ghost"},
                    headers=auth(tokens["coordinator"]))
        assert e3.status_code == 404


# -------- Regression: /match still works with 80 hospitals --------
class TestMatchWithLargeSeed:
    def test_match_scales(self, s, tokens):
        r = s.post(f"{BASE_URL}/api/match",
                   json={"required_care": "ICU", "blood_type": "O+",
                         "specialty_needed": "Trauma",
                         "patient_lat": 19.9975, "patient_lng": 73.7898,
                         "explain": False},
                   headers=auth(tokens["coordinator"]))
        assert r.status_code == 200, r.text
        d = r.json()
        assert len(d["matches"]) == 80
        top = d["top_match"]
        assert 0 <= top["score"] <= 100
        for k in ["distance", "capacity", "specialist", "blood", "readiness"]:
            assert k in top["breakdown"]
