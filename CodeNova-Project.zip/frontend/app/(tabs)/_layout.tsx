import { MaterialCommunityIcons } from "@expo/vector-icons";
import { Tabs } from "expo-router";
import { Platform } from "react-native";

import { useAuth } from "@/src/auth";
import { useTheme } from "@/src/theme";

type IconName = keyof typeof MaterialCommunityIcons.glyphMap;

type TabDef = { name: string; title: string; icon: IconName; testID: string };

const TABS_BY_ROLE: Record<string, TabDef[]> = {
  coordinator: [
    { name: "dashboard", title: "Command", icon: "view-dashboard-outline", testID: "tab-dashboard" },
    { name: "hospitals", title: "Hospitals", icon: "hospital-building", testID: "tab-hospitals" },
    { name: "operations", title: "Tracking", icon: "radar", testID: "tab-operations" },
    { name: "analytics", title: "Forecast", icon: "chart-line", testID: "tab-analytics" },
  ],
  admin: [
    { name: "dashboard", title: "Command", icon: "view-dashboard-outline", testID: "tab-dashboard" },
    { name: "hospitals", title: "Hospitals", icon: "hospital-building", testID: "tab-hospitals" },
    { name: "operations", title: "Tracking", icon: "radar", testID: "tab-operations" },
    { name: "analytics", title: "Forecast", icon: "chart-line", testID: "tab-analytics" },
  ],
  hospital_admin: [
    { name: "dashboard", title: "Facility", icon: "hospital-building", testID: "tab-dashboard" },
    { name: "operations", title: "Inbound", icon: "ambulance", testID: "tab-operations" },
    { name: "supplies", title: "Supplies", icon: "medical-bag", testID: "tab-supplies" },
    { name: "analytics", title: "Forecast", icon: "chart-line", testID: "tab-analytics" },
  ],
  ambulance: [
    { name: "dashboard", title: "Unit", icon: "ambulance", testID: "tab-dashboard" },
    { name: "operations", title: "Route", icon: "map-marker-path", testID: "tab-operations" },
    { name: "hospitals", title: "Hospitals", icon: "hospital-building", testID: "tab-hospitals" },
  ],
  specialist: [
    { name: "dashboard", title: "On-Call", icon: "stethoscope", testID: "tab-dashboard" },
    { name: "operations", title: "Consults", icon: "account-heart", testID: "tab-operations" },
    { name: "hospitals", title: "Facilities", icon: "hospital-building", testID: "tab-hospitals" },
  ],
  doctor: [
    { name: "dashboard", title: "Ward", icon: "heart-pulse", testID: "tab-dashboard" },
    { name: "operations", title: "Inbound", icon: "ambulance", testID: "tab-operations" },
    { name: "supplies", title: "Supplies", icon: "medical-bag", testID: "tab-supplies" },
  ],
};

const ALL_TAB_NAMES = ["dashboard", "hospitals", "operations", "supplies", "analytics"];

export default function TabsLayout() {
  const { colors } = useTheme();
  const { user } = useAuth();
  const role = user?.role ?? "coordinator";
  const tabs = TABS_BY_ROLE[role] ?? TABS_BY_ROLE.coordinator;
  const visibleNames = new Set(tabs.map((t) => t.name));

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.brandPrimary,
        tabBarInactiveTintColor: colors.muted,
        tabBarStyle: {
          backgroundColor: colors.surfaceSecondary,
          borderTopColor: colors.divider,
          ...(Platform.OS === "web" ? { height: 64 } : {}),
        },
        tabBarItemStyle: { alignSelf: "center" },
        tabBarLabelStyle: { fontSize: 10, fontWeight: "800" },
      }}
    >
      {ALL_TAB_NAMES.map((name) => {
        const def = tabs.find((t) => t.name === name);
        if (!visibleNames.has(name) || !def) {
          return <Tabs.Screen key={name} name={name} options={{ href: null }} />;
        }
        return (
          <Tabs.Screen
            key={name}
            name={name}
            options={{
              title: def.title,
              tabBarButtonTestID: def.testID,
              tabBarIcon: ({ color, size }) => (
                <MaterialCommunityIcons name={def.icon} color={color} size={size} />
              ),
            }}
          />
        );
      })}
    </Tabs>
  );
}
