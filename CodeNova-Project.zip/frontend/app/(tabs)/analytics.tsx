import { MaterialCommunityIcons } from "@expo/vector-icons";
import { useEffect, useState } from "react";
import { ActivityIndicator, RefreshControl, ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api, Forecast } from "@/src/api";
import { makeStyles, useTheme } from "@/src/theme";

export default function AnalyticsScreen() {
  const { colors } = useTheme();
  const styles = useStyles();
  const insets = useSafeAreaInsets();
  const [forecasts, setForecasts] = useState<Forecast[]>([]);
  const [summary, setSummary] = useState<{ high_risk: number; medium_risk: number; low_risk: number } | null>(null);
  const [model, setModel] = useState("");
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");

  const load = async () => {
    try {
      setError("");
      const data = await api.forecasts();
      setForecasts(data.forecasts);
      setSummary(data.summary);
      setModel(data.model);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Forecast unavailable");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    void load();
  }, []);

  return (
    <View style={[styles.root, { paddingTop: insets.top }]}>
      <ScrollView
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => {
              setRefreshing(true);
              void load();
            }}
            tintColor={colors.brandPrimary}
          />
        }
        contentContainerStyle={styles.content}
      >
        <View style={styles.header}>
          <View style={{ flex: 1 }}>
            <Text style={styles.kicker}>PREDICTIVE ANALYTICS</Text>
            <Text style={styles.title}>24-hour forecast</Text>
            <Text style={styles.muted}>{model || "Loading model…"}</Text>
          </View>
          <View style={styles.aiMark}>
            <MaterialCommunityIcons name="chart-line" size={22} color={colors.brandPrimary} />
          </View>
        </View>

        {summary ? (
          <View style={styles.summaryRow}>
            <SummaryCard label="HIGH RISK" value={summary.high_risk} color={colors.error} />
            <SummaryCard label="MEDIUM" value={summary.medium_risk} color={colors.warning} />
            <SummaryCard label="LOW" value={summary.low_risk} color={colors.success} />
          </View>
        ) : null}

        {loading ? (
          <View style={styles.center}>
            <ActivityIndicator size="large" color={colors.brandPrimary} />
            <Text style={styles.muted}>Computing regional demand…</Text>
          </View>
        ) : error ? (
          <Text style={styles.error}>{error}</Text>
        ) : (
          <View style={styles.list}>
            {forecasts.map((f) => (
              <ForecastCard key={f.resource_id} forecast={f} />
            ))}
          </View>
        )}
      </ScrollView>
    </View>
  );
}

function SummaryCard({ label, value, color }: { label: string; value: number; color: string }) {
  const styles = useStyles();
  return (
    <View style={styles.summaryCard}>
      <Text style={[styles.summaryValue, { color }]}>{value}</Text>
      <Text style={styles.summaryLabel}>{label}</Text>
    </View>
  );
}

function ForecastCard({ forecast }: { forecast: Forecast }) {
  const { colors } = useTheme();
  const styles = useStyles();
  const riskColor =
    forecast.risk === "high" ? colors.error : forecast.risk === "medium" ? colors.warning : colors.success;
  const trend6h = forecast.predicted_6h - forecast.current;
  const trend24h = forecast.predicted_24h - forecast.current;
  return (
    <View style={styles.card} testID={`forecast-${forecast.resource_id}`}>
      <View style={styles.cardTop}>
        <View style={[styles.riskDot, { backgroundColor: riskColor }]} />
        <View style={{ flex: 1 }}>
          <Text style={styles.cardTitle}>{forecast.resource}</Text>
          <Text style={styles.muted}>{forecast.region}</Text>
        </View>
        <View style={[styles.badge, { backgroundColor: riskColor }]}>
          <Text style={styles.badgeText}>{forecast.risk.toUpperCase()}</Text>
        </View>
      </View>

      <View style={styles.timeline}>
        <TimelinePoint label="NOW" value={forecast.current} trend={0} />
        <View style={styles.arrow}>
          <MaterialCommunityIcons name="arrow-right" size={16} color={colors.muted} />
        </View>
        <TimelinePoint label="+6H" value={forecast.predicted_6h} trend={trend6h} />
        <View style={styles.arrow}>
          <MaterialCommunityIcons name="arrow-right" size={16} color={colors.muted} />
        </View>
        <TimelinePoint label="+24H" value={forecast.predicted_24h} trend={trend24h} />
      </View>

      <View style={styles.adviceBox}>
        <MaterialCommunityIcons name="lightbulb-on-outline" size={16} color={colors.brandPrimary} />
        <Text style={styles.adviceText}>{forecast.advice}</Text>
      </View>
    </View>
  );
}

function TimelinePoint({ label, value, trend }: { label: string; value: number; trend: number }) {
  const { colors } = useTheme();
  const styles = useStyles();
  const trendColor = trend < 0 ? colors.error : trend > 0 ? colors.success : colors.muted;
  return (
    <View style={styles.tlPoint}>
      <Text style={styles.tlValue}>{value}</Text>
      <Text style={styles.tlLabel}>{label}</Text>
      {trend !== 0 ? (
        <Text style={[styles.tlTrend, { color: trendColor }]}>
          {trend > 0 ? "+" : ""}
          {trend}
        </Text>
      ) : null}
    </View>
  );
}

const useStyles = makeStyles((colors) => ({
  root: { flex: 1, backgroundColor: colors.surface },
  content: { padding: 20, paddingBottom: 28, gap: 16, maxWidth: 900, width: "100%", alignSelf: "center" },
  header: { flexDirection: "row", alignItems: "flex-start", gap: 12 },
  kicker: { color: colors.brandPrimary, fontSize: 10, fontWeight: "900", letterSpacing: 1.4, marginBottom: 8 },
  title: { color: colors.onSurface, fontSize: 28, fontWeight: "900" },
  muted: { color: colors.muted, fontSize: 12, lineHeight: 18 },
  aiMark: {
    width: 44, height: 44, borderRadius: 14,
    backgroundColor: colors.brandTertiary,
    alignItems: "center", justifyContent: "center",
  },
  summaryRow: { flexDirection: "row", gap: 10 },
  summaryCard: {
    flex: 1, padding: 14, borderRadius: 14,
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1, borderColor: colors.border, gap: 4,
  },
  summaryValue: { fontSize: 26, fontWeight: "900" },
  summaryLabel: { color: colors.muted, fontSize: 10, fontWeight: "900", letterSpacing: 0.8 },
  list: { gap: 12 },
  card: {
    padding: 14, borderRadius: 16,
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1, borderColor: colors.border, gap: 14,
  },
  cardTop: { flexDirection: "row", alignItems: "center", gap: 10 },
  riskDot: { width: 12, height: 12, borderRadius: 6 },
  cardTitle: { color: colors.onSurface, fontSize: 15, fontWeight: "800" },
  badge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 999 },
  badgeText: { color: colors.onError, fontSize: 9, fontWeight: "900", letterSpacing: 0.8 },
  timeline: { flexDirection: "row", alignItems: "center", gap: 8 },
  tlPoint: {
    flex: 1, padding: 10, borderRadius: 10,
    backgroundColor: colors.surfaceTertiary, alignItems: "center", gap: 2,
  },
  tlValue: { color: colors.onSurface, fontSize: 20, fontWeight: "900" },
  tlLabel: { color: colors.muted, fontSize: 9, fontWeight: "800", letterSpacing: 0.6 },
  tlTrend: { fontSize: 11, fontWeight: "800" },
  arrow: { alignItems: "center", justifyContent: "center" },
  adviceBox: {
    flexDirection: "row", gap: 8, padding: 10,
    borderRadius: 10, backgroundColor: colors.brandTertiary,
    alignItems: "flex-start",
  },
  adviceText: { color: colors.onSurface, fontSize: 12, lineHeight: 18, flex: 1 },
  center: { alignItems: "center", padding: 46, gap: 14 },
  error: { color: colors.error, fontSize: 13 },
}));
