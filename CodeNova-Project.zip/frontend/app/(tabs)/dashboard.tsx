import { MaterialCommunityIcons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  useWindowDimensions,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import {
  Alert,
  Ambulance,
  api,
  Dashboard,
  Hospital,
  Patient,
} from "@/src/api";
import { useAuth } from "@/src/auth";
import { ConsultSheet } from "@/src/components/consult-sheet";
import { makeStyles, useTheme } from "@/src/theme";

type IconName = keyof typeof MaterialCommunityIcons.glyphMap;

export default function DashboardScreen() {
  const { colors } = useTheme();
  const styles = useStyles();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { user } = useAuth();
  const { width } = useWindowDimensions();
  const isWide = Platform.OS === "web" && width >= 900;

  const [data, setData] = useState<Dashboard | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");
  const [consult, setConsult] = useState<{ specialistId: string; patientId?: string; reason?: string } | null>(null);

  const startConsult = (specialistId: string, patientId?: string, reason?: string) => {
    setConsult({ specialistId, patientId, reason });
  };

  const load = async () => {
    try {
      setError("");
      setData(await api.dashboard());
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Sync unavailable");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    void load();
  }, []);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.brandPrimary} />
        <Text style={styles.muted}>Syncing regional telemetry…</Text>
      </View>
    );
  }

  const role = data?.role ?? user?.role ?? "coordinator";
  const roleLabel: Record<string, string> = {
    coordinator: "COMMAND CENTER",
    admin: "ADMIN CONTROL",
    hospital_admin: "FACILITY OPS",
    ambulance: "AMBULANCE UNIT",
    specialist: "SPECIALIST ON-CALL",
    doctor: "ATTENDING PHYSICIAN",
  };

  return (
    <View style={[styles.root, { paddingTop: insets.top }]}>
      <ScrollView
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => {
              setRefreshing(true);
              void load();
            }}
            tintColor={colors.brandPrimary}
          />
        }
        contentContainerStyle={[styles.content, isWide && styles.contentWide]}
      >
        <View style={styles.header}>
          <View style={{ flex: 1 }}>
            <Text style={styles.kicker}>MEDISYNC · {roleLabel[role] ?? "OPERATOR"}</Text>
            <Text style={styles.title} testID="dashboard-greeting">
              Good day, {user?.name?.split(" ")[0]}.
            </Text>
            <Text style={styles.muted}>
              {user?.organization} · {data?.connection.last_sync}
            </Text>
          </View>
          <Pressable
            testID="profile-btn"
            onPress={() => router.push("/settings")}
            style={styles.avatar}
          >
            <Text style={styles.avatarText}>{user?.avatar_initials}</Text>
          </Pressable>
        </View>

        <View style={styles.status}>
          <View style={styles.statusDot} />
          <Text style={styles.statusText}>{data?.connection.label}</Text>
          <Text style={styles.statusMeta}>ALL FEEDS OPERATIONAL</Text>
          <MaterialCommunityIcons name="lock-outline" size={14} color={colors.muted} />
        </View>

        {error ? (
          <Pressable onPress={() => void load()} style={styles.errorBox}>
            <MaterialCommunityIcons name="sync-alert" size={20} color={colors.error} />
            <Text style={styles.errorText}>{error} · Tap to retry</Text>
          </Pressable>
        ) : null}

        {data && renderRole(data, router, isWide, startConsult)}
      </ScrollView>
      <ConsultSheet
        visible={consult !== null}
        specialistId={consult?.specialistId}
        patientId={consult?.patientId}
        reason={consult?.reason}
        onClose={() => setConsult(null)}
      />
    </View>
  );
}

function renderRole(
  data: Dashboard,
  router: ReturnType<typeof useRouter>,
  isWide: boolean,
  onStartConsult: (specialistId: string, patientId?: string, reason?: string) => void,
) {
  switch (data.role) {
    case "coordinator":
    case "admin":
      return <CoordinatorView data={data} router={router} isWide={isWide} />;
    case "hospital_admin":
      return <HospitalAdminView data={data} router={router} />;
    case "ambulance":
      return <AmbulanceView data={data} router={router} />;
    case "specialist":
      return <SpecialistView data={data} onStartConsult={onStartConsult} />;
    case "doctor":
      return <DoctorView data={data} router={router} />;
    default:
      return null;
  }
}

// -------- Coordinator --------
function CoordinatorView({
  data,
  router,
  isWide,
}: {
  data: Extract<Dashboard, { role: "coordinator" | "admin" }>;
  router: ReturnType<typeof useRouter>;
  isWide: boolean;
}) {
  const { colors } = useTheme();
  const styles = useStyles();
  return (
    <>
      <View style={styles.metrics}>
        <Metric label="OPEN BEDS" value={data.metrics.available_beds} sub={`of ${data.metrics.total_beds}`} icon="bed-empty" tint={colors.info} />
        <Metric label="ICU OPEN" value={data.metrics.available_icu} sub={`of ${data.metrics.total_icu}`} icon="heart-pulse" tint={colors.brandPrimary} />
        <Metric label="ACTIVE UNITS" value={data.metrics.active_units} sub="EMS live" icon="ambulance" tint={colors.success} />
        <Metric label="HOSPITALS" value={data.metrics.hospitals_online} sub="online" icon="hospital-building" tint={colors.info} />
      </View>

      <View style={isWide ? styles.twoCol : undefined}>
        <View style={{ flex: 1, gap: 14 }}>
          <Pressable testID="new-triage-button" onPress={() => router.push("/triage")} style={styles.caseCta}>
            <View style={styles.caseIcon}>
              <MaterialCommunityIcons name="pulse" size={24} color={colors.onBrandPrimary} />
            </View>
            <View style={styles.caseCopy}>
              <Text style={styles.caseTitle}>AI TRIAGE + MATCH</Text>
              <Text style={styles.caseSub}>Assess vitals · rank hospitals 0-100</Text>
            </View>
            <MaterialCommunityIcons name="arrow-right" size={22} color={colors.onBrandPrimary} />
          </Pressable>

          <Pressable testID="disaster-mode-button" onPress={() => router.push("/disaster")} style={styles.disasterCta}>
            <View style={styles.disasterIcon}>
              <MaterialCommunityIcons name="alert-octagon" size={24} color={colors.onError} />
            </View>
            <View style={styles.caseCopy}>
              <Text style={styles.disasterTitle}>DISASTER MODE</Text>
              <Text style={styles.disasterSub}>Simulate mass-casualty · auto-distribute</Text>
            </View>
            <MaterialCommunityIcons name="arrow-right" size={22} color={colors.onError} />
          </Pressable>

          <SectionTitle title="FACILITY PULSE" action="View all" onPress={() => router.push("/(tabs)/hospitals")} />
          <View style={styles.hospitalStack}>
            {data.hospitals.map((hospital) => (
              <HospitalRow key={hospital.resource_id} hospital={hospital} />
            ))}
          </View>
        </View>

        <View style={{ flex: 1, gap: 14 }}>
          <SectionTitle title="PRIORITY SIGNALS" action="" onPress={() => undefined} />
          <View style={styles.alertStack}>
            {data.alerts.map((alert) => (
              <AlertRow key={alert.id} alert={alert} />
            ))}
          </View>

          <SectionTitle title="LIVE PATIENTS" action="" onPress={() => undefined} />
          <View style={styles.hospitalStack}>
            {data.patients.map((p) => (
              <PatientRow key={p.resource_id} patient={p} />
            ))}
          </View>
        </View>
      </View>
    </>
  );
}

// -------- Hospital Admin --------
function HospitalAdminView({
  data,
  router,
}: {
  data: Extract<Dashboard, { role: "hospital_admin" }>;
  router: ReturnType<typeof useRouter>;
}) {
  const { colors } = useTheme();
  const styles = useStyles();
  return (
    <>
      <View style={styles.facilityCard}>
        <Text style={styles.facilityName}>{data.hospital.name}</Text>
        <Text style={styles.muted}>{data.hospital.level}</Text>
      </View>
      <View style={styles.metrics}>
        <Metric label="OPEN BEDS" value={data.metrics.available_beds} sub={`of ${data.metrics.total_beds}`} icon="bed-empty" tint={colors.info} />
        <Metric label="ICU OPEN" value={data.metrics.available_icu} sub={`of ${data.metrics.total_icu}`} icon="heart-pulse" tint={colors.brandPrimary} />
        <Metric label="ER WAIT" value={data.metrics.er_wait_min} sub="minutes" icon="clock-outline" tint={colors.warning} />
        <Metric label="INBOUND" value={data.metrics.inbound} sub="ambulances" icon="ambulance" tint={colors.success} />
      </View>

      <SectionTitle title="INBOUND AMBULANCES" action="Live map" onPress={() => router.push("/(tabs)/operations")} />
      <View style={styles.hospitalStack}>
        {data.inbound_ambulances.length === 0 ? (
          <EmptyRow message="No inbound units. All quiet." />
        ) : (
          data.inbound_ambulances.map((a) => <InboundRow key={a.resource_id} ambulance={a} />)
        )}
      </View>

      <SectionTitle title="ALERTS" action="" onPress={() => undefined} />
      <View style={styles.alertStack}>
        {data.alerts.map((alert) => (
          <AlertRow key={alert.id} alert={alert} />
        ))}
      </View>
    </>
  );
}

// -------- Ambulance --------
function AmbulanceView({
  data,
  router,
}: {
  data: Extract<Dashboard, { role: "ambulance" }>;
  router: ReturnType<typeof useRouter>;
}) {
  const { colors } = useTheme();
  const styles = useStyles();
  return (
    <>
      <View style={styles.unitCard}>
        <View style={styles.unitHeader}>
          <MaterialCommunityIcons name="ambulance" size={26} color={colors.brandPrimary} />
          <Text style={styles.unitTitle}>{data.ambulance.unit}</Text>
          <View style={[styles.statusBadge, { backgroundColor: colors.brandTertiary }]}>
            <Text style={[styles.statusBadgeText, { color: colors.brandPrimary }]}>
              {data.ambulance.status.replace("_", " ").toUpperCase()}
            </Text>
          </View>
        </View>
        <Text style={styles.muted}>{data.ambulance.crew} · {data.ambulance.sector}</Text>
      </View>

      <View style={styles.metrics}>
        <Metric label="ETA" value={data.metrics.eta_min} sub="minutes" icon="clock-outline" tint={colors.brandPrimary} />
        <Metric label="PATIENT" value={data.metrics.patient_on_board ? 1 : 0} sub={data.metrics.patient_on_board ? "on board" : "none"} icon="account-heart" tint={colors.info} />
      </View>

      {data.destination ? (
        <Pressable
          testID="live-route-button"
          onPress={() => router.push({ pathname: "/route", params: { amb: data.ambulance.resource_id } })}
          style={styles.caseCta}
        >
          <View style={styles.caseIcon}>
            <MaterialCommunityIcons name="map-marker-path" size={24} color={colors.onBrandPrimary} />
          </View>
          <View style={styles.caseCopy}>
            <Text style={styles.caseTitle}>LIVE ROUTE</Text>
            <Text style={styles.caseSub}>Moving map · turn-by-turn to {data.destination.short_name}</Text>
          </View>
          <MaterialCommunityIcons name="arrow-right" size={22} color={colors.onBrandPrimary} />
        </Pressable>
      ) : null}

      {data.patient ? (
        <View style={styles.patientCard}>
          <Text style={styles.eyebrowSmall}>PATIENT ON BOARD</Text>
          <Text style={styles.patientName}>{data.patient.name}</Text>
          <Text style={styles.muted}>
            {data.patient.age}yo {data.patient.sex} · {data.patient.condition}
          </Text>
          <View style={styles.severityBadge}>
            <Text style={styles.severityText}>{data.patient.severity.toUpperCase()}</Text>
          </View>
        </View>
      ) : null}

      {data.destination ? (
        <View style={styles.patientCard}>
          <Text style={styles.eyebrowSmall}>DESTINATION</Text>
          <Text style={styles.patientName}>{data.destination.name}</Text>
          <Text style={styles.muted}>
            ICU {data.destination.icu_available}/{data.destination.icu_total} · ER wait {data.destination.er_wait_min}m
          </Text>
        </View>
      ) : null}

      <SectionTitle title="ROUTE UPDATES" action="" onPress={() => undefined} />
      <View style={styles.alertStack}>
        {data.alerts.map((alert) => (
          <AlertRow key={alert.id} alert={alert} />
        ))}
      </View>
    </>
  );
}

// -------- Specialist --------
function SpecialistView({
  data,
  onStartConsult,
}: {
  data: Extract<Dashboard, { role: "specialist" }>;
  onStartConsult: (specialistId: string, patientId?: string, reason?: string) => void;
}) {
  const { colors } = useTheme();
  const styles = useStyles();
  const spec = data.specialist;
  return (
    <>
      {spec ? (
        <View style={styles.unitCard}>
          <View style={styles.unitHeader}>
            <View style={styles.avatarLg}>
              <Text style={styles.avatarLgText}>{spec.initials}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.unitTitle}>{spec.name}</Text>
              <Text style={styles.muted}>{spec.specialty} · {spec.facility}</Text>
            </View>
          </View>
        </View>
      ) : null}

      <View style={styles.metrics}>
        <Metric
          label="STATUS"
          value={0}
          sub={data.metrics.status.toUpperCase()}
          icon="stethoscope"
          tint={data.metrics.status === "available" ? colors.success : colors.warning}
          hideValue
        />
        <Metric label="RESPONSE" value={data.metrics.response_min} sub="minutes" icon="clock-fast" tint={colors.brandPrimary} />
        <Metric label="CONSULTS" value={data.metrics.pending_consults} sub="pending" icon="account-heart" tint={colors.info} />
      </View>

      <SectionTitle title="PENDING CONSULTS" action="" onPress={() => undefined} />
      <View style={styles.hospitalStack}>
        {data.consults.length === 0 ? (
          <EmptyRow message="No pending consults." />
        ) : (
          data.consults.map((p) => (
            <Pressable
              key={p.resource_id}
              testID={`consult-patient-${p.resource_id}`}
              onPress={() => spec && onStartConsult(spec.resource_id, p.resource_id, `${p.condition}`)}
            >
              <PatientRow patient={p} />
            </Pressable>
          ))
        )}
      </View>

      {spec && data.consults.length > 0 ? (
        <Pressable
          testID="start-consult-button"
          onPress={() =>
            onStartConsult(
              spec.resource_id,
              data.consults[0]?.resource_id,
              data.consults[0]?.condition ?? "Emergency consult",
            )
          }
          style={styles.caseCta}
        >
          <View style={styles.caseIcon}>
            <MaterialCommunityIcons name="video" size={24} color={colors.onBrandPrimary} />
          </View>
          <View style={styles.caseCopy}>
            <Text style={styles.caseTitle}>START VIDEO CONSULT</Text>
            <Text style={styles.caseSub}>Secure line to the receiving team · one tap</Text>
          </View>
          <MaterialCommunityIcons name="arrow-right" size={22} color={colors.onBrandPrimary} />
        </Pressable>
      ) : null}

      <SectionTitle title="ALERTS" action="" onPress={() => undefined} />
      <View style={styles.alertStack}>
        {data.alerts.map((a) => (
          <AlertRow key={a.id} alert={a} />
        ))}
      </View>
    </>
  );
}

// -------- Doctor --------
function DoctorView({
  data,
  router,
}: {
  data: Extract<Dashboard, { role: "doctor" }>;
  router: ReturnType<typeof useRouter>;
}) {
  const { colors } = useTheme();
  const styles = useStyles();
  return (
    <>
      <View style={styles.facilityCard}>
        <Text style={styles.facilityName}>{data.hospital.name}</Text>
        <Text style={styles.muted}>Emergency Department</Text>
      </View>
      <View style={styles.metrics}>
        <Metric label="ACTIVE CASES" value={data.metrics.active_cases} sub="patients" icon="account-heart" tint={colors.info} />
        <Metric label="CRITICAL" value={data.metrics.critical} sub="high acuity" icon="alert" tint={colors.error} />
        <Metric label="ER WAIT" value={data.metrics.er_wait_min} sub="minutes" icon="clock-outline" tint={colors.warning} />
      </View>

      <Pressable testID="doctor-triage-button" onPress={() => router.push("/triage")} style={styles.caseCta}>
        <View style={styles.caseIcon}>
          <MaterialCommunityIcons name="pulse" size={24} color={colors.onBrandPrimary} />
        </View>
        <View style={styles.caseCopy}>
          <Text style={styles.caseTitle}>RUN AI TRIAGE</Text>
          <Text style={styles.caseSub}>Assess vitals for the next arrival</Text>
        </View>
        <MaterialCommunityIcons name="arrow-right" size={22} color={colors.onBrandPrimary} />
      </Pressable>

      <SectionTitle title="MY PATIENTS" action="" onPress={() => undefined} />
      <View style={styles.hospitalStack}>
        {data.patients.length === 0 ? (
          <EmptyRow message="No active patients." />
        ) : (
          data.patients.map((p) => <PatientRow key={p.resource_id} patient={p} />)
        )}
      </View>

      <SectionTitle title="ALERTS" action="" onPress={() => undefined} />
      <View style={styles.alertStack}>
        {data.alerts.map((a) => (
          <AlertRow key={a.id} alert={a} />
        ))}
      </View>
    </>
  );
}

// -------- Shared components --------
function Metric({
  label,
  value,
  sub,
  icon,
  tint,
  hideValue,
}: {
  label: string;
  value: number;
  sub: string;
  icon: IconName;
  tint: string;
  hideValue?: boolean;
}) {
  const { colors } = useTheme();
  return (
    <View style={[metricStyles.card, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border, borderWidth: 1 }]}>
      <MaterialCommunityIcons name={icon} size={20} color={tint} />
      {!hideValue ? (
        <Text style={[metricStyles.value, { color: colors.onSurface }]}>
          {value}
          <Text style={[metricStyles.sub, { color: colors.muted }]}> {sub}</Text>
        </Text>
      ) : (
        <Text style={[metricStyles.value, { color: colors.onSurface, fontSize: 15 }]}>{sub}</Text>
      )}
      <Text style={[metricStyles.label, { color: colors.muted }]}>{label}</Text>
    </View>
  );
}

function SectionTitle({ title, action, onPress }: { title: string; action: string; onPress: () => void }) {
  const { colors } = useTheme();
  return (
    <View style={sectionStyles.row}>
      <Text style={[sectionStyles.title, { color: colors.onSurface }]}>{title}</Text>
      {action ? (
        <Pressable onPress={onPress} hitSlop={8}>
          <Text style={[sectionStyles.action, { color: colors.brandPrimary }]}>{action}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

function HospitalRow({ hospital }: { hospital: Hospital }) {
  const { colors } = useTheme();
  const styles = useStyles();
  return (
    <View style={styles.hospitalRow}>
      <View style={styles.hospitalName}>
        <View
          style={[
            styles.hospitalMark,
            {
              backgroundColor:
                hospital.status === "optimal"
                  ? colors.success
                  : hospital.status === "watch"
                  ? colors.warning
                  : colors.error,
            },
          ]}
        >
          <MaterialCommunityIcons name="hospital-building" size={17} color={colors.surface} />
        </View>
        <View>
          <Text style={styles.rowTitle}>{hospital.short_name}</Text>
          <Text style={styles.muted}>
            {hospital.level} · {hospital.er_wait_min}m ER wait
          </Text>
        </View>
      </View>
      <View style={styles.capacity}>
        <Text style={styles.capacityValue}>
          {hospital.icu_available}
          <Text style={styles.capacitySlash}>/{hospital.icu_total}</Text>
        </Text>
        <Text style={styles.muted}>ICU OPEN</Text>
      </View>
    </View>
  );
}

function AlertRow({ alert }: { alert: Alert }) {
  const { colors } = useTheme();
  const styles = useStyles();
  return (
    <View style={styles.alert}>
      <View
        style={[
          styles.alertIcon,
          {
            backgroundColor:
              alert.type === "warning" ? colors.brandTertiary : "rgba(59,130,246,0.15)",
          },
        ]}
      >
        <MaterialCommunityIcons
          name={alert.type === "warning" ? "alert-outline" : "information-outline"}
          size={18}
          color={alert.type === "warning" ? colors.brandPrimary : colors.info}
        />
      </View>
      <View style={styles.alertCopy}>
        <Text style={styles.rowTitle}>{alert.title}</Text>
        <Text style={styles.muted}>{alert.detail}</Text>
      </View>
      <Text style={styles.alertTime}>{alert.time}</Text>
    </View>
  );
}

function PatientRow({ patient }: { patient: Patient }) {
  const { colors } = useTheme();
  const styles = useStyles();
  const severityColor =
    patient.severity === "critical"
      ? colors.error
      : patient.severity === "urgent"
      ? colors.warning
      : colors.info;
  return (
    <View style={styles.hospitalRow}>
      <View style={styles.hospitalName}>
        <View style={[styles.hospitalMark, { backgroundColor: severityColor }]}>
          <MaterialCommunityIcons name="account-heart" size={17} color={colors.surface} />
        </View>
        <View>
          <Text style={styles.rowTitle}>{patient.name}</Text>
          <Text style={styles.muted}>
            {patient.age}yo · {patient.condition}
          </Text>
        </View>
      </View>
      <View style={styles.capacity}>
        <Text style={[styles.severityText, { color: severityColor }]}>{patient.severity.toUpperCase()}</Text>
        {patient.eta_min ? <Text style={styles.muted}>ETA {patient.eta_min}m</Text> : null}
      </View>
    </View>
  );
}

function InboundRow({ ambulance }: { ambulance: Ambulance & { patient?: Patient | null } }) {
  const { colors } = useTheme();
  const styles = useStyles();
  return (
    <View style={styles.hospitalRow}>
      <View style={styles.hospitalName}>
        <View style={[styles.hospitalMark, { backgroundColor: colors.brandPrimary }]}>
          <MaterialCommunityIcons name="ambulance" size={17} color={colors.onBrandPrimary} />
        </View>
        <View>
          <Text style={styles.rowTitle}>{ambulance.unit}</Text>
          <Text style={styles.muted}>
            {ambulance.patient?.condition ?? ambulance.crew}
          </Text>
        </View>
      </View>
      <View style={styles.capacity}>
        <Text style={styles.capacityValue}>
          {ambulance.eta_min}
          <Text style={styles.capacitySlash}> min</Text>
        </Text>
        <Text style={styles.muted}>ETA</Text>
      </View>
    </View>
  );
}

function EmptyRow({ message }: { message: string }) {
  const { colors } = useTheme();
  return (
    <View style={{ padding: 20, alignItems: "center" }}>
      <MaterialCommunityIcons name="check-circle-outline" size={22} color={colors.muted} />
      <Text style={{ color: colors.muted, fontSize: 13, marginTop: 6 }}>{message}</Text>
    </View>
  );
}

const metricStyles = StyleSheet.create({
  card: { flex: 1, minHeight: 108, padding: 14, borderRadius: 14, gap: 9, minWidth: 120 },
  value: { fontSize: 26, fontWeight: "900" },
  sub: { fontSize: 12, fontWeight: "500" },
  label: { fontSize: 9, fontWeight: "900", letterSpacing: 0.7 },
});

const sectionStyles = StyleSheet.create({
  row: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: 5,
    marginBottom: 10,
  },
  title: { fontSize: 12, fontWeight: "900", letterSpacing: 1.2 },
  action: { fontSize: 12, fontWeight: "800" },
});

const useStyles = makeStyles((colors) => ({
  root: { flex: 1, backgroundColor: colors.surface },
  content: {
    paddingHorizontal: 20,
    paddingTop: 22,
    paddingBottom: 28,
    gap: 16,
    maxWidth: 720,
    width: "100%",
    alignSelf: "center",
  },
  contentWide: { maxWidth: 1200 },
  twoCol: { flexDirection: "row", gap: 16, alignItems: "flex-start" },
  center: {
    flex: 1,
    backgroundColor: colors.surface,
    justifyContent: "center",
    alignItems: "center",
    gap: 14,
  },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  kicker: {
    color: colors.brandPrimary,
    fontSize: 10,
    fontWeight: "900",
    letterSpacing: 1.4,
    marginBottom: 8,
  },
  title: { color: colors.onSurface, fontSize: 26, fontWeight: "900", letterSpacing: -0.5 },
  muted: { color: colors.muted, fontSize: 12, lineHeight: 18 },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 15,
    backgroundColor: colors.surfaceTertiary,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: "center",
    justifyContent: "center",
  },
  avatarText: { color: colors.brandPrimary, fontSize: 13, fontWeight: "900" },
  avatarLg: {
    width: 48,
    height: 48,
    borderRadius: 16,
    backgroundColor: colors.brandTertiary,
    borderWidth: 1,
    borderColor: colors.borderStrong,
    alignItems: "center",
    justifyContent: "center",
  },
  avatarLgText: { color: colors.brandPrimary, fontSize: 15, fontWeight: "900" },
  status: {
    minHeight: 38,
    backgroundColor: colors.surfaceSecondary,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: colors.border,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    gap: 8,
  },
  statusDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: colors.success },
  statusText: { color: colors.success, fontSize: 10, fontWeight: "900", letterSpacing: 1 },
  statusMeta: {
    color: colors.muted,
    fontSize: 9,
    fontWeight: "800",
    letterSpacing: 0.6,
    marginLeft: "auto",
  },
  metrics: { flexDirection: "row", gap: 8, flexWrap: "wrap" },
  caseCta: {
    minHeight: 84,
    borderRadius: 15,
    padding: 14,
    backgroundColor: colors.brandPrimary,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  caseIcon: {
    width: 44,
    height: 44,
    borderRadius: 13,
    backgroundColor: "rgba(14,17,22,0.22)",
    alignItems: "center",
    justifyContent: "center",
  },
  caseCopy: { flex: 1, gap: 4 },
  caseTitle: { color: colors.onBrandPrimary, fontSize: 12, fontWeight: "900", letterSpacing: 0.7 },
  caseSub: { color: colors.onBrandPrimary, opacity: 0.72, fontSize: 12 },
  disasterCta: {
    minHeight: 78,
    borderRadius: 15,
    padding: 14,
    backgroundColor: colors.error,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  disasterIcon: {
    width: 44,
    height: 44,
    borderRadius: 13,
    backgroundColor: "rgba(14,17,22,0.28)",
    alignItems: "center",
    justifyContent: "center",
  },
  disasterTitle: { color: colors.onError, fontSize: 12, fontWeight: "900", letterSpacing: 0.7 },
  disasterSub: { color: colors.onError, opacity: 0.85, fontSize: 12 },
  errorBox: {
    padding: 14,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.error,
    backgroundColor: colors.surfaceSecondary,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  errorText: { color: colors.error, fontSize: 12 },
  hospitalStack: {
    backgroundColor: colors.surfaceSecondary,
    borderRadius: 15,
    borderWidth: 1,
    borderColor: colors.border,
    overflow: "hidden",
  },
  hospitalRow: {
    minHeight: 70,
    paddingHorizontal: 13,
    paddingVertical: 12,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: 1,
    borderBottomColor: colors.divider,
    gap: 12,
  },
  hospitalName: { flexDirection: "row", alignItems: "center", gap: 10, flex: 1 },
  hospitalMark: {
    width: 35,
    height: 35,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  rowTitle: { color: colors.onSurface, fontSize: 13, fontWeight: "800", marginBottom: 3 },
  capacity: { alignItems: "flex-end" },
  capacityValue: { color: colors.onSurface, fontSize: 18, fontWeight: "900" },
  capacitySlash: { color: colors.muted, fontSize: 12, fontWeight: "600" },
  alertStack: { gap: 8 },
  alert: {
    minHeight: 68,
    padding: 12,
    borderRadius: 13,
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1,
    borderColor: colors.border,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  alertIcon: {
    width: 34,
    height: 34,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  alertCopy: { flex: 1 },
  alertTime: { color: colors.muted, fontSize: 10 },
  eyebrowSmall: { color: colors.brandPrimary, fontSize: 10, fontWeight: "900", letterSpacing: 1.2 },
  facilityCard: {
    padding: 14,
    borderRadius: 14,
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1,
    borderColor: colors.border,
    gap: 4,
  },
  facilityName: { color: colors.onSurface, fontSize: 18, fontWeight: "900" },
  unitCard: {
    padding: 14,
    borderRadius: 14,
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1,
    borderColor: colors.border,
    gap: 8,
  },
  unitHeader: { flexDirection: "row", alignItems: "center", gap: 10 },
  unitTitle: { color: colors.onSurface, fontSize: 20, fontWeight: "900", flex: 1 },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999 },
  statusBadgeText: { fontSize: 9, fontWeight: "900", letterSpacing: 0.6 },
  patientCard: {
    padding: 14,
    borderRadius: 14,
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1,
    borderColor: colors.border,
    gap: 6,
  },
  patientName: { color: colors.onSurface, fontSize: 18, fontWeight: "900" },
  severityBadge: {
    alignSelf: "flex-start",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    backgroundColor: colors.error,
    marginTop: 4,
  },
  severityText: { color: colors.onError, fontSize: 10, fontWeight: "900", letterSpacing: 0.8 },
}));
