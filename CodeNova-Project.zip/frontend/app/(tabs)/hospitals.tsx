import { MaterialCommunityIcons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useEffect, useState } from "react";
import { ActivityIndicator, Pressable, RefreshControl, ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api, Hospital } from "@/src/api";
import { makeStyles, useTheme } from "@/src/theme";

export default function HospitalsScreen() {
  const { colors } = useTheme();
  const styles = useStyles();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");

  const load = async () => {
    try {
      setError("");
      setHospitals(await api.hospitals());
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Unable to load facilities");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };
  useEffect(() => {
    void load();
  }, []);

  return (
    <View style={[styles.root, { paddingTop: insets.top }]}>
      <ScrollView
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => {
              setRefreshing(true);
              void load();
            }}
            tintColor={colors.brandPrimary}
          />
        }
        contentContainerStyle={styles.content}
      >
        <View style={styles.header}>
          <View>
            <Text style={styles.kicker}>LIVE RESOURCE GRID</Text>
            <Text style={styles.title}>Hospitals</Text>
            <Text style={styles.muted}>Capacity across connected facilities</Text>
          </View>
          <View style={styles.live}>
            <View style={styles.dot} />
            <Text style={styles.liveText}>LIVE</Text>
          </View>
        </View>
        <Pressable
          testID="hospitals-match-cta"
          onPress={() => router.push("/match")}
          style={({ pressed }) => [styles.matchCta, pressed && styles.pressed]}
        >
          <MaterialCommunityIcons name="creation" size={22} color={colors.onBrandPrimary} />
          <View style={styles.ctaCopy}>
            <Text style={styles.ctaTitle}>AI HOSPITAL MATCH · 0-100</Text>
            <Text style={styles.ctaSub}>Enter patient needs to rank the best destination</Text>
          </View>
          <MaterialCommunityIcons name="arrow-right" size={20} color={colors.onBrandPrimary} />
        </Pressable>
        {loading ? (
          <View style={styles.center}>
            <ActivityIndicator size="large" color={colors.brandPrimary} />
            <Text style={styles.muted}>Syncing facility feeds…</Text>
          </View>
        ) : error ? (
          <Pressable onPress={() => void load()} style={styles.errorBox}>
            <Text style={styles.errorText}>{error} · Tap to retry</Text>
          </Pressable>
        ) : (
          <View style={styles.list}>
            {hospitals.map((h) => (
              <HospitalCard key={h.resource_id} hospital={h} />
            ))}
          </View>
        )}
      </ScrollView>
    </View>
  );
}

function HospitalCard({ hospital }: { hospital: Hospital }) {
  const { colors } = useTheme();
  const styles = useCardStyles();
  const occupancy = Math.round((hospital.icu_available / Math.max(hospital.icu_total, 1)) * 100);
  const statusColor =
    hospital.status === "optimal"
      ? colors.success
      : hospital.status === "watch"
      ? colors.warning
      : colors.error;
  return (
    <View style={styles.card}>
      <View style={styles.cardTop}>
        <View style={styles.icon}>
          <MaterialCommunityIcons name="hospital-building" size={21} color={statusColor} />
        </View>
        <View style={styles.identity}>
          <Text style={styles.name}>{hospital.name}</Text>
          <Text style={styles.muted}>
            {hospital.level} · ER wait {hospital.er_wait_min}m · traffic ×{hospital.traffic_factor.toFixed(1)}
          </Text>
        </View>
        <View
          style={[
            styles.badge,
            {
              backgroundColor:
                hospital.status === "optimal"
                  ? "rgba(16,185,129,0.14)"
                  : hospital.status === "watch"
                  ? colors.brandTertiary
                  : "rgba(239,68,68,0.14)",
            },
          ]}
        >
          <Text style={[styles.badgeText, { color: statusColor }]}>{hospital.status.toUpperCase()}</Text>
        </View>
      </View>
      <View style={styles.capacityRow}>
        <View style={styles.capacityStat}>
          <Text style={styles.big}>
            {hospital.icu_available}
            <Text style={styles.slash}>/{hospital.icu_total}</Text>
          </Text>
          <Text style={styles.muted}>ICU OPEN</Text>
        </View>
        <View style={styles.capacityStat}>
          <Text style={styles.big}>
            {hospital.beds_available}
            <Text style={styles.slash}>/{hospital.beds_total}</Text>
          </Text>
          <Text style={styles.muted}>TOTAL BEDS</Text>
        </View>
        <View style={styles.capacityStat}>
          <Text style={styles.big}>
            {hospital.er_wait_min}
            <Text style={styles.slash}>m</Text>
          </Text>
          <Text style={styles.muted}>ER WAIT</Text>
        </View>
      </View>
      <View style={styles.barTrack}>
        <View style={[styles.barFill, { width: `${occupancy}%`, backgroundColor: statusColor }]} />
      </View>
      <View style={styles.tags}>
        {hospital.specialists.map((s) => (
          <Text key={s} style={styles.tag}>
            {s}
          </Text>
        ))}
        {hospital.oxygen ? <Text style={styles.tag}>O₂ READY</Text> : null}
        {hospital.blood.map((b) => (
          <Text key={b} style={[styles.tag, { color: colors.brandPrimary }]}>
            {b}
          </Text>
        ))}
      </View>
    </View>
  );
}

const useStyles = makeStyles((colors) => ({
  root: { flex: 1, backgroundColor: colors.surface },
  content: { padding: 20, paddingBottom: 28, gap: 18, maxWidth: 900, width: "100%", alignSelf: "center" },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  kicker: { color: colors.brandPrimary, fontSize: 10, fontWeight: "900", letterSpacing: 1.4, marginBottom: 8 },
  title: { color: colors.onSurface, fontSize: 28, fontWeight: "900" },
  muted: { color: colors.muted, fontSize: 12 },
  live: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 11,
    minHeight: 32,
    borderRadius: 20,
    backgroundColor: "rgba(16,185,129,0.12)",
  },
  dot: { width: 7, height: 7, borderRadius: 4, backgroundColor: colors.success },
  liveText: { color: colors.success, fontSize: 10, fontWeight: "900", letterSpacing: 1 },
  matchCta: {
    minHeight: 74,
    padding: 14,
    backgroundColor: colors.brandPrimary,
    borderRadius: 15,
    flexDirection: "row",
    alignItems: "center",
    gap: 11,
  },
  ctaCopy: { flex: 1, gap: 4 },
  ctaTitle: { color: colors.onBrandPrimary, fontSize: 12, fontWeight: "900", letterSpacing: 0.8 },
  ctaSub: { color: colors.onBrandPrimary, opacity: 0.72, fontSize: 12 },
  pressed: { opacity: 0.82 },
  list: { gap: 11 },
  center: { alignItems: "center", padding: 46, gap: 14 },
  errorBox: { padding: 18, borderRadius: 12, borderColor: colors.error, borderWidth: 1 },
  errorText: { color: colors.error, fontSize: 13 },
}));

const useCardStyles = makeStyles((colors) => ({
  card: {
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 16,
    padding: 14,
    gap: 14,
  },
  cardTop: { flexDirection: "row", alignItems: "center", gap: 10 },
  icon: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: colors.surfaceTertiary,
    alignItems: "center",
    justifyContent: "center",
  },
  identity: { flex: 1 },
  name: { color: colors.onSurface, fontSize: 14, fontWeight: "800", marginBottom: 4 },
  muted: { color: colors.muted, fontSize: 11 },
  badge: { paddingHorizontal: 7, minHeight: 22, borderRadius: 5, justifyContent: "center" },
  badgeText: { fontSize: 8, fontWeight: "900", letterSpacing: 0.5 },
  capacityRow: { flexDirection: "row", justifyContent: "space-between" },
  capacityStat: { gap: 4 },
  big: { color: colors.onSurface, fontSize: 21, fontWeight: "900" },
  slash: { color: colors.muted, fontSize: 12, fontWeight: "600" },
  barTrack: { height: 5, backgroundColor: colors.surfaceTertiary, borderRadius: 3, overflow: "hidden" },
  barFill: { height: 5, borderRadius: 3 },
  tags: { flexDirection: "row", gap: 6, flexWrap: "wrap" },
  tag: {
    color: colors.onSurfaceSecondary,
    backgroundColor: colors.surfaceTertiary,
    borderRadius: 6,
    paddingHorizontal: 8,
    paddingVertical: 5,
    fontSize: 10,
    fontWeight: "700",
  },
}));
