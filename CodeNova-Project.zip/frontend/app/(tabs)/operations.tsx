import { MaterialCommunityIcons } from "@expo/vector-icons";
import { useEffect, useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { Ambulance, api, Patient, Specialist } from "@/src/api";
import { makeStyles, useTheme } from "@/src/theme";

export default function OperationsScreen() {
  const { colors } = useTheme();
  const styles = useStyles();
  const insets = useSafeAreaInsets();
  const [tab, setTab] = useState<"fleet" | "specialists" | "patients">("fleet");
  const [fleet, setFleet] = useState<Ambulance[]>([]);
  const [specialists, setSpecialists] = useState<Specialist[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([api.ambulances(), api.specialists(), api.patients()])
      .then(([a, s, p]) => {
        setFleet(a);
        setSpecialists(s);
        setPatients(p);
      })
      .catch((caught) =>
        setError(caught instanceof Error ? caught.message : "Telemetry unavailable"),
      )
      .finally(() => setLoading(false));
  }, []);

  return (
    <View style={[styles.root, { paddingTop: insets.top }]}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <View>
            <Text style={styles.kicker}>FIELD TELEMETRY</Text>
            <Text style={styles.title}>Live Ops</Text>
            <Text style={styles.muted}>Ambulances, specialists, and patients in motion</Text>
          </View>
          <View style={styles.radar}>
            <MaterialCommunityIcons name="radar" size={25} color={colors.brandPrimary} />
          </View>
        </View>

        <LiveMap fleet={fleet} />

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.segment}
        >
          {(
            [
              { id: "fleet", label: `FLEET · ${fleet.length}` },
              { id: "specialists", label: `SPECIALISTS · ${specialists.length}` },
              { id: "patients", label: `PATIENTS · ${patients.length}` },
            ] as const
          ).map((item) => (
            <Pressable
              key={item.id}
              testID={`seg-${item.id}`}
              onPress={() => setTab(item.id)}
              style={[styles.segmentButton, tab === item.id && styles.segmentActive]}
            >
              <Text style={[styles.segmentText, tab === item.id && styles.segmentTextActive]}>
                {item.label}
              </Text>
            </Pressable>
          ))}
        </ScrollView>

        {loading ? (
          <View style={styles.center}>
            <ActivityIndicator size="large" color={colors.brandPrimary} />
            <Text style={styles.muted}>Acquiring field telemetry…</Text>
          </View>
        ) : error ? (
          <Text style={styles.error}>{error}</Text>
        ) : tab === "fleet" ? (
          <View style={styles.list}>
            {fleet.map((item) => (
              <FleetCard key={item.resource_id} item={item} />
            ))}
          </View>
        ) : tab === "specialists" ? (
          <View style={styles.list}>
            {specialists.map((item) => (
              <SpecialistCard key={item.resource_id} item={item} />
            ))}
          </View>
        ) : (
          <View style={styles.list}>
            {patients.map((item) => (
              <PatientCard key={item.resource_id} item={item} />
            ))}
          </View>
        )}
      </ScrollView>
    </View>
  );
}

function LiveMap({ fleet }: { fleet: Ambulance[] }) {
  const { colors } = useTheme();
  const styles = useStyles();
  // Simple normalization of lat/lng into 0-100% positions on the pretend map.
  const lats = fleet.map((f) => f.lat);
  const lngs = fleet.map((f) => f.lng);
  const minLat = Math.min(...lats, 33.95);
  const maxLat = Math.max(...lats, 34.15);
  const minLng = Math.min(...lngs, -118.4);
  const maxLng = Math.max(...lngs, -118.1);
  return (
    <View style={styles.map}>
      <View style={styles.mapGrid}>
        {[1, 2, 3, 4].map((row) => (
          <View key={row} style={styles.gridLine} />
        ))}
      </View>
      <View style={styles.mapLabel}>
        <MaterialCommunityIcons name="map-marker-radius-outline" size={16} color={colors.brandPrimary} />
        <Text style={styles.mapLabelText}>REGIONAL SECTOR · GPS LIVE</Text>
      </View>
      {fleet.map((amb) => {
        const x = ((amb.lng - minLng) / Math.max(maxLng - minLng, 0.01)) * 82 + 6;
        const y = 88 - ((amb.lat - minLat) / Math.max(maxLat - minLat, 0.01)) * 76;
        const color =
          amb.status === "available"
            ? colors.success
            : amb.status === "at_scene"
            ? colors.info
            : colors.brandPrimary;
        return (
          <View
            key={amb.resource_id}
            style={[
              styles.mapPin,
              { left: `${x}%`, top: `${y}%`, backgroundColor: color },
            ]}
          >
            <MaterialCommunityIcons name="ambulance" size={15} color={colors.onBrandPrimary} />
          </View>
        );
      })}
    </View>
  );
}

function FleetCard({ item }: { item: Ambulance }) {
  const { colors } = useTheme();
  const styles = useCardStyles();
  const statusColor =
    item.status === "available"
      ? colors.success
      : item.status === "at_scene"
      ? colors.info
      : colors.brandPrimary;
  return (
    <View style={styles.card}>
      <View style={styles.row}>
        <View
          style={[
            styles.icon,
            {
              backgroundColor:
                item.status === "available"
                  ? "rgba(16,185,129,0.14)"
                  : colors.brandTertiary,
            },
          ]}
        >
          <MaterialCommunityIcons name="ambulance" size={20} color={statusColor} />
        </View>
        <View style={styles.copy}>
          <Text style={styles.name}>{item.unit}</Text>
          <Text style={styles.muted}>{item.crew}</Text>
        </View>
        <Text style={[styles.status, { color: statusColor }]}>
          {item.status.replace("_", " ").toUpperCase()}
        </Text>
      </View>
      <View style={styles.detail}>
        <Text style={styles.muted}>{item.sector}</Text>
        <Text style={styles.destination}>{item.destination}</Text>
        <Text style={styles.eta}>{item.eta_min} min ETA</Text>
      </View>
    </View>
  );
}

function SpecialistCard({ item }: { item: Specialist }) {
  const { colors } = useTheme();
  const styles = useCardStyles();
  return (
    <View style={styles.card}>
      <View style={styles.row}>
        <View style={[styles.avatar, { backgroundColor: colors.surfaceTertiary }]}>
          <Text style={styles.avatarText}>{item.initials}</Text>
        </View>
        <View style={styles.copy}>
          <Text style={styles.name}>{item.name}</Text>
          <Text style={styles.muted}>
            {item.specialty} · {item.facility}
          </Text>
        </View>
        <Text
          style={[
            styles.status,
            { color: item.status === "available" ? colors.success : colors.warning },
          ]}
        >
          {item.status.toUpperCase()}
        </Text>
      </View>
      <View style={styles.detail}>
        <Text style={styles.muted}>Secure response channel</Text>
        <Text style={styles.destination}>Expected response</Text>
        <Text style={styles.eta}>{item.response_min} min</Text>
      </View>
    </View>
  );
}

function PatientCard({ item }: { item: Patient }) {
  const { colors } = useTheme();
  const styles = useCardStyles();
  const severityColor =
    item.severity === "critical"
      ? colors.error
      : item.severity === "urgent"
      ? colors.warning
      : colors.info;
  return (
    <View style={styles.card}>
      <View style={styles.row}>
        <View style={[styles.icon, { backgroundColor: colors.surfaceTertiary }]}>
          <MaterialCommunityIcons name="account-heart" size={20} color={severityColor} />
        </View>
        <View style={styles.copy}>
          <Text style={styles.name}>{item.name}</Text>
          <Text style={styles.muted}>
            {item.age}yo {item.sex} · {item.condition}
          </Text>
        </View>
        <Text style={[styles.status, { color: severityColor }]}>{item.severity.toUpperCase()}</Text>
      </View>
      <View style={styles.detail}>
        <Text style={styles.muted}>FHIR {item.fhir_id}</Text>
        <Text style={styles.destination}>Assigned</Text>
        <Text style={styles.eta}>{item.eta_min ? `${item.eta_min} min` : "—"}</Text>
      </View>
    </View>
  );
}

const useStyles = makeStyles((colors) => ({
  root: { flex: 1, backgroundColor: colors.surface },
  content: { padding: 20, paddingBottom: 28, gap: 16, maxWidth: 900, width: "100%", alignSelf: "center" },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  kicker: { color: colors.brandPrimary, fontSize: 10, fontWeight: "900", letterSpacing: 1.4, marginBottom: 8 },
  title: { color: colors.onSurface, fontSize: 28, fontWeight: "900" },
  muted: { color: colors.muted, fontSize: 12 },
  radar: {
    width: 47, height: 47, borderRadius: 15,
    backgroundColor: colors.brandTertiary,
    alignItems: "center", justifyContent: "center",
  },
  map: {
    minHeight: 220,
    borderRadius: 16,
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1,
    borderColor: colors.border,
    overflow: "hidden",
    position: "relative",
  },
  mapGrid: { ...StyleSheet.absoluteFillObject, padding: 30, gap: 40, justifyContent: "space-around" },
  gridLine: { height: 1, backgroundColor: colors.divider },
  mapLabel: {
    position: "absolute", top: 14, left: 14,
    flexDirection: "row", alignItems: "center", gap: 6,
  },
  mapLabelText: { color: colors.muted, fontSize: 9, fontWeight: "900", letterSpacing: 1 },
  mapPin: {
    position: "absolute", width: 34, height: 34, borderRadius: 17,
    alignItems: "center", justifyContent: "center",
    borderWidth: 3, borderColor: colors.surfaceSecondary,
  },
  segment: { gap: 6, paddingRight: 8 },
  segmentButton: {
    minHeight: 40, paddingHorizontal: 14, borderRadius: 10,
    justifyContent: "center", flexShrink: 0,
    borderWidth: 1, borderColor: colors.border,
    backgroundColor: colors.surfaceSecondary,
  },
  segmentActive: {
    backgroundColor: colors.brandTertiary,
    borderColor: colors.brandPrimary,
  },
  segmentText: { color: colors.muted, fontSize: 10, fontWeight: "900", letterSpacing: 0.6 },
  segmentTextActive: { color: colors.brandPrimary },
  list: { gap: 10 },
  center: { alignItems: "center", padding: 35, gap: 12 },
  error: { color: colors.error, fontSize: 13 },
}));

const useCardStyles = makeStyles((colors) => ({
  card: {
    backgroundColor: colors.surfaceSecondary, borderRadius: 15,
    borderWidth: 1, borderColor: colors.border, padding: 14, gap: 13,
  },
  row: { flexDirection: "row", alignItems: "center", gap: 10 },
  icon: {
    width: 40, height: 40, borderRadius: 12,
    alignItems: "center", justifyContent: "center",
  },
  avatar: {
    width: 40, height: 40, borderRadius: 12,
    alignItems: "center", justifyContent: "center",
  },
  avatarText: { color: colors.brandPrimary, fontSize: 12, fontWeight: "900" },
  copy: { flex: 1 },
  name: { color: colors.onSurface, fontSize: 14, fontWeight: "800", marginBottom: 4 },
  muted: { color: colors.muted, fontSize: 11 },
  status: { fontSize: 9, fontWeight: "900", letterSpacing: 0.5 },
  detail: {
    minHeight: 43, borderTopWidth: 1, borderTopColor: colors.divider,
    paddingTop: 10, flexDirection: "row", alignItems: "center", gap: 10,
  },
  destination: { color: colors.onSurfaceSecondary, fontSize: 12, fontWeight: "700", flex: 1 },
  eta: { color: colors.brandPrimary, fontSize: 12, fontWeight: "900" },
}));
