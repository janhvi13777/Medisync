import { MaterialCommunityIcons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useEffect, useState } from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api, DisasterPlanItem, DisasterResult } from "@/src/api";
import { makeStyles, useTheme } from "@/src/theme";

const PRESETS = [
  { name: "Building collapse", c: 8, u: 20, m: 30, r: 10 },
  { name: "Highway pileup", c: 5, u: 15, m: 25, r: 20 },
  { name: "Mass casualty event", c: 20, u: 45, m: 80, r: 25 },
];

export default function DisasterScreen() {
  const { colors } = useTheme();
  const styles = useStyles();
  const insets = useSafeAreaInsets();
  const router = useRouter();

  const [scenario, setScenario] = useState("Mass casualty event");
  const [critical, setCritical] = useState("8");
  const [urgent, setUrgent] = useState("20");
  const [moderate, setModerate] = useState("30");
  const [radius, setRadius] = useState("15");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<DisasterResult | null>(null);
  const [activeDisaster, setActiveDisaster] = useState<DisasterResult | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api.disasterActive().then((d) => {
      if (d.active && d.disaster) setActiveDisaster(d.disaster);
    }).catch(() => undefined);
  }, []);

  const applyPreset = (p: (typeof PRESETS)[number]) => {
    setScenario(p.name);
    setCritical(String(p.c));
    setUrgent(String(p.u));
    setModerate(String(p.m));
    setRadius(String(p.r));
  };

  const run = async (activate: boolean) => {
    setBusy(true);
    setError("");
    try {
      const res = await api.disasterSimulate({
        scenario_name: scenario,
        critical: Number(critical) || 0,
        urgent: Number(urgent) || 0,
        moderate: Number(moderate) || 0,
        radius_km: Number(radius) || 15,
        activate,
      });
      setResult(res);
      if (activate) setActiveDisaster(res);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Simulation failed");
    } finally {
      setBusy(false);
    }
  };

  const endDisaster = async () => {
    await api.disasterEnd();
    setActiveDisaster(null);
  };

  const totalPatients =
    (Number(critical) || 0) + (Number(urgent) || 0) + (Number(moderate) || 0);

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={[styles.root, { paddingTop: insets.top }]}
    >
      <ScrollView
        contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 24 }]}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.header}>
          <Pressable testID="disaster-back" onPress={() => router.back()} style={styles.back}>
            <MaterialCommunityIcons name="arrow-left" size={21} color={colors.onSurface} />
          </Pressable>
          <View style={{ flex: 1 }}>
            <Text style={styles.kicker}>MASS-CASUALTY MODE</Text>
            <Text style={styles.title}>Disaster simulator</Text>
          </View>
          <View style={styles.aiMark}>
            <MaterialCommunityIcons name="alert-octagon" size={22} color={colors.error} />
          </View>
        </View>

        {activeDisaster ? (
          <View style={styles.activeBanner} testID="active-disaster-banner">
            <View style={styles.pulseDot} />
            <View style={{ flex: 1 }}>
              <Text style={styles.activeTitle}>ACTIVE · {activeDisaster.scenario_name}</Text>
              <Text style={styles.activeSub}>
                {activeDisaster.patients.total} patients across {activeDisaster.hospitals_used} hospitals
              </Text>
            </View>
            <Pressable testID="end-disaster-btn" onPress={() => void endDisaster()} style={styles.endBtn}>
              <Text style={styles.endBtnText}>END</Text>
            </Pressable>
          </View>
        ) : null}

        <Text style={styles.intro}>
          Enter incident scale and radius. Medisync auto-distributes casualties across live regional
          capacity, prioritizing ICU/vent-capable hospitals for critical cases.
        </Text>

        <View style={styles.panel}>
          <Text style={styles.panelHeader}>QUICK PRESETS</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.presetRow}>
            {PRESETS.map((p) => (
              <Pressable
                key={p.name}
                testID={`preset-${p.name.toLowerCase().replace(/\s/g, "-")}`}
                onPress={() => applyPreset(p)}
                style={styles.presetChip}
              >
                <MaterialCommunityIcons name="alert-octagram-outline" size={14} color={colors.error} />
                <Text style={styles.presetText}>{p.name}</Text>
              </Pressable>
            ))}
          </ScrollView>
        </View>

        <View style={styles.panel}>
          <Text style={styles.panelHeader}>SCENARIO</Text>
          <TextInput
            testID="disaster-scenario"
            value={scenario}
            onChangeText={setScenario}
            style={styles.input}
            placeholderTextColor={colors.muted}
          />
        </View>

        <View style={styles.panel}>
          <Text style={styles.panelHeader}>CASUALTY BREAKDOWN</Text>
          <View style={styles.grid}>
            <NumField testID="disaster-critical" label="CRITICAL (ICU)" value={critical} onChangeText={setCritical} tint={colors.error} />
            <NumField testID="disaster-urgent" label="URGENT" value={urgent} onChangeText={setUrgent} tint={colors.warning} />
            <NumField testID="disaster-moderate" label="MODERATE" value={moderate} onChangeText={setModerate} tint={colors.info} />
            <NumField testID="disaster-radius" label="RADIUS (km)" value={radius} onChangeText={setRadius} tint={colors.brandPrimary} />
          </View>
          <View style={styles.totalRow}>
            <Text style={styles.totalLabel}>TOTAL PATIENTS</Text>
            <Text style={styles.totalValue}>{totalPatients}</Text>
          </View>
        </View>

        {error ? <Text style={styles.error}>{error}</Text> : null}

        <View style={styles.actions}>
          <Pressable
            testID="simulate-btn"
            onPress={() => void run(false)}
            disabled={busy}
            style={({ pressed }) => [styles.secondary, pressed && styles.pressed, busy && styles.disabled]}
          >
            {busy ? (
              <ActivityIndicator color={colors.brandPrimary} />
            ) : (
              <MaterialCommunityIcons name="flask-outline" size={18} color={colors.brandPrimary} />
            )}
            <Text style={styles.secondaryText}>SIMULATE</Text>
          </Pressable>
          <Pressable
            testID="activate-btn"
            onPress={() => void run(true)}
            disabled={busy}
            style={({ pressed }) => [styles.primary, pressed && styles.pressed, busy && styles.disabled]}
          >
            {busy ? (
              <ActivityIndicator color={colors.onError} />
            ) : (
              <MaterialCommunityIcons name="alert-octagon" size={19} color={colors.onError} />
            )}
            <Text style={styles.primaryText}>ACTIVATE DISASTER MODE</Text>
          </Pressable>
        </View>

        {result ? <ResultPanel result={result} /> : null}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

function NumField({
  testID,
  label,
  value,
  onChangeText,
  tint,
}: {
  testID: string;
  label: string;
  value: string;
  onChangeText: (v: string) => void;
  tint: string;
}) {
  const { colors } = useTheme();
  const styles = useStyles();
  return (
    <View style={styles.numFieldWrap}>
      <Text style={[styles.numLabel, { color: tint }]}>{label}</Text>
      <TextInput
        testID={testID}
        value={value}
        onChangeText={onChangeText}
        keyboardType="number-pad"
        style={styles.input}
        placeholderTextColor={colors.muted}
      />
    </View>
  );
}

function ResultPanel({ result }: { result: DisasterResult }) {
  const { colors } = useTheme();
  const styles = useStyles();
  const unassignedTotal =
    result.unassigned.critical + result.unassigned.urgent + result.unassigned.moderate;
  return (
    <View style={styles.result} testID="disaster-result">
      <View style={styles.resultHeader}>
        <View style={{ flex: 1 }}>
          <Text style={styles.kicker}>ASSIGNMENT PLAN</Text>
          <Text style={styles.resultTitle}>{result.scenario_name}</Text>
          <Text style={styles.muted}>
            {result.total_assigned} of {result.patients.total} patients placed · {result.hospitals_used}
            /{result.hospitals_in_range} hospitals engaged
          </Text>
        </View>
        <View style={styles.resultBadge}>
          <Text style={styles.resultBadgeValue}>{result.hospitals_used}</Text>
          <Text style={styles.resultBadgeLabel}>SITES</Text>
        </View>
      </View>

      {unassignedTotal > 0 ? (
        <View style={styles.unassigned}>
          <MaterialCommunityIcons name="alert-outline" size={16} color={colors.error} />
          <Text style={styles.unassignedText}>
            {unassignedTotal} patients unassigned — expand radius or route out of region
          </Text>
        </View>
      ) : (
        <View style={[styles.unassigned, { borderColor: colors.success }]}>
          <MaterialCommunityIcons name="check-circle-outline" size={16} color={colors.success} />
          <Text style={[styles.unassignedText, { color: colors.success }]}>
            All patients placed within regional capacity
          </Text>
        </View>
      )}

      {result.plan.map((item) => (
        <PlanRow key={item.hospital_id} item={item} />
      ))}
    </View>
  );
}

function PlanRow({ item }: { item: DisasterPlanItem }) {
  const { colors } = useTheme();
  const styles = useStyles();
  const statusColor =
    item.emergency_status === "NORMAL"
      ? colors.success
      : item.emergency_status === "BUSY"
      ? colors.warning
      : colors.error;
  return (
    <View style={styles.planRow}>
      <View style={styles.planTop}>
        <View style={[styles.planDot, { backgroundColor: statusColor }]} />
        <View style={{ flex: 1 }}>
          <Text style={styles.planName}>{item.hospital_name}</Text>
          <Text style={styles.muted}>
            {item.distance_km} km · {item.eta_min}m ETA · {item.emergency_status}
          </Text>
        </View>
        <View style={styles.planTotal}>
          <Text style={styles.planTotalValue}>{item.assigned.total}</Text>
          <Text style={styles.planTotalLabel}>PATIENTS</Text>
        </View>
      </View>
      <View style={styles.severityRow}>
        {item.assigned.critical > 0 ? (
          <View style={[styles.sevPill, { backgroundColor: colors.error }]}>
            <Text style={styles.sevPillText}>C · {item.assigned.critical}</Text>
          </View>
        ) : null}
        {item.assigned.urgent > 0 ? (
          <View style={[styles.sevPill, { backgroundColor: colors.warning }]}>
            <Text style={[styles.sevPillText, { color: colors.onWarning }]}>U · {item.assigned.urgent}</Text>
          </View>
        ) : null}
        {item.assigned.moderate > 0 ? (
          <View style={[styles.sevPill, { backgroundColor: colors.info }]}>
            <Text style={styles.sevPillText}>M · {item.assigned.moderate}</Text>
          </View>
        ) : null}
      </View>
      <Text style={styles.capacityAfter}>
        REMAINING · ICU {item.capacity_after.icu_remaining} · VENT {item.capacity_after.ventilator_remaining} ·
        BEDS {item.capacity_after.beds_remaining}
      </Text>
    </View>
  );
}

const useStyles = makeStyles((colors) => ({
  root: { flex: 1, backgroundColor: colors.surface },
  content: { padding: 20, gap: 16, maxWidth: 720, width: "100%", alignSelf: "center" },
  header: { flexDirection: "row", alignItems: "center", gap: 12 },
  back: {
    width: 44, height: 44, borderRadius: 12,
    borderWidth: 1, borderColor: colors.border,
    alignItems: "center", justifyContent: "center",
  },
  kicker: { color: colors.error, fontSize: 10, fontWeight: "900", letterSpacing: 1.2, marginBottom: 6 },
  title: { color: colors.onSurface, fontSize: 26, fontWeight: "900" },
  aiMark: {
    width: 40, height: 40, borderRadius: 12,
    backgroundColor: "rgba(239,68,68,0.15)",
    alignItems: "center", justifyContent: "center",
  },
  intro: { color: colors.onSurfaceSecondary, fontSize: 14, lineHeight: 21 },
  activeBanner: {
    flexDirection: "row", alignItems: "center", gap: 10,
    padding: 12, borderRadius: 12, backgroundColor: colors.error,
    borderWidth: 1, borderColor: colors.error,
  },
  pulseDot: { width: 12, height: 12, borderRadius: 6, backgroundColor: colors.onError },
  activeTitle: { color: colors.onError, fontSize: 12, fontWeight: "900", letterSpacing: 0.5 },
  activeSub: { color: colors.onError, fontSize: 11, opacity: 0.85 },
  endBtn: {
    paddingHorizontal: 12, minHeight: 32, borderRadius: 8,
    backgroundColor: colors.onError, justifyContent: "center",
  },
  endBtnText: { color: colors.error, fontSize: 11, fontWeight: "900" },
  panel: {
    backgroundColor: colors.surfaceSecondary, borderRadius: 16,
    borderWidth: 1, borderColor: colors.border, padding: 15, gap: 10,
  },
  panelHeader: { color: colors.muted, fontSize: 10, fontWeight: "900", letterSpacing: 1.1 },
  presetRow: { gap: 8, paddingRight: 8 },
  presetChip: {
    minHeight: 40, paddingHorizontal: 12, borderRadius: 999,
    borderWidth: 1, borderColor: "rgba(239,68,68,0.35)",
    backgroundColor: "rgba(239,68,68,0.08)",
    flexDirection: "row", alignItems: "center", gap: 6, flexShrink: 0,
  },
  presetText: { color: colors.onSurface, fontSize: 12, fontWeight: "700" },
  grid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  numFieldWrap: { flex: 1, minWidth: 130, gap: 6 },
  numLabel: { fontSize: 10, fontWeight: "900", letterSpacing: 1 },
  input: {
    minHeight: 48, borderWidth: 1, borderRadius: 10,
    borderColor: colors.border, backgroundColor: colors.surfaceTertiary,
    paddingHorizontal: 12, color: colors.onSurface, fontSize: 15,
  },
  totalRow: {
    flexDirection: "row", justifyContent: "space-between", alignItems: "center",
    paddingTop: 6, borderTopWidth: 1, borderTopColor: colors.divider,
  },
  totalLabel: { color: colors.muted, fontSize: 10, fontWeight: "900", letterSpacing: 1.1 },
  totalValue: { color: colors.error, fontSize: 22, fontWeight: "900" },
  error: { color: colors.error, fontSize: 12 },
  actions: { flexDirection: "row", gap: 10 },
  secondary: {
    flex: 1, minHeight: 52, borderRadius: 12,
    borderWidth: 1, borderColor: colors.brandPrimary,
    flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8,
  },
  secondaryText: { color: colors.brandPrimary, fontSize: 11, fontWeight: "900", letterSpacing: 0.6 },
  primary: {
    flex: 1.5, minHeight: 52, borderRadius: 12,
    backgroundColor: colors.error,
    flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8,
  },
  primaryText: { color: colors.onError, fontSize: 11, fontWeight: "900", letterSpacing: 0.6 },
  pressed: { opacity: 0.85 },
  disabled: { opacity: 0.6 },
  result: {
    backgroundColor: colors.surfaceSecondary, borderRadius: 17,
    borderWidth: 1, borderColor: colors.borderStrong, padding: 15, gap: 12,
  },
  resultHeader: { flexDirection: "row", alignItems: "flex-start", gap: 10 },
  resultTitle: { color: colors.onSurface, fontSize: 18, fontWeight: "900" },
  muted: { color: colors.muted, fontSize: 11 },
  resultBadge: {
    width: 66, height: 66, borderRadius: 33, borderWidth: 2,
    borderColor: colors.brandPrimary, backgroundColor: colors.brandTertiary,
    alignItems: "center", justifyContent: "center",
  },
  resultBadgeValue: { color: colors.brandPrimary, fontSize: 22, fontWeight: "900" },
  resultBadgeLabel: { color: colors.muted, fontSize: 8, fontWeight: "900" },
  unassigned: {
    flexDirection: "row", alignItems: "center", gap: 8,
    padding: 10, borderRadius: 10,
    borderWidth: 1, borderColor: colors.error,
    backgroundColor: colors.surfaceTertiary,
  },
  unassignedText: { color: colors.error, fontSize: 12, fontWeight: "700", flex: 1 },
  planRow: {
    padding: 12, borderRadius: 12,
    backgroundColor: colors.surfaceTertiary,
    borderWidth: 1, borderColor: colors.border, gap: 8,
  },
  planTop: { flexDirection: "row", alignItems: "center", gap: 10 },
  planDot: { width: 10, height: 10, borderRadius: 5 },
  planName: { color: colors.onSurface, fontSize: 14, fontWeight: "800" },
  planTotal: { alignItems: "flex-end" },
  planTotalValue: { color: colors.brandPrimary, fontSize: 20, fontWeight: "900" },
  planTotalLabel: { color: colors.muted, fontSize: 8, fontWeight: "900", letterSpacing: 0.6 },
  severityRow: { flexDirection: "row", gap: 6, flexWrap: "wrap" },
  sevPill: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 999 },
  sevPillText: { color: colors.onError, fontSize: 10, fontWeight: "900", letterSpacing: 0.6 },
  capacityAfter: { color: colors.muted, fontSize: 10, fontWeight: "700", letterSpacing: 0.4 },
}));
