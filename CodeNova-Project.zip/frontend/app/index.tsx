import { Redirect } from "expo-router";
import { ActivityIndicator, StyleSheet, Text, View } from "react-native";

import { useAuth } from "@/src/auth";
import { useTheme } from "@/src/theme";

export default function Index() {
  const { user, loading } = useAuth();
  const { colors } = useTheme();
  if (loading) return <View style={[styles.root, { backgroundColor: colors.surface }]}><ActivityIndicator color={colors.brandPrimary} size="large" /><Text style={[styles.loading, { color: colors.muted }]}>Securing Medisync…</Text></View>;
  return user ? <Redirect href="/(tabs)/dashboard" /> : <Redirect href="/login" />;
}

const styles = StyleSheet.create({ root: { flex: 1, alignItems: "center", justifyContent: "center", gap: 16 }, loading: { fontSize: 14 } });