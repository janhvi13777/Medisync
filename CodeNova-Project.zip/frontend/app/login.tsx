import { MaterialCommunityIcons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useEffect, useState } from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useAuth } from "@/src/auth";
import { makeStyles, useTheme } from "@/src/theme";

type IconName = keyof typeof MaterialCommunityIcons.glyphMap;

const DEMOS: { role: string; label: string; email: string; icon: IconName }[] = [
  { role: "coordinator", label: "Coordinator", email: "coordinator@medisync.app", icon: "shield-crown-outline" },
  { role: "hospital_admin", label: "Hospital Admin", email: "hospital@medisync.app", icon: "hospital-building" },
  { role: "ambulance", label: "Ambulance", email: "ambulance@medisync.app", icon: "ambulance" },
  { role: "specialist", label: "Specialist", email: "specialist@medisync.app", icon: "stethoscope" },
  { role: "doctor", label: "Doctor", email: "doctor@medisync.app", icon: "heart-pulse" },
];

export default function LoginScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const styles = useStyles();
  const { user, error, login, register, googleLogin, clearError } = useAuth();
  const [isRegister, setIsRegister] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("coordinator");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (user) router.replace("/(tabs)/dashboard");
  }, [user, router]);

  const submit = async () => {
    setBusy(true);
    clearError();
    try {
      if (isRegister) await register(name, email, password, role);
      else await login(email, password);
    } catch {
    } finally {
      setBusy(false);
    }
  };

  const demoLogin = async (demoEmail: string) => {
    setEmail(demoEmail);
    setPassword("MediSync123!");
    setBusy(true);
    clearError();
    try {
      await login(demoEmail, "MediSync123!");
    } catch {
    } finally {
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={[styles.root, { paddingTop: insets.top, paddingBottom: insets.bottom }]}
    >
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <View style={styles.brandRow}>
          <View style={styles.logo}>
            <MaterialCommunityIcons name="heart-pulse" size={22} color={colors.onBrandPrimary} />
          </View>
          <Text style={styles.brand}>MEDISYNC</Text>
          <Text style={styles.protocol}>FHIR · SECURE</Text>
        </View>

        <View style={styles.hero}>
          <Text style={styles.eyebrow}>EMERGENCY HEALTHCARE COORDINATION</Text>
          <Text style={styles.title}>
            {isRegister ? "Create your access" : "Coordinate care\nwithout delay."}
          </Text>
          <Text style={styles.subtitle}>
            {isRegister
              ? "Join your organization's secure Medisync workspace."
              : "One live view for hospitals, EMS, specialists, and critical supplies with AI-guided routing."}
          </Text>
        </View>

        <View style={styles.formCard}>
          <View style={styles.formHeader}>
            <Text style={styles.formTitle}>{isRegister ? "New operator profile" : "Operator sign-in"}</Text>
            <View style={styles.secure}>
              <MaterialCommunityIcons name="shield-check-outline" size={15} color={colors.success} />
              <Text style={styles.secureText}>ENCRYPTED</Text>
            </View>
          </View>
          {isRegister ? (
            <Field
              testID="name-input"
              label="FULL NAME"
              value={name}
              onChangeText={setName}
              placeholder="Jordan Blake"
              colors={colors}
            />
          ) : null}
          <Field
            testID="email-input"
            label="WORK EMAIL"
            value={email}
            onChangeText={setEmail}
            placeholder="name@hospital.org"
            keyboardType="email-address"
            colors={colors}
          />
          <Field
            testID="password-input"
            label="PASSWORD"
            value={password}
            onChangeText={setPassword}
            placeholder="8+ characters"
            secureTextEntry
            colors={colors}
          />
          {isRegister ? (
            <View>
              <Text style={styles.label}>ACCESS ROLE</Text>
              <View style={styles.roleRow}>
                {DEMOS.map((item) => (
                  <Pressable
                    key={item.role}
                    testID={`register-role-${item.role}`}
                    onPress={() => setRole(item.role)}
                    style={[styles.roleChip, role === item.role && styles.roleChipActive]}
                  >
                    <Text style={[styles.roleText, role === item.role && styles.roleTextActive]}>
                      {item.label}
                    </Text>
                  </Pressable>
                ))}
              </View>
            </View>
          ) : null}
          {error ? <Text style={styles.error}>{error}</Text> : null}
          <Pressable
            accessibilityRole="button"
            testID="sign-in-button"
            onPress={submit}
            disabled={busy}
            style={({ pressed }) => [styles.primary, pressed && styles.pressed, busy && styles.disabled]}
          >
            <Text style={styles.primaryText}>
              {busy ? "SECURING SESSION…" : isRegister ? "CREATE SECURE ACCESS" : "ENTER MEDISYNC"}
            </Text>
            {busy ? (
              <ActivityIndicator color={colors.onBrandPrimary} />
            ) : (
              <MaterialCommunityIcons name="arrow-right" size={20} color={colors.onBrandPrimary} />
            )}
          </Pressable>
          <View style={styles.orRow}>
            <View style={styles.line} />
            <Text style={styles.or}>OR</Text>
            <View style={styles.line} />
          </View>
          <Pressable
            testID="google-sign-in"
            onPress={() => void googleLogin()}
            style={({ pressed }) => [styles.google, pressed && styles.pressed]}
          >
            <MaterialCommunityIcons name="google" size={19} color={colors.onSurface} />
            <Text style={styles.googleText}>CONTINUE WITH GOOGLE</Text>
          </Pressable>
        </View>

        {!isRegister ? (
          <View style={styles.demoSection}>
            <Text style={styles.demoHeader}>QUICK DEMO ACCESS</Text>
            <Text style={styles.demoNote}>Tap a role to sign in with seeded demo data</Text>
            <View style={styles.demoGrid}>
              {DEMOS.map((demo) => (
                <Pressable
                  key={demo.role}
                  testID={`demo-${demo.role}`}
                  disabled={busy}
                  onPress={() => void demoLogin(demo.email)}
                  style={({ pressed }) => [styles.demoChip, pressed && styles.pressed]}
                >
                  <MaterialCommunityIcons name={demo.icon} size={18} color={colors.brandPrimary} />
                  <Text style={styles.demoLabel}>{demo.label}</Text>
                </Pressable>
              ))}
            </View>
          </View>
        ) : null}

        <Pressable
          onPress={() => {
            setIsRegister((v) => !v);
            clearError();
          }}
          style={styles.switch}
        >
          <Text style={styles.switchMuted}>{isRegister ? "Already have access?" : "Need an operator account?"}</Text>
          <Text style={styles.switchAction}>{isRegister ? "Sign in" : "Register"}</Text>
        </Pressable>

        <Text style={styles.footer}>ACCESS IS LOGGED · FHIR-READY · ROLE CONTROLLED</Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

function Field({
  testID,
  label,
  value,
  onChangeText,
  placeholder,
  secureTextEntry,
  keyboardType,
  colors,
}: {
  testID: string;
  label: string;
  value: string;
  onChangeText: (value: string) => void;
  placeholder: string;
  secureTextEntry?: boolean;
  keyboardType?: "email-address";
  colors: ReturnType<typeof useTheme>["colors"];
}) {
  return (
    <View style={{ gap: 7 }}>
      <Text style={{ color: colors.muted, fontSize: 10, fontWeight: "800", letterSpacing: 1.2 }}>{label}</Text>
      <TextInput
        testID={testID}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.muted}
        secureTextEntry={secureTextEntry}
        keyboardType={keyboardType}
        autoCapitalize="none"
        style={{
          minHeight: 48,
          borderWidth: 1,
          borderRadius: 10,
          paddingHorizontal: 14,
          fontSize: 15,
          color: colors.onSurface,
          borderColor: colors.border,
          backgroundColor: colors.surfaceTertiary,
        }}
      />
    </View>
  );
}

const useStyles = makeStyles((colors) => ({
  root: { flex: 1, backgroundColor: colors.surface },
  content: {
    paddingHorizontal: 24,
    paddingVertical: 24,
    gap: 22,
    maxWidth: 560,
    width: "100%",
    alignSelf: "center",
  },
  brandRow: { flexDirection: "row", alignItems: "center", gap: 9 },
  logo: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: colors.brandPrimary,
    alignItems: "center",
    justifyContent: "center",
  },
  brand: { color: colors.onSurface, fontSize: 17, fontWeight: "800", letterSpacing: 1.4 },
  protocol: { color: colors.muted, fontSize: 9, letterSpacing: 1, marginLeft: "auto" },
  hero: { gap: 10, paddingTop: 6 },
  eyebrow: { color: colors.brandPrimary, fontSize: 11, fontWeight: "800", letterSpacing: 1.6 },
  title: { color: colors.onSurface, fontSize: 32, lineHeight: 36, fontWeight: "800" },
  subtitle: { color: colors.onSurfaceSecondary, fontSize: 14, lineHeight: 21, maxWidth: 420 },
  formCard: {
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 18,
    padding: 18,
    gap: 15,
  },
  formHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  formTitle: { color: colors.onSurface, fontSize: 18, fontWeight: "800" },
  secure: { flexDirection: "row", alignItems: "center", gap: 5 },
  secureText: { color: colors.success, fontSize: 9, fontWeight: "800", letterSpacing: 1 },
  label: { fontSize: 10, fontWeight: "800", letterSpacing: 1.2, color: colors.muted, marginBottom: 8 },
  roleRow: { flexDirection: "row", gap: 7, flexWrap: "wrap" },
  roleChip: {
    minHeight: 40,
    paddingHorizontal: 12,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: colors.border,
    justifyContent: "center",
  },
  roleChipActive: { borderColor: colors.brandPrimary, backgroundColor: colors.brandTertiary },
  roleText: { color: colors.onSurfaceSecondary, fontSize: 12, fontWeight: "700" },
  roleTextActive: { color: colors.brandPrimary },
  error: { color: colors.error, fontSize: 12, lineHeight: 18 },
  primary: {
    minHeight: 52,
    borderRadius: 11,
    paddingHorizontal: 16,
    backgroundColor: colors.brandPrimary,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
  },
  primaryText: { color: colors.onBrandPrimary, fontSize: 12, fontWeight: "900", letterSpacing: 1 },
  pressed: { opacity: 0.85, transform: [{ scale: 0.99 }] },
  disabled: { opacity: 0.65 },
  orRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  line: { flex: 1, height: 1, backgroundColor: colors.divider },
  or: { color: colors.muted, fontSize: 10, fontWeight: "800" },
  google: {
    minHeight: 48,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: colors.border,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 9,
  },
  googleText: { color: colors.onSurface, fontSize: 11, fontWeight: "800", letterSpacing: 0.6 },
  demoSection: { gap: 10 },
  demoHeader: { color: colors.brandPrimary, fontSize: 11, fontWeight: "900", letterSpacing: 1.4 },
  demoNote: { color: colors.muted, fontSize: 12 },
  demoGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  demoChip: {
    minHeight: 44,
    paddingHorizontal: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surfaceSecondary,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  demoLabel: { color: colors.onSurface, fontSize: 12, fontWeight: "700" },
  switch: {
    flexDirection: "row",
    justifyContent: "center",
    gap: 5,
    minHeight: 44,
    alignItems: "center",
  },
  switchMuted: { color: colors.muted, fontSize: 13 },
  switchAction: { color: colors.brandPrimary, fontSize: 13, fontWeight: "800" },
  footer: {
    color: colors.muted,
    textAlign: "center",
    fontSize: 9,
    letterSpacing: 1.2,
    paddingTop: 4,
  },
}));
