import { MaterialCommunityIcons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, Switch, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api, MatchResult, MatchScore } from "@/src/api";
import { makeStyles, useTheme } from "@/src/theme";

const conditions = ["Critical patient", "Trauma", "Cardiac event", "Respiratory distress", "Stroke"];
const careOptions = ["ICU", "Trauma", "Cardiac", "General"];
const bloodTypes = ["O+", "O-", "A+", "A-", "B+", "AB+"];
const specialties = ["Trauma", "Cardiology", "Neurology", "Pediatrics", "Critical care"];

export default function MatchScreen() {
  const { colors } = useTheme();
  const styles = useStyles();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [condition, setCondition] = useState(conditions[0]);
  const [care, setCare] = useState(careOptions[0]);
  const [blood, setBlood] = useState(bloodTypes[0]);
  const [specialty, setSpecialty] = useState<string>("Trauma");
  const [oxygen, setOxygen] = useState(true);
  const [explain, setExplain] = useState(true);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<MatchResult | null>(null);
  const [error, setError] = useState("");

  const run = async () => {
    setBusy(true);
    setError("");
    try {
      const res = await api.match({
        condition,
        urgency: "High",
        required_care: care,
        blood_type: blood,
        oxygen_required: oxygen,
        specialty_needed: specialty,
        explain,
      });
      setResult(res as MatchResult);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Matching service unavailable");
    } finally {
      setBusy(false);
    }
  };

  return (
    <View style={[styles.root, { paddingTop: insets.top }]}>
      <ScrollView contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 24 }]}>
        <View style={styles.header}>
          <Pressable onPress={() => router.back()} style={styles.back} testID="match-back">
            <MaterialCommunityIcons name="arrow-left" size={21} color={colors.onSurface} />
          </Pressable>
          <View style={styles.headerCopy}>
            <Text style={styles.kicker}>EXPLAINABLE AI · 0-100</Text>
            <Text style={styles.title}>Hospital match</Text>
          </View>
          <View style={styles.aiMark}>
            <MaterialCommunityIcons name="creation" size={19} color={colors.brandPrimary} />
          </View>
        </View>
        <Text style={styles.intro}>
          Give the network a few routing signals. Medisync ranks live capacity, clinical fit,
          transfer time, and specialists — with a transparent 0-100 breakdown.
        </Text>

        <View style={styles.panel}>
          <FieldLabel label="PATIENT CONDITION" />
          <ChipRow values={conditions} selected={condition} onSelect={setCondition} />
          <FieldLabel label="REQUIRED CARE" />
          <ChipRow values={careOptions} selected={care} onSelect={setCare} />
          <FieldLabel label="BLOOD TYPE" />
          <ChipRow values={bloodTypes} selected={blood} onSelect={setBlood} />
          <FieldLabel label="SPECIALTY NEEDED" />
          <ChipRow values={specialties} selected={specialty} onSelect={setSpecialty} />
        </View>

        <View style={styles.togglePanel}>
          <View style={styles.toggleRow}>
            <View style={styles.toggleIcon}>
              <MaterialCommunityIcons name="gas-cylinder" size={18} color={colors.info} />
            </View>
            <View style={styles.toggleCopy}>
              <Text style={styles.toggleTitle}>Oxygen support required</Text>
              <Text style={styles.muted}>Prioritize facilities with reserve oxygen</Text>
            </View>
            <Switch
              testID="match-oxygen-toggle"
              value={oxygen}
              onValueChange={setOxygen}
              trackColor={{ false: colors.surfaceTertiary, true: colors.brandSecondary }}
              thumbColor={oxygen ? colors.brandPrimary : colors.muted}
            />
          </View>
          <View style={styles.toggleRow}>
            <View style={styles.toggleIcon}>
              <MaterialCommunityIcons name="creation" size={18} color={colors.brandPrimary} />
            </View>
            <View style={styles.toggleCopy}>
              <Text style={styles.toggleTitle}>Generate AI explanation</Text>
              <Text style={styles.muted}>Claude Sonnet 4.6 adds an operational rationale</Text>
            </View>
            <Switch
              testID="match-explain-toggle"
              value={explain}
              onValueChange={setExplain}
              trackColor={{ false: colors.surfaceTertiary, true: colors.brandSecondary }}
              thumbColor={explain ? colors.brandPrimary : colors.muted}
            />
          </View>
        </View>

        {error ? <Text style={styles.error}>{error}</Text> : null}
        <Pressable
          testID="run-match-button"
          onPress={() => void run()}
          disabled={busy}
          style={({ pressed }) => [styles.run, pressed && styles.pressed, busy && styles.disabled]}
        >
          {busy ? (
            <ActivityIndicator color={colors.onBrandPrimary} />
          ) : (
            <MaterialCommunityIcons name="creation" size={21} color={colors.onBrandPrimary} />
          )}
          <Text style={styles.runText}>{busy ? "EVALUATING LIVE CAPACITY…" : "RUN HOSPITAL MATCH"}</Text>
        </Pressable>

        {result ? (
          <Results result={result} />
        ) : (
          <View style={styles.empty}>
            <MaterialCommunityIcons name="radar" size={30} color={colors.muted} />
            <Text style={styles.emptyTitle}>Ready for triage signals</Text>
            <Text style={styles.muted}>Your ranked recommendations with score breakdowns will appear here.</Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

function FieldLabel({ label }: { label: string }) {
  const { colors } = useTheme();
  return (
    <Text style={{ color: colors.muted, fontSize: 10, fontWeight: "900", letterSpacing: 1.1 }}>{label}</Text>
  );
}

function ChipRow({
  values,
  selected,
  onSelect,
}: {
  values: string[];
  selected: string;
  onSelect: (value: string) => void;
}) {
  const { colors } = useTheme();
  return (
    <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 7 }}>
      {values.map((value) => (
        <Pressable
          testID={`match-chip-${value.toLowerCase().replace(/\s/g, "-")}`}
          key={value}
          onPress={() => onSelect(value)}
          style={{
            minHeight: 40,
            justifyContent: "center",
            paddingHorizontal: 11,
            borderRadius: 9,
            borderWidth: 1,
            borderColor: selected === value ? colors.brandPrimary : colors.border,
            backgroundColor: selected === value ? colors.brandTertiary : colors.surfaceTertiary,
          }}
        >
          <Text
            style={{
              color: selected === value ? colors.brandPrimary : colors.onSurfaceSecondary,
              fontSize: 12,
              fontWeight: "800",
            }}
          >
            {value}
          </Text>
        </Pressable>
      ))}
    </View>
  );
}

function Results({ result }: { result: MatchResult }) {
  const { colors } = useTheme();
  const styles = useResultsStyles();
  return (
    <View style={styles.results} testID="match-results">
      <View style={styles.resultHeader}>
        <View style={{ flex: 1 }}>
          <Text style={styles.kicker}>RECOMMENDED DESTINATION</Text>
          <Text style={styles.resultName}>{result.top_match.hospital.name}</Text>
          <Text style={styles.subline}>
            {result.top_match.distance_km} km · {result.top_match.eta_min} min ETA · {result.top_match.hospital.level}
          </Text>
        </View>
        <View style={styles.score}>
          <Text style={styles.scoreValue}>{result.top_match.score}</Text>
          <Text style={styles.scoreLabel}>/100</Text>
        </View>
      </View>

      <BreakdownBars match={result.top_match} />

      <View style={styles.explanation}>
        <View style={styles.explainTitle}>
          <MaterialCommunityIcons name="creation" size={17} color={colors.brandPrimary} />
          <Text style={styles.explainLabel}>AI EXPLANATION</Text>
        </View>
        <Text style={styles.explainText}>{result.explanation}</Text>
      </View>

      <Text style={styles.rankTitle}>OTHER LIVE OPTIONS</Text>
      {result.matches.slice(1, 4).map((item) => (
        <View key={item.hospital.resource_id} style={styles.rankRow}>
          <View style={styles.rankNumber}>
            <Text style={styles.rankNumberText}>{item.score}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.rankName}>{item.hospital.short_name}</Text>
            <Text style={styles.muted}>
              {item.hospital.icu_available} ICU open · {item.eta_min} min ETA · {item.distance_km} km
            </Text>
          </View>
          <MaterialCommunityIcons name="chevron-right" size={20} color={colors.muted} />
        </View>
      ))}
    </View>
  );
}

function BreakdownBars({ match }: { match: MatchScore }) {
  const { colors } = useTheme();
  const styles = useResultsStyles();
  const entries = Object.entries(match.breakdown);
  return (
    <View style={styles.breakdown}>
      <Text style={styles.breakdownHeader}>SCORE BREAKDOWN</Text>
      {entries.map(([key, val]) => {
        const pct = Math.round((val.points / val.max) * 100);
        return (
          <View key={key} style={styles.breakdownRow}>
            <View style={styles.breakdownTop}>
              <Text style={styles.breakdownLabel}>{key.toUpperCase()}</Text>
              <Text style={styles.breakdownPoints}>
                {val.points}
                <Text style={styles.breakdownMax}>/{val.max}</Text>
              </Text>
            </View>
            <View style={styles.barTrack}>
              <View
                style={[
                  styles.barFill,
                  {
                    width: `${pct}%`,
                    backgroundColor:
                      pct >= 66 ? colors.success : pct >= 33 ? colors.warning : colors.error,
                  },
                ]}
              />
            </View>
            <Text style={styles.breakdownDetail}>{val.detail}</Text>
          </View>
        );
      })}
    </View>
  );
}

const useStyles = makeStyles((colors) => ({
  root: { flex: 1, backgroundColor: colors.surface },
  content: { padding: 20, gap: 16, maxWidth: 720, width: "100%", alignSelf: "center" },
  header: { flexDirection: "row", alignItems: "center", gap: 12 },
  back: {
    width: 44, height: 44, borderRadius: 12,
    borderWidth: 1, borderColor: colors.border,
    alignItems: "center", justifyContent: "center",
  },
  headerCopy: { flex: 1 },
  kicker: { color: colors.brandPrimary, fontSize: 10, fontWeight: "900", letterSpacing: 1.2, marginBottom: 6 },
  title: { color: colors.onSurface, fontSize: 26, fontWeight: "900" },
  aiMark: {
    width: 40, height: 40, borderRadius: 12,
    backgroundColor: colors.brandTertiary,
    alignItems: "center", justifyContent: "center",
  },
  intro: { color: colors.onSurfaceSecondary, fontSize: 14, lineHeight: 21, marginBottom: 4 },
  panel: {
    backgroundColor: colors.surfaceSecondary, borderRadius: 16,
    borderWidth: 1, borderColor: colors.border, padding: 15, gap: 11,
  },
  togglePanel: {
    backgroundColor: colors.surfaceSecondary, borderRadius: 16,
    borderWidth: 1, borderColor: colors.border, paddingHorizontal: 14,
  },
  toggleRow: {
    minHeight: 72, flexDirection: "row", alignItems: "center", gap: 10,
    borderBottomWidth: 1, borderBottomColor: colors.divider,
  },
  toggleIcon: {
    width: 34, height: 34, borderRadius: 10,
    backgroundColor: colors.surfaceTertiary,
    alignItems: "center", justifyContent: "center",
  },
  toggleCopy: { flex: 1, gap: 3 },
  toggleTitle: { color: colors.onSurface, fontSize: 13, fontWeight: "800" },
  muted: { color: colors.muted, fontSize: 11, lineHeight: 17 },
  error: { color: colors.error, fontSize: 12 },
  run: {
    minHeight: 54, borderRadius: 12,
    backgroundColor: colors.brandPrimary,
    alignItems: "center", justifyContent: "center",
    flexDirection: "row", gap: 10,
  },
  runText: { color: colors.onBrandPrimary, fontSize: 12, fontWeight: "900", letterSpacing: 0.8 },
  pressed: { opacity: 0.82 },
  disabled: { opacity: 0.65 },
  empty: { alignItems: "center", justifyContent: "center", paddingVertical: 35, gap: 8 },
  emptyTitle: { color: colors.onSurface, fontSize: 16, fontWeight: "800" },
}));

const useResultsStyles = makeStyles((colors) => ({
  results: {
    backgroundColor: colors.surfaceSecondary, borderRadius: 17,
    borderWidth: 1, borderColor: colors.borderStrong, padding: 15, gap: 15,
  },
  resultHeader: { flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between", gap: 10 },
  kicker: { color: colors.brandPrimary, fontSize: 10, fontWeight: "900", letterSpacing: 1.1, marginBottom: 7 },
  resultName: { color: colors.onSurface, fontSize: 19, fontWeight: "900" },
  subline: { color: colors.muted, fontSize: 11, marginTop: 4 },
  score: {
    width: 78, height: 78, borderRadius: 40, borderWidth: 3,
    borderColor: colors.brandPrimary,
    alignItems: "center", justifyContent: "center",
    backgroundColor: colors.brandTertiary,
  },
  scoreValue: { color: colors.brandPrimary, fontSize: 24, fontWeight: "900" },
  scoreLabel: { color: colors.muted, fontSize: 9, fontWeight: "900", letterSpacing: 0.6 },
  breakdown: { gap: 10 },
  breakdownHeader: { color: colors.muted, fontSize: 10, fontWeight: "900", letterSpacing: 1.1 },
  breakdownRow: { gap: 6 },
  breakdownTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "baseline" },
  breakdownLabel: { color: colors.onSurface, fontSize: 12, fontWeight: "800", letterSpacing: 0.6 },
  breakdownPoints: { color: colors.onSurface, fontSize: 13, fontWeight: "900" },
  breakdownMax: { color: colors.muted, fontSize: 11, fontWeight: "600" },
  barTrack: { height: 6, borderRadius: 4, backgroundColor: colors.surfaceTertiary, overflow: "hidden" },
  barFill: { height: 6, borderRadius: 4 },
  breakdownDetail: { color: colors.muted, fontSize: 11 },
  explanation: { backgroundColor: colors.brandTertiary, borderRadius: 12, padding: 12, gap: 8 },
  explainTitle: { flexDirection: "row", alignItems: "center", gap: 7 },
  explainLabel: { color: colors.brandPrimary, fontSize: 10, fontWeight: "900", letterSpacing: 1 },
  explainText: { color: colors.onSurface, fontSize: 13, lineHeight: 19 },
  rankTitle: { color: colors.muted, fontSize: 10, fontWeight: "900", letterSpacing: 1 },
  rankRow: {
    minHeight: 60, flexDirection: "row", alignItems: "center", gap: 10,
    borderTopWidth: 1, borderTopColor: colors.divider, paddingVertical: 8,
  },
  rankNumber: {
    width: 44, height: 44, borderRadius: 12,
    backgroundColor: colors.surfaceTertiary,
    justifyContent: "center", alignItems: "center",
  },
  rankNumberText: { color: colors.onSurface, fontSize: 14, fontWeight: "900" },
  rankName: { color: colors.onSurface, fontSize: 13, fontWeight: "800", marginBottom: 3 },
  muted: { color: colors.muted, fontSize: 11 },
}));
