import { MaterialCommunityIcons } from "@expo/vector-icons";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { AmbulanceRoute, api } from "@/src/api";
import { useAuth } from "@/src/auth";
import { makeStyles, useTheme } from "@/src/theme";

export default function RouteScreen() {
  const { colors } = useTheme();
  const styles = useStyles();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { user } = useAuth();
  const params = useLocalSearchParams<{ amb?: string }>();
  const ambId = String(params.amb ?? user?.facility_id ?? "amb-01");

  const [route, setRoute] = useState<AmbulanceRoute | null>(null);
  const [error, setError] = useState("");
  const [progressIdx, setProgressIdx] = useState(0);
  const [playing, setPlaying] = useState(true);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    api
      .ambulanceRoute(ambId)
      .then((r) => {
        setRoute(r);
        setProgressIdx(0);
      })
      .catch((caught) => setError(caught instanceof Error ? caught.message : "Route unavailable"));
  }, [ambId]);

  useEffect(() => {
    if (!route || !playing) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }
    timerRef.current = setInterval(() => {
      setProgressIdx((idx) => Math.min(idx + 1, (route?.route.waypoints.length ?? 1) - 1));
    }, 2000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [route, playing]);

  if (error) {
    return (
      <View style={styles.center}>
        <MaterialCommunityIcons name="map-marker-off-outline" size={30} color={colors.muted} />
        <Text style={styles.muted}>{error}</Text>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backBtnText}>GO BACK</Text>
        </Pressable>
      </View>
    );
  }

  if (!route) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.brandPrimary} />
        <Text style={styles.muted}>Calculating live route…</Text>
      </View>
    );
  }

  const wp = route.route.waypoints[progressIdx];
  const done = progressIdx >= route.route.waypoints.length - 1;
  const nextWp = route.route.waypoints[Math.min(progressIdx + 1, route.route.waypoints.length - 1)];

  return (
    <View style={[styles.root, { paddingTop: insets.top }]}>
      <ScrollView contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 24 }]}>
        <View style={styles.header}>
          <Pressable testID="route-back" onPress={() => router.back()} style={styles.back}>
            <MaterialCommunityIcons name="arrow-left" size={21} color={colors.onSurface} />
          </Pressable>
          <View style={{ flex: 1 }}>
            <Text style={styles.kicker}>LIVE ROUTE · {route.ambulance.unit}</Text>
            <Text style={styles.title}>{route.destination.short_name}</Text>
          </View>
          <View style={[styles.playIcon, { backgroundColor: playing ? colors.success : colors.warning }]}>
            <View style={styles.playDot} />
          </View>
        </View>

        <RouteMap route={route} progressIdx={progressIdx} />

        <View style={styles.etaCard}>
          <View style={{ flex: 1 }}>
            <Text style={styles.etaLabel}>ETA REMAINING</Text>
            <Text style={styles.etaValue}>
              {done ? "ARRIVED" : `${Math.max(0, wp.eta_min)} min`}
            </Text>
            <Text style={styles.muted}>
              {done ? "Handoff to receiving team" : `${wp.distance_remaining_km} km to hospital · progress ${Math.round(wp.progress_pct)}%`}
            </Text>
          </View>
          <Pressable
            testID="route-playpause"
            onPress={() => setPlaying((p) => !p)}
            style={styles.playPause}
          >
            <MaterialCommunityIcons
              name={playing ? "pause" : "play"}
              size={22}
              color={colors.onBrandPrimary}
            />
          </Pressable>
        </View>

        <View style={styles.turnCard}>
          <View style={styles.turnIcon}>
            <MaterialCommunityIcons
              name={done ? "flag-checkered" : "arrow-right-bold"}
              size={26}
              color={colors.brandPrimary}
            />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.turnLabel}>{done ? "FINAL STEP" : "NEXT MANEUVER"}</Text>
            <Text style={styles.turnText}>{done ? wp.maneuver : nextWp.maneuver}</Text>
          </View>
        </View>

        <View style={styles.progressCard}>
          <Text style={styles.panelHeader}>ROUTE PROGRESS</Text>
          <View style={styles.progressTrack}>
            <View
              style={[
                styles.progressFill,
                { width: `${wp.progress_pct}%` },
              ]}
            />
          </View>
          <View style={styles.progressMeta}>
            <Text style={styles.muted}>{Math.round(wp.progress_pct)}% complete</Text>
            <Text style={styles.muted}>
              {route.route.total_distance_km} km total · traffic ×{route.route.traffic_factor.toFixed(1)}
            </Text>
          </View>
        </View>

        <View style={styles.destCard}>
          <Text style={styles.panelHeader}>DESTINATION FACILITY</Text>
          <Text style={styles.destName}>{route.destination.name}</Text>
          <View style={styles.destStatsRow}>
            <Stat label="ICU OPEN" value={`${route.destination.icu_available}/${route.destination.icu_total}`} />
            <Stat label="ER WAIT" value={`${route.destination.er_wait_min}m`} />
            <Stat label="STEPS" value={`${progressIdx + 1}/${route.route.waypoints.length}`} />
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

function RouteMap({
  route,
  progressIdx,
}: {
  route: AmbulanceRoute;
  progressIdx: number;
}) {
  const { colors } = useTheme();
  const styles = useStyles();
  const wp = route.route.waypoints;
  const lats = wp.map((w) => w.lat);
  const lngs = wp.map((w) => w.lng);
  const minLat = Math.min(...lats);
  const maxLat = Math.max(...lats);
  const minLng = Math.min(...lngs);
  const maxLng = Math.max(...lngs);
  const padLat = Math.max(0.005, (maxLat - minLat) * 0.15);
  const padLng = Math.max(0.005, (maxLng - minLng) * 0.15);
  const toX = (lng: number) =>
    ((lng - (minLng - padLng)) / (maxLng + padLng - (minLng - padLng))) * 100;
  const toY = (lat: number) =>
    100 - ((lat - (minLat - padLat)) / (maxLat + padLat - (minLat - padLat))) * 100;

  const current = wp[progressIdx];
  return (
    <View style={styles.map} testID="route-map">
      <View style={styles.mapGrid}>
        {[1, 2, 3, 4].map((r) => (
          <View key={r} style={styles.gridLine} />
        ))}
      </View>
      <Text style={styles.mapLabel}>NASHIK · LIVE GPS</Text>

      {/* Path dots */}
      {wp.map((w, i) => (
        <View
          key={i}
          style={[
            styles.pathDot,
            {
              left: `${toX(w.lng)}%`,
              top: `${toY(w.lat)}%`,
              backgroundColor:
                i <= progressIdx ? colors.brandPrimary : colors.divider,
              width: i === wp.length - 1 ? 0 : 6,
              height: i === wp.length - 1 ? 0 : 6,
            },
          ]}
        />
      ))}

      {/* Destination pin */}
      <View
        style={[
          styles.destPin,
          { left: `${toX(wp[wp.length - 1].lng)}%`, top: `${toY(wp[wp.length - 1].lat)}%` },
        ]}
      >
        <MaterialCommunityIcons name="hospital-building" size={16} color={colors.onError} />
      </View>

      {/* Ambulance pin */}
      <View
        style={[
          styles.ambPin,
          { left: `${toX(current.lng)}%`, top: `${toY(current.lat)}%` },
        ]}
      >
        <MaterialCommunityIcons name="ambulance" size={16} color={colors.onBrandPrimary} />
      </View>
    </View>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  const { colors } = useTheme();
  const styles = useStyles();
  return (
    <View style={styles.stat}>
      <Text style={[styles.statValue, { color: colors.brandPrimary }]}>{value}</Text>
      <Text style={styles.muted}>{label}</Text>
    </View>
  );
}

const useStyles = makeStyles((colors) => ({
  root: { flex: 1, backgroundColor: colors.surface },
  content: { padding: 20, gap: 14, maxWidth: 720, width: "100%", alignSelf: "center" },
  center: {
    flex: 1, backgroundColor: colors.surface,
    alignItems: "center", justifyContent: "center", gap: 12, padding: 32,
  },
  header: { flexDirection: "row", alignItems: "center", gap: 12 },
  back: {
    width: 44, height: 44, borderRadius: 12,
    borderWidth: 1, borderColor: colors.border,
    alignItems: "center", justifyContent: "center",
  },
  kicker: { color: colors.brandPrimary, fontSize: 10, fontWeight: "900", letterSpacing: 1.2, marginBottom: 6 },
  title: { color: colors.onSurface, fontSize: 24, fontWeight: "900" },
  playIcon: {
    width: 40, height: 40, borderRadius: 20,
    alignItems: "center", justifyContent: "center",
  },
  playDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: colors.onBrandPrimary },
  map: {
    minHeight: 280, borderRadius: 16,
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1, borderColor: colors.border,
    overflow: "hidden", position: "relative",
  },
  mapGrid: { ...StyleSheet.absoluteFillObject, padding: 30, gap: 50, justifyContent: "space-around" },
  gridLine: { height: 1, backgroundColor: colors.divider },
  mapLabel: {
    position: "absolute", top: 14, left: 14,
    color: colors.muted, fontSize: 9, fontWeight: "900", letterSpacing: 1,
  },
  pathDot: {
    position: "absolute", borderRadius: 3,
    marginLeft: -3, marginTop: -3,
  },
  destPin: {
    position: "absolute", width: 36, height: 36, borderRadius: 18,
    backgroundColor: colors.error, alignItems: "center", justifyContent: "center",
    borderWidth: 3, borderColor: colors.surfaceSecondary,
    marginLeft: -18, marginTop: -18,
  },
  ambPin: {
    position: "absolute", width: 36, height: 36, borderRadius: 18,
    backgroundColor: colors.brandPrimary, alignItems: "center", justifyContent: "center",
    borderWidth: 3, borderColor: colors.surfaceSecondary,
    marginLeft: -18, marginTop: -18,
  },
  etaCard: {
    padding: 14, borderRadius: 14,
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1, borderColor: colors.border,
    flexDirection: "row", alignItems: "center", gap: 12,
  },
  etaLabel: { color: colors.muted, fontSize: 10, fontWeight: "900", letterSpacing: 1.1 },
  etaValue: { color: colors.brandPrimary, fontSize: 32, fontWeight: "900", marginVertical: 4 },
  muted: { color: colors.muted, fontSize: 12 },
  playPause: {
    width: 54, height: 54, borderRadius: 27,
    backgroundColor: colors.brandPrimary,
    alignItems: "center", justifyContent: "center",
  },
  turnCard: {
    padding: 14, borderRadius: 14,
    backgroundColor: colors.brandTertiary,
    borderWidth: 1, borderColor: colors.borderStrong,
    flexDirection: "row", alignItems: "center", gap: 12,
  },
  turnIcon: {
    width: 48, height: 48, borderRadius: 14,
    backgroundColor: colors.surface,
    alignItems: "center", justifyContent: "center",
  },
  turnLabel: { color: colors.brandPrimary, fontSize: 10, fontWeight: "900", letterSpacing: 1 },
  turnText: { color: colors.onSurface, fontSize: 15, fontWeight: "800", marginTop: 4 },
  progressCard: {
    padding: 14, borderRadius: 14,
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1, borderColor: colors.border, gap: 8,
  },
  panelHeader: { color: colors.muted, fontSize: 10, fontWeight: "900", letterSpacing: 1.1 },
  progressTrack: {
    height: 8, borderRadius: 4,
    backgroundColor: colors.surfaceTertiary, overflow: "hidden",
  },
  progressFill: { height: 8, borderRadius: 4, backgroundColor: colors.brandPrimary },
  progressMeta: { flexDirection: "row", justifyContent: "space-between" },
  destCard: {
    padding: 14, borderRadius: 14,
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1, borderColor: colors.border, gap: 8,
  },
  destName: { color: colors.onSurface, fontSize: 15, fontWeight: "800" },
  destStatsRow: {
    flexDirection: "row", justifyContent: "space-between",
    paddingTop: 8, borderTopWidth: 1, borderTopColor: colors.divider,
  },
  stat: { alignItems: "center", gap: 4 },
  statValue: { fontSize: 18, fontWeight: "900" },
  backBtn: {
    minHeight: 44, paddingHorizontal: 20, borderRadius: 10,
    borderWidth: 1, borderColor: colors.brandPrimary, justifyContent: "center",
  },
  backBtnText: { color: colors.brandPrimary, fontSize: 12, fontWeight: "900" },
}));
