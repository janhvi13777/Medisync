import { MaterialCommunityIcons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useState } from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api, TriageResult } from "@/src/api";
import { makeStyles, useTheme } from "@/src/theme";

const CONSCIOUSNESS = ["alert", "verbal", "pain", "unresponsive"];

export default function TriageScreen() {
  const { colors } = useTheme();
  const styles = useStyles();
  const insets = useSafeAreaInsets();
  const router = useRouter();

  const [name, setName] = useState("Unknown");
  const [age, setAge] = useState("40");
  const [complaint, setComplaint] = useState("Chest pain, 45 minutes, radiating");
  const [sbp, setSbp] = useState("108");
  const [dbp, setDbp] = useState("72");
  const [hr, setHr] = useState("118");
  const [rr, setRr] = useState("24");
  const [spo2, setSpo2] = useState("91");
  const [temp, setTemp] = useState("37.2");
  const [consc, setConsc] = useState("alert");
  const [trauma, setTrauma] = useState(false);

  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<TriageResult | null>(null);
  const [error, setError] = useState("");

  const run = async () => {
    setBusy(true);
    setError("");
    try {
      const res = await api.triage({
        patient_name: name,
        age: Number(age) || 40,
        sex: "unknown",
        chief_complaint: complaint,
        systolic_bp: Number(sbp) || 120,
        diastolic_bp: Number(dbp) || 80,
        heart_rate: Number(hr) || 80,
        respiratory_rate: Number(rr) || 16,
        spo2: Number(spo2) || 98,
        temperature_c: Number(temp) || 37,
        consciousness: consc,
        trauma,
      });
      setResult(res as TriageResult);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Triage service unavailable");
    } finally {
      setBusy(false);
    }
  };

  const severityColor = (s?: string) =>
    s === "critical" ? colors.error : s === "urgent" ? colors.warning : s === "moderate" ? colors.info : colors.success;

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={[styles.root, { paddingTop: insets.top }]}
    >
      <ScrollView
        contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 24 }]}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.header}>
          <Pressable onPress={() => router.back()} style={styles.back} testID="triage-back">
            <MaterialCommunityIcons name="arrow-left" size={21} color={colors.onSurface} />
          </Pressable>
          <View style={{ flex: 1 }}>
            <Text style={styles.kicker}>AI EMERGENCY TRIAGE</Text>
            <Text style={styles.title}>Assess vitals</Text>
          </View>
          <View style={styles.aiMark}>
            <MaterialCommunityIcons name="pulse" size={20} color={colors.brandPrimary} />
          </View>
        </View>

        <Text style={styles.intro}>
          Enter patient vitals and complaint. Medisync will score severity, flag concerns, and
          recommend care level plus specialty.
        </Text>

        <View style={styles.panel}>
          <NumField testID="triage-name" label="PATIENT NAME" value={name} onChangeText={setName} keyboardType="default" />
          <View style={styles.row2}>
            <NumField testID="triage-age" label="AGE" value={age} onChangeText={setAge} />
            <View style={{ flex: 2 }}>
              <Text style={styles.fieldLabel}>CHIEF COMPLAINT</Text>
              <TextInput
                testID="triage-complaint"
                value={complaint}
                onChangeText={setComplaint}
                placeholder="e.g. chest pain, MVA polytrauma"
                placeholderTextColor={colors.muted}
                style={styles.input}
              />
            </View>
          </View>
        </View>

        <View style={styles.panel}>
          <Text style={styles.panelHeader}>VITALS</Text>
          <View style={styles.grid}>
            <NumField testID="triage-sbp" label="SBP mmHg" value={sbp} onChangeText={setSbp} />
            <NumField testID="triage-dbp" label="DBP mmHg" value={dbp} onChangeText={setDbp} />
            <NumField testID="triage-hr" label="HEART RATE" value={hr} onChangeText={setHr} />
            <NumField testID="triage-rr" label="RESP RATE" value={rr} onChangeText={setRr} />
            <NumField testID="triage-spo2" label="SpO₂ %" value={spo2} onChangeText={setSpo2} />
            <NumField testID="triage-temp" label="TEMP °C" value={temp} onChangeText={setTemp} keyboardType="decimal-pad" />
          </View>
        </View>

        <View style={styles.panel}>
          <Text style={styles.panelHeader}>CONSCIOUSNESS (AVPU)</Text>
          <View style={styles.chipRow}>
            {CONSCIOUSNESS.map((c) => (
              <Pressable
                key={c}
                testID={`triage-avpu-${c}`}
                onPress={() => setConsc(c)}
                style={[styles.chip, consc === c && styles.chipActive]}
              >
                <Text style={[styles.chipText, consc === c && styles.chipTextActive]}>{c.toUpperCase()}</Text>
              </Pressable>
            ))}
          </View>
          <Pressable
            testID="triage-trauma"
            onPress={() => setTrauma((v) => !v)}
            style={[styles.traumaRow, trauma && styles.traumaActive]}
          >
            <MaterialCommunityIcons
              name={trauma ? "checkbox-marked" : "checkbox-blank-outline"}
              size={22}
              color={trauma ? colors.brandPrimary : colors.muted}
            />
            <Text style={styles.traumaText}>Trauma mechanism suspected</Text>
          </Pressable>
        </View>

        {error ? <Text style={styles.error}>{error}</Text> : null}

        <Pressable
          testID="run-triage-button"
          onPress={() => void run()}
          disabled={busy}
          style={({ pressed }) => [styles.run, pressed && styles.pressed, busy && styles.disabled]}
        >
          {busy ? (
            <ActivityIndicator color={colors.onBrandPrimary} />
          ) : (
            <MaterialCommunityIcons name="pulse" size={21} color={colors.onBrandPrimary} />
          )}
          <Text style={styles.runText}>{busy ? "ASSESSING VITALS…" : "RUN AI TRIAGE"}</Text>
        </Pressable>

        {result ? (
          <View style={styles.result} testID="triage-result">
            <View style={styles.resultHeader}>
              <View>
                <Text style={styles.kicker}>ASSESSMENT</Text>
                <Text style={[styles.severity, { color: severityColor(result.assessment.severity) }]}>
                  {result.assessment.severity.toUpperCase()}
                </Text>
              </View>
              <View
                style={[
                  styles.scoreBadge,
                  { borderColor: severityColor(result.assessment.severity) },
                ]}
              >
                <Text style={[styles.scoreValue, { color: severityColor(result.assessment.severity) }]}>
                  {result.assessment.score}
                </Text>
                <Text style={styles.scoreLabel}>SCORE</Text>
              </View>
            </View>

            {result.assessment.flags.length > 0 ? (
              <View style={styles.flagRow}>
                {result.assessment.flags.map((flag) => (
                  <View key={flag} style={styles.flagChip}>
                    <MaterialCommunityIcons name="alert-outline" size={13} color={colors.warning} />
                    <Text style={styles.flagText}>{flag}</Text>
                  </View>
                ))}
              </View>
            ) : null}

            <View style={styles.recRow}>
              <RecPill label="ICU" active={result.assessment.recommend_icu} />
              <RecPill label="VENTILATOR" active={result.assessment.recommend_ventilator} />
              <RecPill label="BLOOD READY" active={result.assessment.recommend_blood_ready} />
            </View>

            <View style={styles.specialty}>
              <MaterialCommunityIcons name="stethoscope" size={18} color={colors.brandPrimary} />
              <View style={{ flex: 1 }}>
                <Text style={styles.specialtyLabel}>RECOMMENDED SPECIALTY</Text>
                <Text style={styles.specialtyValue}>{result.assessment.recommend_specialty}</Text>
              </View>
            </View>

            <View style={styles.narrative}>
              <View style={styles.narrativeHeader}>
                <MaterialCommunityIcons name="creation" size={16} color={colors.brandPrimary} />
                <Text style={styles.narrativeLabel}>AI NARRATIVE</Text>
              </View>
              <Text style={styles.narrativeText}>{result.narrative}</Text>
            </View>

            <Pressable
              testID="triage-to-match"
              onPress={() => router.push("/match")}
              style={styles.matchBtn}
            >
              <MaterialCommunityIcons name="hospital-marker" size={18} color={colors.onBrandPrimary} />
              <Text style={styles.matchBtnText}>MATCH TO HOSPITAL</Text>
              <MaterialCommunityIcons name="arrow-right" size={18} color={colors.onBrandPrimary} />
            </Pressable>
          </View>
        ) : null}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

function NumField({
  testID,
  label,
  value,
  onChangeText,
  keyboardType = "number-pad",
}: {
  testID: string;
  label: string;
  value: string;
  onChangeText: (v: string) => void;
  keyboardType?: "number-pad" | "decimal-pad" | "default";
}) {
  const { colors } = useTheme();
  const styles = useStyles();
  return (
    <View style={{ flex: 1, minWidth: 90 }}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <TextInput
        testID={testID}
        value={value}
        onChangeText={onChangeText}
        placeholderTextColor={colors.muted}
        keyboardType={keyboardType}
        style={styles.input}
      />
    </View>
  );
}

function RecPill({ label, active }: { label: string; active: boolean }) {
  const { colors } = useTheme();
  const styles = useStyles();
  return (
    <View
      style={[
        styles.recPill,
        {
          backgroundColor: active ? colors.brandPrimary : colors.surfaceTertiary,
          borderColor: active ? colors.brandPrimary : colors.border,
        },
      ]}
    >
      <MaterialCommunityIcons
        name={active ? "check-circle" : "circle-outline"}
        size={13}
        color={active ? colors.onBrandPrimary : colors.muted}
      />
      <Text
        style={[
          styles.recPillText,
          { color: active ? colors.onBrandPrimary : colors.muted },
        ]}
      >
        {label}
      </Text>
    </View>
  );
}

const useStyles = makeStyles((colors) => ({
  root: { flex: 1, backgroundColor: colors.surface },
  content: { padding: 20, gap: 16, maxWidth: 720, width: "100%", alignSelf: "center" },
  header: { flexDirection: "row", alignItems: "center", gap: 12 },
  back: {
    width: 44, height: 44, borderRadius: 12,
    borderWidth: 1, borderColor: colors.border,
    alignItems: "center", justifyContent: "center",
  },
  kicker: { color: colors.brandPrimary, fontSize: 10, fontWeight: "900", letterSpacing: 1.2, marginBottom: 6 },
  title: { color: colors.onSurface, fontSize: 26, fontWeight: "900" },
  aiMark: {
    width: 40, height: 40, borderRadius: 12,
    backgroundColor: colors.brandTertiary,
    alignItems: "center", justifyContent: "center",
  },
  intro: { color: colors.onSurfaceSecondary, fontSize: 14, lineHeight: 21 },
  panel: {
    backgroundColor: colors.surfaceSecondary,
    borderRadius: 16, borderWidth: 1, borderColor: colors.border,
    padding: 15, gap: 12,
  },
  panelHeader: { color: colors.muted, fontSize: 10, fontWeight: "900", letterSpacing: 1.1 },
  row2: { flexDirection: "row", gap: 10 },
  grid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  fieldLabel: { color: colors.muted, fontSize: 10, fontWeight: "900", letterSpacing: 1.0, marginBottom: 6 },
  input: {
    minHeight: 46, borderWidth: 1, borderRadius: 10,
    borderColor: colors.border, backgroundColor: colors.surfaceTertiary,
    paddingHorizontal: 12, color: colors.onSurface, fontSize: 15,
  },
  chipRow: { flexDirection: "row", flexWrap: "wrap", gap: 7 },
  chip: {
    minHeight: 40, paddingHorizontal: 12, borderRadius: 10,
    borderWidth: 1, borderColor: colors.border,
    backgroundColor: colors.surfaceTertiary, justifyContent: "center",
  },
  chipActive: { borderColor: colors.brandPrimary, backgroundColor: colors.brandTertiary },
  chipText: { color: colors.muted, fontSize: 11, fontWeight: "800", letterSpacing: 0.6 },
  chipTextActive: { color: colors.brandPrimary },
  traumaRow: {
    flexDirection: "row", alignItems: "center", gap: 10, minHeight: 44,
    paddingHorizontal: 10, borderRadius: 10,
    borderWidth: 1, borderColor: colors.border,
  },
  traumaActive: { borderColor: colors.brandPrimary, backgroundColor: colors.brandTertiary },
  traumaText: { color: colors.onSurface, fontSize: 13, fontWeight: "700" },
  error: { color: colors.error, fontSize: 12 },
  run: {
    minHeight: 54, borderRadius: 12,
    backgroundColor: colors.brandPrimary,
    alignItems: "center", justifyContent: "center",
    flexDirection: "row", gap: 10,
  },
  runText: { color: colors.onBrandPrimary, fontSize: 12, fontWeight: "900", letterSpacing: 0.8 },
  pressed: { opacity: 0.82 },
  disabled: { opacity: 0.65 },
  result: {
    backgroundColor: colors.surfaceSecondary,
    borderRadius: 17, borderWidth: 1, borderColor: colors.borderStrong,
    padding: 16, gap: 14,
  },
  resultHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" },
  severity: { fontSize: 22, fontWeight: "900", letterSpacing: 0.5 },
  scoreBadge: {
    width: 66, height: 66, borderRadius: 33, borderWidth: 2,
    alignItems: "center", justifyContent: "center",
  },
  scoreValue: { fontSize: 22, fontWeight: "900" },
  scoreLabel: { color: colors.muted, fontSize: 8, fontWeight: "900" },
  flagRow: { flexDirection: "row", flexWrap: "wrap", gap: 6 },
  flagChip: {
    flexDirection: "row", alignItems: "center", gap: 5,
    paddingHorizontal: 8, paddingVertical: 5, borderRadius: 8,
    backgroundColor: colors.brandTertiary,
  },
  flagText: { color: colors.warning, fontSize: 11, fontWeight: "700" },
  recRow: { flexDirection: "row", gap: 8, flexWrap: "wrap" },
  recPill: {
    minHeight: 32, paddingHorizontal: 12,
    borderRadius: 999, borderWidth: 1,
    flexDirection: "row", alignItems: "center", gap: 6,
  },
  recPillText: { fontSize: 10, fontWeight: "900", letterSpacing: 0.6 },
  specialty: {
    flexDirection: "row", alignItems: "center", gap: 10,
    padding: 12, borderRadius: 12, backgroundColor: colors.surfaceTertiary,
  },
  specialtyLabel: { color: colors.muted, fontSize: 10, fontWeight: "900", letterSpacing: 0.8 },
  specialtyValue: { color: colors.onSurface, fontSize: 15, fontWeight: "800", marginTop: 3 },
  narrative: {
    padding: 12, borderRadius: 12, backgroundColor: colors.brandTertiary, gap: 8,
  },
  narrativeHeader: { flexDirection: "row", alignItems: "center", gap: 7 },
  narrativeLabel: { color: colors.brandPrimary, fontSize: 10, fontWeight: "900", letterSpacing: 1 },
  narrativeText: { color: colors.onSurface, fontSize: 13, lineHeight: 19 },
  matchBtn: {
    minHeight: 48, borderRadius: 11,
    backgroundColor: colors.brandPrimary,
    flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10,
  },
  matchBtnText: { color: colors.onBrandPrimary, fontSize: 12, fontWeight: "900", letterSpacing: 0.7 },
}));
