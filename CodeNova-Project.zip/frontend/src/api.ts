import Constants from "expo-constants";

import { storage } from "@/src/utils/storage";

export const AUTH_TOKEN_KEY = "medisync.session_token";
const backendUrl = String(
  Constants.expoConfig?.extra?.backendUrl ??
    process.env.EXPO_PUBLIC_BACKEND_URL ??
    process.env.EXPO_BACKEND_URL ??
    "",
).replace(/\/$/, "");

export type Role = "coordinator" | "hospital_admin" | "ambulance" | "specialist" | "doctor" | "admin";

export type User = {
  user_id: string;
  email: string;
  name: string;
  role: Role;
  organization: string;
  facility_id?: string | null;
  avatar_initials: string;
};

export type Hospital = {
  resource_id: string;
  name: string;
  short_name: string;
  lat: number;
  lng: number;
  beds_available: number;
  beds_total: number;
  icu_available: number;
  icu_total: number;
  er_wait_min: number;
  specialists: string[];
  oxygen: boolean;
  blood: string[];
  status: string;
  accent: string;
  level: string;
  traffic_factor: number;
};

export type Ambulance = {
  resource_id: string;
  unit: string;
  crew: string;
  sector: string;
  lat: number;
  lng: number;
  eta_min: number;
  status: string;
  destination: string;
  patient_on_board: boolean;
  color: string;
};

export type Specialist = {
  resource_id: string;
  name: string;
  specialty: string;
  facility: string;
  facility_id: string;
  status: string;
  response_min: number;
  initials: string;
  on_call: boolean;
};

export type Supply = {
  resource_id: string;
  name: string;
  category: string;
  quantity: number;
  unit: string;
  threshold: number;
  location: string;
  status: string;
};

export type Patient = {
  resource_id: string;
  fhir_id: string;
  name: string;
  age: number;
  sex: string;
  condition: string;
  severity: string;
  assigned_ambulance?: string;
  assigned_hospital?: string;
  eta_min?: number;
};

export type Alert = { id: string; type: string; title: string; detail: string; time: string };

export type CoordinatorDashboard = {
  role: "coordinator" | "admin";
  connection: { status: string; label: string; last_sync: string };
  metrics: {
    available_beds: number;
    total_beds: number;
    available_icu: number;
    total_icu: number;
    active_units: number;
    low_supplies: number;
    hospitals_online: number;
  };
  hospitals: Hospital[];
  ambulances: Ambulance[];
  patients: Patient[];
  alerts: Alert[];
};

export type HospitalDashboard = {
  role: "hospital_admin";
  connection: { status: string; label: string; last_sync: string };
  hospital: Hospital;
  inbound_ambulances: (Ambulance & { patient?: Patient | null })[];
  metrics: {
    available_beds: number;
    total_beds: number;
    available_icu: number;
    total_icu: number;
    er_wait_min: number;
    inbound: number;
  };
  alerts: Alert[];
};

export type AmbulanceDashboard = {
  role: "ambulance";
  connection: { status: string; label: string; last_sync: string };
  ambulance: Ambulance;
  patient: Patient | null;
  destination: Hospital | null;
  metrics: { eta_min: number; sector: string; status: string; patient_on_board: boolean };
  alerts: Alert[];
};

export type SpecialistDashboard = {
  role: "specialist";
  connection: { status: string; label: string; last_sync: string };
  specialist: Specialist | null;
  consults: Patient[];
  metrics: { status: string; response_min: number; pending_consults: number };
  alerts: Alert[];
};

export type DoctorDashboard = {
  role: "doctor";
  connection: { status: string; label: string; last_sync: string };
  hospital: Hospital;
  patients: Patient[];
  metrics: { active_cases: number; critical: number; er_wait_min: number };
  alerts: Alert[];
};

export type Dashboard =
  | CoordinatorDashboard
  | HospitalDashboard
  | AmbulanceDashboard
  | SpecialistDashboard
  | DoctorDashboard;

export type ScoreBreakdown = Record<string, { points: number; max: number; detail: string }>;

export type MatchScore = {
  hospital: Hospital;
  score: number;
  eta_min: number;
  distance_km: number;
  breakdown: ScoreBreakdown;
  reasons: string[];
};

export type MatchResult = {
  request: Record<string, unknown>;
  matches: MatchScore[];
  top_match: MatchScore;
  explanation: string;
  engine: string;
};

export type TriageResult = {
  request: Record<string, unknown>;
  assessment: {
    severity: "critical" | "urgent" | "moderate" | "stable";
    score: number;
    flags: string[];
    recommend_icu: boolean;
    recommend_ventilator: boolean;
    recommend_specialty: string;
    recommend_blood_ready: boolean;
  };
  narrative: string;
  engine: string;
};

export type Forecast = {
  resource_id: string;
  resource: string;
  region: string;
  current: number;
  predicted_6h: number;
  predicted_24h: number;
  risk: "low" | "medium" | "high";
  advice: string;
};

export type DisasterPlanItem = {
  hospital_id: string;
  hospital_name: string;
  distance_km: number;
  eta_min: number;
  assigned: { critical: number; urgent: number; moderate: number; total: number };
  capacity_after: { icu_remaining: number; ventilator_remaining: number; beds_remaining: number };
  emergency_status: string;
};

export type DisasterResult = {
  scenario_id: string;
  scenario_name: string;
  patients: { critical: number; urgent: number; moderate: number; total: number };
  unassigned: { critical: number; urgent: number; moderate: number };
  hospitals_used: number;
  hospitals_in_range: number;
  total_assigned: number;
  plan: DisasterPlanItem[];
  active: boolean;
};

export type RouteWaypoint = {
  index: number;
  lat: number;
  lng: number;
  eta_min: number;
  progress_pct: number;
  maneuver: string;
  distance_remaining_km: number;
};

export type AmbulanceRoute = {
  ambulance: { resource_id: string; unit: string; crew: string; lat: number; lng: number; status: string };
  destination: {
    resource_id: string;
    name: string;
    short_name: string;
    lat: number;
    lng: number;
    icu_available: number;
    icu_total: number;
    er_wait_min: number;
  };
  route: {
    total_distance_km: number;
    total_eta_min: number;
    traffic_factor: number;
    waypoints: RouteWaypoint[];
  };
};

export type Consult = {
  consult_id: string;
  room_id: string;
  specialist_id: string;
  specialist_name: string;
  specialist_specialty: string;
  specialist_initials: string;
  patient_id?: string | null;
  patient_summary: string;
  reason: string;
  initiator_id: string;
  initiator_name: string;
  initiator_role: string;
  status: string;
  started_at: string;
};

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = await storage.secureGet(AUTH_TOKEN_KEY, "");
  const response = await fetch(`${backendUrl}/api${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers ?? {}),
    },
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.detail ?? "Something went wrong");
  return body as T;
}

export const api = {
  login: (email: string, password: string) =>
    request<{ session_token: string; user: User }>("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    }),
  register: (payload: { name: string; email: string; password: string; role: string }) =>
    request<{ session_token: string; user: User }>("/auth/register", {
      method: "POST",
      body: JSON.stringify(payload),
    }),
  me: () => request<User>("/auth/me"),
  dashboard: () => request<Dashboard>("/dashboard"),
  hospitals: () => request<Hospital[]>("/hospitals"),
  ambulances: () => request<Ambulance[]>("/ambulances"),
  specialists: () => request<Specialist[]>("/specialists"),
  supplies: () => request<Supply[]>("/supplies"),
  patients: () => request<Patient[]>("/patients"),
  forecasts: () =>
    request<{
      forecasts: Forecast[];
      summary: { high_risk: number; medium_risk: number; low_risk: number };
      generated_at: string;
      model: string;
    }>("/analytics/forecast"),
  updateSupply: (resource_id: string, quantity: number) =>
    request<Supply>(`/supplies/${resource_id}`, {
      method: "PATCH",
      body: JSON.stringify({ quantity }),
    }),
  triage: (payload: Record<string, unknown>) =>
    request<TriageResult>("/triage", { method: "POST", body: JSON.stringify(payload) }),
  match: (payload: Record<string, unknown>) =>
    request<MatchResult>("/match", { method: "POST", body: JSON.stringify(payload) }),
  disasterSimulate: (payload: Record<string, unknown>) =>
    request<DisasterResult>("/disaster/simulate", { method: "POST", body: JSON.stringify(payload) }),
  disasterActive: () =>
    request<{ active: boolean; disaster: DisasterResult | null }>("/disaster/active"),
  disasterEnd: () => request<{ ok: boolean }>("/disaster/end", { method: "POST" }),
  ambulanceRoute: (resource_id: string) =>
    request<AmbulanceRoute>(`/ambulances/${resource_id}/route`),
  consultStart: (payload: { specialist_id: string; patient_id?: string; reason?: string }) =>
    request<Consult>("/consult/start", { method: "POST", body: JSON.stringify(payload) }),
  consultActive: () => request<Consult[]>("/consult/active"),
  consultEnd: (consult_id: string) =>
    request<{ ok: boolean }>("/consult/end", { method: "POST", body: JSON.stringify({ consult_id }) }),
  logout: () => request<{ ok: boolean }>("/auth/logout", { method: "POST" }),
};

export async function saveSession(sessionToken: string) {
  await storage.secureSet(AUTH_TOKEN_KEY, sessionToken);
}
export async function clearSession() {
  await storage.secureRemove(AUTH_TOKEN_KEY);
}
