import * as Linking from "expo-linking";
import * as WebBrowser from "expo-web-browser";
import { createContext, PropsWithChildren, useContext, useEffect, useMemo, useState } from "react";
import { Platform } from "react-native";

import { api, AUTH_TOKEN_KEY, clearSession, saveSession, User } from "@/src/api";
import { storage } from "@/src/utils/storage";

WebBrowser.maybeCompleteAuthSession();

const AuthContext = createContext<null | {
  user: User | null;
  loading: boolean;
  error: string;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string, role: string) => Promise<void>;
  googleLogin: () => Promise<void>;
  logout: () => Promise<void>;
  clearError: () => void;
}>(null);

const handledSessionIds = new Set<string>();

function getSessionId(url: string | null) {
  return url?.match(/[?#&]session_id=([^&#]+)/)?.[1] ?? null;
}

export function AuthProvider({ children }: PropsWithChildren) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const finishGoogle = async (url: string) => {
    const sessionId = getSessionId(url);
    if (!sessionId || handledSessionIds.has(sessionId)) return false;
    handledSessionIds.add(sessionId);
    try {
      const backend = String(
        process.env.EXPO_PUBLIC_BACKEND_URL ?? process.env.EXPO_BACKEND_URL ?? "",
      ).replace(/\/$/, "");
      const response = await fetch(`${backend}/api/auth/session`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ session_id: sessionId }),
      });
      const body = await response.json();
      if (!response.ok) throw new Error(body.detail ?? "Google sign-in failed");
      await saveSession(body.session_token);
      setUser(body.user);
      return true;
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Google sign-in failed");
      return false;
    }
  };

  useEffect(() => {
    let mounted = true;
    const bootstrap = async () => {
      try {
        if (Platform.OS === "web") {
          const url = window.location.href;
          const sessionId = getSessionId(url);
          if (sessionId) await finishGoogle(url);
        } else {
          const initialUrl = await Linking.getInitialURL();
          if (initialUrl) await finishGoogle(initialUrl);
        }
        const token = await storage.secureGet(AUTH_TOKEN_KEY, "");
        if (token && mounted) {
          try {
            setUser(await api.me());
          } catch {
            await clearSession();
          }
        }
      } finally {
        if (mounted) setLoading(false);
      }
    };
    const listener =
      Platform.OS === "web"
        ? undefined
        : Linking.addEventListener("url", ({ url }) => {
            void finishGoogle(url);
          });
    void bootstrap();
    return () => {
      mounted = false;
      listener?.remove();
    };
  }, []);

  const value = useMemo(
    () => ({
      user,
      loading,
      error,
      clearError: () => setError(""),
      login: async (email: string, password: string) => {
        setError("");
        try {
          const response = await api.login(email, password);
          await saveSession(response.session_token);
          setUser(response.user);
        } catch (caught) {
          setError(caught instanceof Error ? caught.message : "Unable to sign in");
          throw caught;
        }
      },
      register: async (name: string, email: string, password: string, role: string) => {
        setError("");
        try {
          const response = await api.register({ name, email, password, role });
          await saveSession(response.session_token);
          setUser(response.user);
        } catch (caught) {
          setError(caught instanceof Error ? caught.message : "Unable to create account");
          throw caught;
        }
      },
      googleLogin: async () => {
        setError("");
        if (Platform.OS === "web") {
          window.location.href = `https://auth.emergentagent.com/?redirect=${encodeURIComponent(
            `${window.location.origin}/`,
          )}`;
          return;
        }
        const redirectUrl = Linking.createURL("");
        const result = await WebBrowser.openAuthSessionAsync(
          `https://auth.emergentagent.com/?redirect=${encodeURIComponent(redirectUrl)}`,
          redirectUrl,
        );
        if (result.type === "success" && result.url) await finishGoogle(result.url);
      },
      logout: async () => {
        try {
          await api.logout();
        } catch {}
        await clearSession();
        setUser(null);
      },
    }),
    [user, loading, error],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used inside AuthProvider");
  return context;
}
