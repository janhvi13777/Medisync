import { MaterialCommunityIcons } from "@expo/vector-icons";
import { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Modal,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api, Consult } from "@/src/api";
import { makeStyles, useTheme } from "@/src/theme";

type Props = {
  visible: boolean;
  specialistId?: string | null;
  patientId?: string | null;
  reason?: string;
  onClose: () => void;
};

export function ConsultSheet({ visible, specialistId, patientId, reason, onClose }: Props) {
  const { colors } = useTheme();
  const styles = useStyles();
  const insets = useSafeAreaInsets();

  const [consult, setConsult] = useState<Consult | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [muted, setMuted] = useState(false);
  const [cameraOff, setCameraOff] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (!visible) {
      setConsult(null);
      setError("");
      setElapsed(0);
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }
    if (!specialistId) return;
    setBusy(true);
    api
      .consultStart({
        specialist_id: specialistId,
        patient_id: patientId ?? undefined,
        reason: reason ?? "Emergency consult",
      })
      .then((c) => {
        setConsult(c);
        setElapsed(0);
        timerRef.current = setInterval(() => setElapsed((e) => e + 1), 1000);
      })
      .catch((caught) => setError(caught instanceof Error ? caught.message : "Could not start consult"))
      .finally(() => setBusy(false));
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [visible, specialistId, patientId, reason]);

  const end = async () => {
    if (consult) {
      try {
        await api.consultEnd(consult.consult_id);
      } catch {}
    }
    onClose();
  };

  const mm = String(Math.floor(elapsed / 60)).padStart(2, "0");
  const ss = String(elapsed % 60).padStart(2, "0");

  return (
    <Modal
      transparent
      animationType="slide"
      visible={visible}
      onRequestClose={() => void end()}
    >
      <View style={styles.backdrop}>
        <View style={[styles.sheet, { paddingTop: insets.top + 20, paddingBottom: insets.bottom + 20 }]}>
          {busy && !consult ? (
            <View style={styles.center}>
              <ActivityIndicator size="large" color={colors.brandPrimary} />
              <Text style={styles.muted}>Connecting secure line…</Text>
            </View>
          ) : error ? (
            <View style={styles.center}>
              <MaterialCommunityIcons name="phone-off" size={30} color={colors.error} />
              <Text style={styles.error}>{error}</Text>
              <Pressable onPress={onClose} style={styles.closeBtn} testID="consult-close">
                <Text style={styles.closeBtnText}>CLOSE</Text>
              </Pressable>
            </View>
          ) : consult ? (
            <>
              <View style={styles.headerRow}>
                <View style={styles.recording}>
                  <View style={styles.recDot} />
                  <Text style={styles.recText}>SECURE · E2E ENCRYPTED</Text>
                </View>
                <Text style={styles.timer}>
                  {mm}:{ss}
                </Text>
              </View>

              <View style={styles.videoPane} testID="consult-video">
                {cameraOff ? (
                  <View style={styles.videoOff}>
                    <MaterialCommunityIcons name="video-off" size={38} color={colors.muted} />
                    <Text style={styles.muted}>Camera off</Text>
                  </View>
                ) : (
                  <View style={styles.videoFace}>
                    <View style={styles.avatarLg}>
                      <Text style={styles.avatarLgText}>{consult.specialist_initials}</Text>
                    </View>
                    <View style={styles.wavePulse} />
                  </View>
                )}
                <View style={styles.selfPreview}>
                  <MaterialCommunityIcons name="account" size={22} color={colors.muted} />
                </View>
              </View>

              <View style={styles.specCard}>
                <View style={styles.avatarSm}>
                  <Text style={styles.avatarSmText}>{consult.specialist_initials}</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.specName}>{consult.specialist_name}</Text>
                  <Text style={styles.muted}>{consult.specialist_specialty}</Text>
                </View>
                <View style={styles.livePill}>
                  <View style={styles.livePillDot} />
                  <Text style={styles.livePillText}>LIVE</Text>
                </View>
              </View>

              <View style={styles.patientCard}>
                <Text style={styles.patientLabel}>PATIENT BRIEF</Text>
                <Text style={styles.patientText}>{consult.patient_summary}</Text>
                <Text style={styles.patientReason}>{consult.reason}</Text>
              </View>

              <View style={styles.controls}>
                <Pressable
                  testID="consult-mute"
                  onPress={() => setMuted((m) => !m)}
                  style={[styles.ctlBtn, muted && styles.ctlBtnActive]}
                >
                  <MaterialCommunityIcons
                    name={muted ? "microphone-off" : "microphone"}
                    size={22}
                    color={muted ? colors.error : colors.onSurface}
                  />
                </Pressable>
                <Pressable
                  testID="consult-camera"
                  onPress={() => setCameraOff((v) => !v)}
                  style={[styles.ctlBtn, cameraOff && styles.ctlBtnActive]}
                >
                  <MaterialCommunityIcons
                    name={cameraOff ? "video-off" : "video"}
                    size={22}
                    color={cameraOff ? colors.error : colors.onSurface}
                  />
                </Pressable>
                <Pressable testID="consult-end" onPress={() => void end()} style={styles.endBtn}>
                  <MaterialCommunityIcons name="phone-hangup" size={22} color={colors.onError} />
                  <Text style={styles.endBtnText}>END</Text>
                </Pressable>
              </View>
            </>
          ) : null}
        </View>
      </View>
    </Modal>
  );
}

const useStyles = makeStyles((colors) => ({
  backdrop: { flex: 1, backgroundColor: "rgba(0,0,0,0.75)", justifyContent: "flex-end" },
  sheet: {
    minHeight: "88%",
    backgroundColor: colors.surface,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingHorizontal: 20,
    gap: 14,
  },
  center: {
    ...StyleSheet.absoluteFillObject,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
  },
  headerRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  recording: { flexDirection: "row", alignItems: "center", gap: 6 },
  recDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.success },
  recText: { color: colors.success, fontSize: 10, fontWeight: "900", letterSpacing: 1 },
  timer: { color: colors.onSurface, fontSize: 16, fontWeight: "900", fontVariant: ["tabular-nums"] },
  videoPane: {
    minHeight: 320, borderRadius: 20,
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1, borderColor: colors.border,
    overflow: "hidden", position: "relative",
    alignItems: "center", justifyContent: "center",
  },
  videoFace: { alignItems: "center", justifyContent: "center", gap: 20 },
  videoOff: { alignItems: "center", gap: 8 },
  avatarLg: {
    width: 110, height: 110, borderRadius: 55,
    backgroundColor: colors.brandPrimary,
    alignItems: "center", justifyContent: "center",
  },
  avatarLgText: { color: colors.onBrandPrimary, fontSize: 40, fontWeight: "900" },
  wavePulse: {
    position: "absolute", width: 160, height: 160, borderRadius: 80,
    borderWidth: 2, borderColor: colors.brandPrimary, opacity: 0.35,
  },
  selfPreview: {
    position: "absolute", right: 12, bottom: 12,
    width: 72, height: 96, borderRadius: 12,
    backgroundColor: colors.surfaceTertiary,
    borderWidth: 1, borderColor: colors.border,
    alignItems: "center", justifyContent: "center",
  },
  specCard: {
    flexDirection: "row", alignItems: "center", gap: 12,
    padding: 12, borderRadius: 14,
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1, borderColor: colors.border,
  },
  avatarSm: {
    width: 40, height: 40, borderRadius: 12,
    backgroundColor: colors.brandTertiary,
    alignItems: "center", justifyContent: "center",
  },
  avatarSmText: { color: colors.brandPrimary, fontSize: 14, fontWeight: "900" },
  specName: { color: colors.onSurface, fontSize: 15, fontWeight: "800" },
  muted: { color: colors.muted, fontSize: 12 },
  livePill: {
    flexDirection: "row", alignItems: "center", gap: 5,
    paddingHorizontal: 9, paddingVertical: 5,
    borderRadius: 999, backgroundColor: "rgba(16,185,129,0.14)",
  },
  livePillDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: colors.success },
  livePillText: { color: colors.success, fontSize: 9, fontWeight: "900", letterSpacing: 0.8 },
  patientCard: {
    padding: 12, borderRadius: 14,
    backgroundColor: colors.brandTertiary,
    borderWidth: 1, borderColor: colors.borderStrong, gap: 6,
  },
  patientLabel: { color: colors.brandPrimary, fontSize: 10, fontWeight: "900", letterSpacing: 1 },
  patientText: { color: colors.onSurface, fontSize: 14, fontWeight: "800" },
  patientReason: { color: colors.onSurfaceSecondary, fontSize: 12 },
  controls: { flexDirection: "row", gap: 12, alignItems: "center", justifyContent: "center", marginTop: 6 },
  ctlBtn: {
    width: 56, height: 56, borderRadius: 28,
    backgroundColor: colors.surfaceSecondary,
    borderWidth: 1, borderColor: colors.border,
    alignItems: "center", justifyContent: "center",
  },
  ctlBtnActive: { borderColor: colors.error, backgroundColor: "rgba(239,68,68,0.12)" },
  endBtn: {
    minHeight: 56, paddingHorizontal: 22, borderRadius: 28,
    backgroundColor: colors.error,
    flexDirection: "row", alignItems: "center", gap: 8,
  },
  endBtnText: { color: colors.onError, fontSize: 12, fontWeight: "900", letterSpacing: 0.8 },
  error: { color: colors.error, fontSize: 13 },
  closeBtn: {
    minHeight: 44, paddingHorizontal: 22, borderRadius: 10,
    borderWidth: 1, borderColor: colors.border, justifyContent: "center",
  },
  closeBtnText: { color: colors.onSurface, fontSize: 12, fontWeight: "800" },
}));
