// Medisync theme tokens.
//
// Two schemes — light (medical dashboard) is the default; dark uses fresh
// emerald + slate for high-contrast safety look. Both share the same key set.

import { useMemo } from "react";
import { Appearance, StyleSheet, useColorScheme } from "react-native";

export type ColorScheme = "light" | "dark";

const light = {
  // Surfaces
  surface: "#F6F8FB",
  onSurface: "#0F172A",
  surfaceSecondary: "#FFFFFF",
  onSurfaceSecondary: "#334155",
  surfaceTertiary: "#EEF2F7",
  onSurfaceTertiary: "#475569",
  surfaceInverse: "#0F172A",
  onSurfaceInverse: "#F6F8FB",
  muted: "#64748B",

  // Brand (emerald + teal accents)
  brand: "#059669",
  onBrand: "#FFFFFF",
  brandPrimary: "#059669",
  onBrandPrimary: "#FFFFFF",
  brandSecondary: "#047857",
  onBrandSecondary: "#FFFFFF",
  brandTertiary: "rgba(5, 150, 105, 0.12)",
  onBrandTertiary: "#047857",

  // Status
  success: "#10B981",
  onSuccess: "#FFFFFF",
  warning: "#F59E0B",
  onWarning: "#1E293B",
  error: "#DC2626",
  onError: "#FFFFFF",
  info: "#0EA5E9",
  onInfo: "#FFFFFF",

  // Lines
  border: "#E2E8F0",
  borderStrong: "#059669",
  divider: "#EDF2F7",
};

const dark = {
  // Surfaces — slate stack
  surface: "#0B1220",
  onSurface: "#E2E8F0",
  surfaceSecondary: "#101B2D",
  onSurfaceSecondary: "#CBD5E1",
  surfaceTertiary: "#182338",
  onSurfaceTertiary: "#94A3B8",
  surfaceInverse: "#E2E8F0",
  onSurfaceInverse: "#0B1220",
  muted: "#64748B",

  // Brand — emerald pops on slate
  brand: "#10B981",
  onBrand: "#0B1220",
  brandPrimary: "#10B981",
  onBrandPrimary: "#0B1220",
  brandSecondary: "#059669",
  onBrandSecondary: "#FFFFFF",
  brandTertiary: "rgba(16, 185, 129, 0.18)",
  onBrandTertiary: "#34D399",

  // Status
  success: "#22C55E",
  onSuccess: "#0B1220",
  warning: "#F59E0B",
  onWarning: "#0B1220",
  error: "#F87171",
  onError: "#0B1220",
  info: "#38BDF8",
  onInfo: "#0B1220",

  // Lines
  border: "#1F2A44",
  borderStrong: "#10B981",
  divider: "#182338",
};

export type ThemeColors = typeof light;

export const defaultScheme = "light" satisfies ColorScheme;

export const themes: { light: ThemeColors; dark: ThemeColors } = { light, dark };

export function setColorScheme(scheme: ColorScheme | null) {
  Appearance.setColorScheme?.(scheme);
}

setColorScheme?.(null);

export function useTheme(): { scheme: ColorScheme; colors: ThemeColors } {
  const system = useColorScheme();
  const scheme: ColorScheme = system === "dark" ? "dark" : "light";
  return { scheme, colors: themes[scheme] };
}

export function makeStyles<T extends StyleSheet.NamedStyles<T> | StyleSheet.NamedStyles<any>>(
  factory: (colors: ThemeColors) => T & StyleSheet.NamedStyles<any>,
): () => T {
  return function useStyles(): T {
    const { colors } = useTheme();
    return useMemo(() => StyleSheet.create(factory(colors)), [colors]);
  };
}
