# Medisync – Product Requirements

## What it is
Medisync is an emergency healthcare resource coordination platform. It connects hospitals, ambulances, specialists, doctors, and coordinators in real time, with AI-guided triage and hospital matching so critical patients reach the right facility fast.

## Data
- 80 real hospitals from Nashik (NMC dataset) with beds, ICU, ventilators, ambulances, specialists on-call, emergency status, and lat/lng.

## Roles (all seeded, password `MediSync123!`)
- **Coordinator** — `coordinator@medisync.app` — regional command view (metrics, live hospitals, patients, forecasts, disaster simulator).
- **Hospital Admin** — `hospital@medisync.app` — Apollo Nashik view with inbound ambulances.
- **Ambulance** — `ambulance@medisync.app` — EMS-041 unit view with live route to destination.
- **Specialist** — `specialist@medisync.app` — Dr. Aisha Rahman on-call view with one-tap video consult.
- **Doctor** — `doctor@medisync.app` — Apollo ED view with active patients.

## Core features
- **AI Emergency Triage** (Claude Sonnet 4.6) — vitals + complaint → severity, score, flags, recommendations, AI narrative.
- **Explainable 0-100 Hospital Match** — 5 weighted sub-scores across the 80-hospital network with Claude rationale.
- **Live Ops Tracking** — ambulances on Nashik map, specialists, patients in motion.
- **Predictive Forecasts** — 6h/24h risk on ICU, blood, trauma kits, ventilators.
- **Disaster Mode** — mass-casualty simulator: enter critical/urgent/moderate counts + radius → greedy auto-distribution across hospitals prioritising ICU/vent capacity for critical, with per-hospital assignment plan and unassigned overflow.
- **Ambulance Live Route** — moving-map screen with dotted path, ambulance/destination pins, ticking ETA, turn-by-turn maneuver cards, and play/pause simulation control.
- **Specialist Video Consult** — one-tap secure sheet with SECURE · E2E ENCRYPTED banner, timer, specialist avatar + self preview, patient brief, mic/camera/end controls; consult persisted via `/api/consult/*`.
- **Supply Inventory** — quantity + threshold, low-reserve flags, editable via bottom sheet.
- **FHIR-style seed data**, **Web multi-column** coordinator dashboard.

## Tech
- Expo Router (mobile + web) with role-aware tabs.
- FastAPI + Motor (async MongoDB), JWT + role-based access, unique `jti` per session.
- Emergent LLM Key → Claude Sonnet 4.6 for triage + match narratives.
