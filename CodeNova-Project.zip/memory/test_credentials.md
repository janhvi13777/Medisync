# Test Credentials — Medisync
# Agent writes here when creating/modifying auth credentials. Testing agent reads this before auth tests.

All demo accounts share password: `MediSync123!`

| Role            | Email                        | Name              | Facility |
| --------------- | ---------------------------- | ----------------- | -------- |
| Coordinator     | coordinator@medisync.app     | Jordan Blake      | Regional Command |
| Hospital Admin  | hospital@medisync.app        | Dr. Amara Okoye   | St. Mary's Medical Center (hosp-01) |
| Ambulance       | ambulance@medisync.app       | Paramedic Sam Lee | EMS-041 Central (amb-01) |
| Specialist      | specialist@medisync.app      | Dr. Aisha Rahman  | St. Mary's Trauma Surgery (spec-01) |
| Doctor          | doctor@medisync.app          | Dr. Kai Reyes     | St. Mary's Emergency Dept (hosp-01) |

Google OAuth: use a permitted Google identity through the in-app "Continue with Google" flow; no password is stored here.
